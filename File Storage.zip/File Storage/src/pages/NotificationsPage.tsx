    import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Bell, BellOff, CheckCheck, FileText, Share2,
  Upload, Trash2, MessageSquare, AlertTriangle, RotateCcw,
} from 'lucide-react';
import { notificationsApi } from '@/services/api';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import type { FileNotification, NotificationType } from '@/types';
import { formatDate } from '@/lib/formatters';
import { toast } from 'sonner';

const NOTIF_ICONS: Record<NotificationType, React.ReactNode> = {
  FILE_SHARED:       <Share2 className="w-4 h-4" />,
  FILE_UPLOADED:     <Upload className="w-4 h-4" />,
  FILE_UPDATED:      <FileText className="w-4 h-4" />,
  FILE_DELETED:      <Trash2 className="w-4 h-4" />,
  COMMENT_ADDED:     <MessageSquare className="w-4 h-4" />,
  MENTIONED:         <MessageSquare className="w-4 h-4" />,
  SHARE_EXPIRING:    <Share2 className="w-4 h-4" />,
  QUOTA_WARNING:     <AlertTriangle className="w-4 h-4" />,
  RESTORE_COMPLETED: <RotateCcw className="w-4 h-4" />,
};

const NOTIF_COLORS: Record<NotificationType, string> = {
  FILE_SHARED:       'bg-primary/10 text-primary',
  FILE_UPLOADED:     'bg-[hsl(var(--success))]/10 text-[hsl(var(--success))]',
  FILE_UPDATED:      'bg-primary/10 text-primary',
  FILE_DELETED:      'bg-destructive/10 text-destructive',
  COMMENT_ADDED:     'bg-[hsl(var(--info))]/10 text-[hsl(var(--info))]',
  MENTIONED:         'bg-[hsl(var(--info))]/10 text-[hsl(var(--info))]',
  SHARE_EXPIRING:    'bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))]',
  QUOTA_WARNING:     'bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))]',
  RESTORE_COMPLETED: 'bg-[hsl(var(--success))]/10 text-[hsl(var(--success))]',
};

export default function NotificationsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<FileNotification[]>([]);
  const [loading, setLoading]             = useState(true);
  const [typeFilter, setTypeFilter]       = useState('all');
  const [readFilter, setReadFilter]       = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number | undefined> = { limit: 100 };
      if (readFilter === 'unread') params.is_read = 0;
      if (readFilter === 'read') params.is_read = 1;
      if (typeFilter !== 'all') params.notification_type = typeFilter;
      const res = await notificationsApi.list(params);
      setNotifications(res?.data || []);
    } catch {
      // Backend unavailable in demo mode — show empty state silently
      setNotifications([]);
    } finally { setLoading(false); }
  }, [typeFilter, readFilter]);

  useEffect(() => { load(); }, [load]);

  // Auto mark-all-read 1.5 s after mount (once per page visit)
  useEffect(() => {
    const timer = setTimeout(async () => {
      try {
        await notificationsApi.markAllRead();
        setNotifications(prev => prev.map(n => ({ ...n, is_read: 1 })));
      } catch {
        // non-critical
      }
    }, 1500);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // intentionally empty — fires once on mount only

  // Supabase Realtime — ref-guard pattern, Strict Mode safe
  useEffect(() => {
    if (!user?.id) return;

    const mountedRef = { current: true, channel: undefined as ReturnType<typeof supabase.channel> | undefined };

    Promise.resolve().then(() => {
      if (!mountedRef.current) return;

      const channelName = `notifications-page:${user.id}:${crypto.randomUUID()}`;
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'file_notifications',
            filter: `user_id=eq.${user.id}`,
          },
          (payload) => {
            const newNotif = payload.new as FileNotification;
            const matchesType = typeFilter === 'all' || newNotif.notification_type === typeFilter;
            const matchesRead = readFilter === 'all' || (readFilter === 'unread' && newNotif.is_read === 0);
            if (matchesType && matchesRead) {
              setNotifications(prev => [newNotif, ...prev]);
            }
          }
        )
        .subscribe();

      mountedRef.channel = channel;
    });

    return () => {
      mountedRef.current = false;
      if (mountedRef.channel) {
        supabase.removeChannel(mountedRef.channel);
        mountedRef.channel = undefined;
      }
    };
  }, [user?.id, typeFilter, readFilter]);

  const handleMarkRead = async (id: string) => {
    try {
      await notificationsApi.markRead(id);
      setNotifications(prev => prev.map(n =>
        n.notification_id === id ? { ...n, is_read: 1 } : n
      ));
    } catch (e: unknown) { toast.error((e as Error).message); }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationsApi.markAllRead();
      setNotifications(prev => prev.map(n => ({ ...n, is_read: 1 })));
      toast.success('All notifications marked as read');
    } catch (e: unknown) { toast.error((e as Error).message); }
  };

  const unreadCount = notifications.filter(n => n.is_read === 0).length;

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance flex items-center gap-2">
            Notifications
            {unreadCount > 0 && (
              <Badge className="bg-primary text-primary-foreground text-xs">{unreadCount}</Badge>
            )}
          </h1>
          <p className="text-sm text-muted-foreground text-pretty">Your in-app notification center</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="secondary" className="gap-2 shrink-0" onClick={handleMarkAllRead}>
            <CheckCheck className="w-4 h-4" /> Mark all read
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-3 flex flex-row gap-2 items-center flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground whitespace-nowrap">Type</span>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="h-8 text-xs w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {[
                  'FILE_SHARED', 'FILE_UPLOADED', 'FILE_UPDATED', 'FILE_DELETED',
                  'COMMENT_ADDED', 'MENTIONED', 'SHARE_EXPIRING', 'QUOTA_WARNING', 'RESTORE_COMPLETED',
                ].map(t => (
                  <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground">Status</span>
            <Select value={readFilter} onValueChange={setReadFilter}>
              <SelectTrigger className="h-8 text-xs w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="unread">Unread</SelectItem>
                <SelectItem value="read">Read</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <span className="text-xs text-muted-foreground ml-auto">
            {notifications.length} notification{notifications.length !== 1 ? 's' : ''}
          </span>
        </CardContent>
      </Card>

      {/* Notifications list */}
      {loading ? (
        <div className="space-y-2">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-20 w-full bg-muted rounded-md" />)}
        </div>
      ) : notifications.length === 0 ? (
        <Card>
          <CardContent className="py-20 flex flex-col items-center gap-3 text-muted-foreground">
            <BellOff className="w-12 h-12 opacity-20" />
            <p className="text-sm">No notifications</p>
            <p className="text-xs text-center max-w-xs text-pretty">
              You'll see notifications here when files are shared, updated, or need your attention
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {notifications.map(n => (
            <Card
              key={n.notification_id}
              className={`cursor-pointer transition-colors hover:border-primary/40 ${n.is_read === 0 ? 'border-primary/30 bg-primary/2' : ''}`}
              onClick={() => {
                if (n.is_read === 0) handleMarkRead(n.notification_id);
                if (n.document_id) navigate(`/files/${n.document_id}`);
              }}
            >
              <CardContent className="p-3 flex items-start gap-3">
                {/* Icon */}
                <div className={`w-9 h-9 rounded-md flex items-center justify-center shrink-0 ${NOTIF_COLORS[n.notification_type] || 'bg-muted text-muted-foreground'}`}>
                  {NOTIF_ICONS[n.notification_type] || <Bell className="w-4 h-4" />}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className={`text-sm text-pretty ${n.is_read === 0 ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                      {n.message}
                    </p>
                    {n.is_read === 0 && (
                      <div className="w-2 h-2 rounded-full bg-primary shrink-0 mt-1.5" />
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">{formatDate(n.created_at)}</span>
                    <Badge variant="outline" className="text-[10px]">{n.notification_type.replace(/_/g, ' ')}</Badge>
                    <Badge variant="secondary" className="text-[10px]">{n.delivery_method}</Badge>
                  </div>
                </div>

                {/* Actions */}
                {n.is_read === 0 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 shrink-0 text-muted-foreground hover:text-foreground"
                    onClick={e => { e.stopPropagation(); handleMarkRead(n.notification_id); }}
                    title="Mark as read"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
