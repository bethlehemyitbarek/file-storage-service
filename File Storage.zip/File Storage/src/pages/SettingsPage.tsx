import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import {
  Settings, User, HardDrive, Bell, Save, Loader2, AlertTriangle,
} from 'lucide-react';
import { preferencesApi, quotasApi } from '@/services/api';
import type { UserPreferences, StorageQuota } from '@/types';
import { useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';

export default function SettingsPage() {
  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get('tab') || 'preferences';

  const [prefs, setPrefs]   = useState<Partial<UserPreferences>>({
    preferred_view: 'LIST',
    default_sort_field: 'created_at',
    default_sort_order: 'DESC',
    items_per_page: 25,
    thumbnail_preview_enabled: 1,
    auto_save_interval_seconds: 30,
    theme: 'SYSTEM',
    language: 'en',
  });
  const [quota, setQuota]   = useState<StorageQuota | null>(null);
  const [loading, setLoading]  = useState(true);
  const [saving, setSaving]    = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [pRes, qRes] = await Promise.allSettled([
        preferencesApi.get(),
        quotasApi.getMe(),
      ]);
      if (pRes.status === 'fulfilled' && pRes.value) setPrefs(pRes.value);
      else {
        // Fall back to locally saved preferences
        const saved = localStorage.getItem('user_preferences');
        if (saved) { try { setPrefs(JSON.parse(saved)); } catch { /* keep defaults */ } }
      }
      if (qRes.status === 'fulfilled') setQuota(qRes.value);
    } catch { /* keep defaults */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSavePrefs = async () => {
    setSaving(true);
    try {
      await preferencesApi.update(prefs as Record<string, unknown>);
      toast.success('Preferences saved');
    } catch {
      // Backend unavailable — persist to localStorage in demo mode
      try {
        localStorage.setItem('user_preferences', JSON.stringify(prefs));
        toast.success('Preferences saved locally');
      } catch {
        toast.error('Failed to save preferences');
      }
    } finally { setSaving(false); }
  };

  const usedPct = quota ? Math.min(100, (quota.used_space_mb / quota.allocated_space_mb) * 100) : 0;

  const quotaStatusColor =
    quota?.status === 'EXCEEDED_HARD' ? 'text-destructive' :
    quota?.status === 'EXCEEDED_SOFT' ? 'text-[hsl(var(--warning))]' :
    'text-[hsl(var(--success))]';

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Settings</h1>
        <p className="text-sm text-muted-foreground text-pretty">Manage your preferences, quota, and notifications</p>
      </div>

      <Tabs defaultValue={defaultTab}>
        <TabsList className="grid grid-cols-3 w-full md:w-80">
          <TabsTrigger value="preferences" className="gap-1.5 text-xs">
            <User className="w-3.5 h-3.5" /> Preferences
          </TabsTrigger>
          <TabsTrigger value="quota" className="gap-1.5 text-xs">
            <HardDrive className="w-3.5 h-3.5" /> Quota
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-1.5 text-xs">
            <Bell className="w-3.5 h-3.5" /> Notifications
          </TabsTrigger>
        </TabsList>

        {/* Preferences */}
        <TabsContent value="preferences" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Settings className="w-4 h-4 text-primary" /> User Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-10 w-full bg-muted" />)}
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Default View</Label>
                      <Select
                        value={prefs.preferred_view}
                        onValueChange={v => setPrefs(p => ({ ...p, preferred_view: v as UserPreferences['preferred_view'] }))}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="LIST">List</SelectItem>
                          <SelectItem value="GRID">Grid</SelectItem>
                          <SelectItem value="DETAILED">Detailed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Default Sort</Label>
                      <div className="flex gap-2">
                        <Select
                          value={prefs.default_sort_field}
                          onValueChange={v => setPrefs(p => ({ ...p, default_sort_field: v }))}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="created_at">Created Date</SelectItem>
                            <SelectItem value="updated_at">Modified Date</SelectItem>
                            <SelectItem value="file_name">Name</SelectItem>
                            <SelectItem value="size_kb">Size</SelectItem>
                          </SelectContent>
                        </Select>
                        <Select
                          value={prefs.default_sort_order}
                          onValueChange={v => setPrefs(p => ({ ...p, default_sort_order: v as 'ASC' | 'DESC' }))}
                        >
                          <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ASC">ASC</SelectItem>
                            <SelectItem value="DESC">DESC</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Items per Page (max 100)</Label>
                      <Input
                        type="number"
                        min={5}
                        max={100}
                        value={prefs.items_per_page}
                        onChange={e => setPrefs(p => ({ ...p, items_per_page: parseInt(e.target.value) }))}
                        className="px-3"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Theme</Label>
                      <Select
                        value={prefs.theme}
                        onValueChange={v => setPrefs(p => ({ ...p, theme: v as UserPreferences['theme'] }))}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="LIGHT">Light</SelectItem>
                          <SelectItem value="DARK">Dark</SelectItem>
                          <SelectItem value="SYSTEM">System</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Auto-save Interval (seconds)</Label>
                      <Input
                        type="number"
                        min={10}
                        max={300}
                        value={prefs.auto_save_interval_seconds}
                        onChange={e => setPrefs(p => ({ ...p, auto_save_interval_seconds: parseInt(e.target.value) }))}
                        className="px-3"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-normal">Language</Label>
                      <Select
                        value={prefs.language}
                        onValueChange={v => setPrefs(p => ({ ...p, language: v }))}
                      >
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="am">Amharic</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Thumbnail Preview</p>
                      <p className="text-xs text-muted-foreground">Show file thumbnails in browser</p>
                    </div>
                    <Switch
                      checked={prefs.thumbnail_preview_enabled === 1}
                      onCheckedChange={v => setPrefs(p => ({ ...p, thumbnail_preview_enabled: v ? 1 : 0 }))}
                    />
                  </div>

                  <Button onClick={handleSavePrefs} disabled={saving} className="gap-2">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    {saving ? 'Saving…' : 'Save Preferences'}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Quota */}
        <TabsContent value="quota" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-primary" /> Storage Quota
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {loading ? (
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full bg-muted" />
                  <Skeleton className="h-8 w-full bg-muted" />
                  <Skeleton className="h-4 w-2/3 bg-muted" />
                </div>
              ) : !quota ? (
                <p className="text-sm text-muted-foreground">No quota information available</p>
              ) : (
                <>
                  {quota.status !== 'ACTIVE' && (
                    <div className="flex items-start gap-2 p-3 rounded-md bg-destructive/10 border border-destructive/20 text-xs text-destructive">
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                      {quota.status === 'EXCEEDED_HARD'
                        ? 'Hard limit exceeded — uploads are blocked until storage is freed.'
                        : 'Approaching quota limit — free up space soon to avoid upload blocks.'}
                    </div>
                  )}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Used</span>
                      <span className={`font-medium ${quotaStatusColor}`}>
                        {quota.used_space_mb.toFixed(0)} MB / {quota.allocated_space_mb.toFixed(0)} MB
                      </span>
                    </div>
                    <Progress value={usedPct} className="h-3" />
                    <p className="text-xs text-muted-foreground">{usedPct.toFixed(1)}% of quota used</p>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {[
                      ['Quota Type',   quota.quota_type],
                      ['Soft Limit',   `${quota.soft_limit_mb.toFixed(0)} MB`],
                      ['Hard Limit',   `${quota.hard_limit_mb.toFixed(0)} MB`],
                      ['Status',       quota.status],
                    ].map(([k, v]) => (
                      <div key={k} className="p-3 rounded-md bg-muted/40 border border-border/50">
                        <p className="text-xs text-muted-foreground">{k}</p>
                        <p className="text-sm font-medium mt-0.5">{v}</p>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification settings */}
        <TabsContent value="notifications" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary" /> Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {([
                { type: 'FILE_SHARED',       label: 'File shared with me' },
                { type: 'FILE_UPLOADED',     label: 'File uploaded' },
                { type: 'FILE_UPDATED',      label: 'File updated' },
                { type: 'FILE_DELETED',      label: 'File deleted' },
                { type: 'COMMENT_ADDED',     label: 'New comment on file' },
                { type: 'MENTIONED',         label: 'Mentioned in discussion' },
                { type: 'SHARE_EXPIRING',    label: 'Share link expiring' },
                { type: 'QUOTA_WARNING',     label: 'Quota warning' },
                { type: 'RESTORE_COMPLETED', label: 'Restore job completed' },
              ]).map(({ type, label }) => (
                <div key={type} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                  <div>
                    <p className="text-sm font-medium">{label}</p>
                    <p className="text-xs text-muted-foreground">{type}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">IN_APP</Badge>
                    <Switch defaultChecked />
                  </div>
                </div>
              ))}
              <div className="pt-2">
                <Button onClick={handleSavePrefs} disabled={saving} className="gap-2">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {saving ? 'Saving…' : 'Save Settings'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
