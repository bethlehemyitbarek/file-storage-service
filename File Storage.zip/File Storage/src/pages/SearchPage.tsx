import { useState, useCallback, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, FileText, Filter, X } from 'lucide-react';
import { filesApi } from '@/services/api';
import type { FileMetadata } from '@/types';
import { formatBytes, formatDate, mimeToExt } from '@/lib/formatters';
import { useDebounce } from '@/hooks/use-debounce';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [query, setQuery]       = useState(searchParams.get('q') || '');
  const [mimeFilter, setMime]   = useState('all');
  const [statusFilter, setStatus] = useState('all');
  const [tierFilter, setTier]   = useState('all');
  const [results, setResults]   = useState<FileMetadata[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(false);
  const [searched, setSearched] = useState(false);

  const debouncedQuery = useDebounce(query, 400);

  const runSearch = useCallback(async (q: string) => {
    if (!q.trim()) { setResults([]); setTotal(0); setSearched(false); return; }
    setLoading(true);
    setSearched(true);
    try {
      const params: Record<string, string | number | undefined> = {
        search: q,
        limit: 50,
      };
      if (mimeFilter !== 'all') params.mime_type = mimeFilter;
      if (statusFilter !== 'all') params.status = statusFilter;
      if (tierFilter !== 'all') params.storage_tier = tierFilter;

      const res = await filesApi.list(params);
      setResults(res?.data || []);
      setTotal(res?.total || 0);
      setSearchParams({ q });
    } catch { setResults([]); }
    finally { setLoading(false); }
  }, [mimeFilter, statusFilter, tierFilter, setSearchParams]);

  useEffect(() => { runSearch(debouncedQuery); }, [debouncedQuery, runSearch]);

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setTotal(0);
    setSearched(false);
    setSearchParams({});
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Search</h1>
        <p className="text-sm text-muted-foreground text-pretty">Full-text search across file names, tags, and content</p>
      </div>

      {/* Search bar */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              className="pl-9 pr-9 text-sm"
              placeholder='Search files… (e.g. "contract AND 2026")'
              value={query}
              onChange={e => setQuery(e.target.value)}
              autoFocus
            />
            {query && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                onClick={clearSearch}
              >
                <X className="w-3.5 h-3.5" />
              </Button>
            )}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
            <div className="flex gap-2 flex-wrap">
              <div className="flex items-center gap-1.5">
                <Label className="text-xs text-muted-foreground whitespace-nowrap">Type</Label>
                <Select value={mimeFilter} onValueChange={setMime}>
                  <SelectTrigger className="h-7 text-xs w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="application/pdf">PDF</SelectItem>
                    <SelectItem value="application/vnd.openxmlformats-officedocument.wordprocessingml.document">DOCX</SelectItem>
                    <SelectItem value="image/jpeg">JPEG</SelectItem>
                    <SelectItem value="text/plain">TXT</SelectItem>
                    <SelectItem value="application/json">JSON</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-1.5">
                <Label className="text-xs text-muted-foreground whitespace-nowrap">Status</Label>
                <Select value={statusFilter} onValueChange={setStatus}>
                  <SelectTrigger className="h-7 text-xs w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="ACTIVE">Active</SelectItem>
                    <SelectItem value="ARCHIVED">Archived</SelectItem>
                    <SelectItem value="PENDING">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-1.5">
                <Label className="text-xs text-muted-foreground whitespace-nowrap">Tier</Label>
                <Select value={tierFilter} onValueChange={setTier}>
                  <SelectTrigger className="h-7 text-xs w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="HOT">HOT</SelectItem>
                    <SelectItem value="WARM">WARM</SelectItem>
                    <SelectItem value="COLD">COLD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {loading && (
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 w-full bg-muted rounded-md" />)}
        </div>
      )}

      {!loading && searched && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">
            {total} result{total !== 1 ? 's' : ''} for "<span className="text-foreground font-medium">{query}</span>"
          </p>
          {results.length === 0 ? (
            <Card>
              <CardContent className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
                <FileText className="w-12 h-12 opacity-30" />
                <p className="text-sm">No files match your search</p>
                <p className="text-xs text-center max-w-xs text-pretty">
                  Try using different keywords, or check your filters
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {results.map(f => (
                <Card
                  key={f.document_id}
                  className="cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => navigate(`/files/${f.document_id}`)}
                >
                  <CardContent className="p-3 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center text-[11px] font-bold text-primary shrink-0">
                      {mimeToExt(f.mime_type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{f.file_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatBytes(f.size_kb * 1024)} · {f.mime_type} · {formatDate(f.updated_at)}
                      </p>
                      {f.description && (
                        <p className="text-xs text-muted-foreground mt-0.5 truncate text-pretty">{f.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Badge variant={f.status === 'ACTIVE' ? 'secondary' : 'outline'} className="text-xs">
                        {f.status}
                      </Badge>
                      <Badge variant="outline" className="text-xs">{f.storage_tier}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {!loading && !searched && (
        <div className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
          <Search className="w-12 h-12 opacity-20" />
          <p className="text-sm">Start typing to search your files</p>
          <p className="text-xs text-center max-w-xs text-pretty">
            Supports fuzzy matching, boolean operators (AND/OR/NOT), and phrase search
          </p>
        </div>
      )}
    </div>
  );
}
