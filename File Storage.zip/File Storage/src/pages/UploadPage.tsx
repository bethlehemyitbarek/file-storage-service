import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Upload, X, FileText, CheckCircle, AlertCircle,
  RefreshCw, FolderOpen, Info,
} from 'lucide-react';
import { uploadSessionsApi, fileRequestsApi } from '@/services/api';
import { supabase } from '@/db/supabase';
import { formatBytes } from '@/lib/formatters';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// Fixed UUIDs for demo mode (columns are uuid type in Postgres)
const DEMO_TENANT_ID = '00000000-0000-0000-0000-000000000001';
const DEMO_USER_ID   = '00000000-0000-0000-0000-000000000002';
const STORAGE_BUCKET = 'file-storage';

interface UploadFile {
  id: string;
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'done' | 'error';
  error?: string;
}

export default function UploadPage() {
  const navigate = useNavigate();
  const [uploads, setUploads] = useState<UploadFile[]>([]);
  const [dragging, setDragging] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const addFiles = useCallback((files: FileList | File[]) => {
    const arr = Array.from(files);
    const remaining = 5 - uploads.filter(u => u.status !== 'error').length;
    if (remaining <= 0) {
      toast.error('Maximum 5 files per session');
      return;
    }
    const toAdd = arr.slice(0, remaining).map(f => ({
      id: `${f.name}-${Date.now()}-${Math.random()}`,
      file: f,
      progress: 0,
      status: 'pending' as const,
    }));
    if (arr.length > remaining) {
      toast.warning(`Only ${remaining} file(s) added — max 5 per session`);
    }
    setUploads(prev => [...prev, ...toAdd]);
  }, [uploads]);

  const removeFile = (id: string) => {
    setUploads(prev => prev.filter(u => u.id !== id));
  };

  /** Upload one file to Supabase Storage with progress simulation, returns public URL */
  const uploadToStorage = async (uploadFile: UploadFile): Promise<string> => {
    const docId = crypto.randomUUID();
    const ext   = uploadFile.file.name.split('.').pop() || 'bin';
    const path  = `${docId}.${ext}`;

    // Tick progress while awaiting actual upload
    let tick = 0;
    const interval = setInterval(() => {
      tick = Math.min(tick + Math.random() * 15 + 5, 90);
      setUploads(prev => prev.map(u =>
        u.id === uploadFile.id ? { ...u, progress: Math.round(tick) } : u
      ));
    }, 200);

    try {
      const { error } = await supabase.storage
        .from(STORAGE_BUCKET)
        .upload(path, uploadFile.file, { upsert: false, contentType: uploadFile.file.type || 'application/octet-stream' });

      clearInterval(interval);
      if (error) throw new Error(error.message);

      setUploads(prev => prev.map(u =>
        u.id === uploadFile.id ? { ...u, progress: 100, status: 'done' } : u
      ));

      const { data: { publicUrl } } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path);
      return publicUrl;
    } catch (err) {
      clearInterval(interval);
      throw err;
    }
  };

  const handleUpload = async () => {
    const pending = uploads.filter(u => u.status === 'pending');
    if (pending.length === 0) return;

    setUploading(true);

    try {
      // Create upload session — fall back to local ID if backend is unavailable
      const totalSize = pending.reduce((sum, u) => sum + u.file.size / 1024, 0);
      let sessionIdValue: string = crypto.randomUUID();
      try {
        const session = await uploadSessionsApi.create({
          file_count: pending.length,
          total_size_kb: Math.round(totalSize),
        });
        sessionIdValue = session.session_id;
      } catch {
        // Backend unavailable — continue with local session ID
      }
      setSessionId(sessionIdValue);

      // Upload each file — track counts directly to avoid stale state reads
      let doneCount  = 0;
      let errorCount = 0;
      for (const upload of pending) {
        setUploads(prev => prev.map(u =>
          u.id === upload.id ? { ...u, status: 'uploading' } : u
        ));

        try {
          // Create file request record — non-critical, skip on network error
          try {
            await fileRequestsApi.create({
              file_name: upload.file.name,
              mime_type: upload.file.type || 'application/octet-stream',
              size_kb: Math.round(upload.file.size / 1024),
              source: 'HTTP',
              session_id: sessionIdValue,
            });
          } catch { /* non-critical */ }

          // Upload to Supabase Storage and get public URL
          const publicUrl = await uploadToStorage(upload);

          // Persist metadata with real storage URL so files are previewable
          const docId = crypto.randomUUID();
          const now   = new Date().toISOString();
          const { error: metaErr } = await supabase.from('file_metadata').insert({
            row_id:            crypto.randomUUID(),
            document_id:       docId,
            tenant_id:         DEMO_TENANT_ID,
            user_id:           DEMO_USER_ID,
            created_by:        DEMO_USER_ID,
            file_name:         upload.file.name,
            mime_type:         upload.file.type || 'application/octet-stream',
            size_kb:           Math.max(1, Math.round(upload.file.size / 1024)),
            version:           1,
            status:            'ACTIVE',
            checksum:          '',
            storage_path:      publicUrl,
            storage_tier:      'HOT',
            encryption_status: 'UNENCRYPTED',
            effective_from:    now,
            effective_to:      '9999-12-31T23:59:59Z',
            is_current:        1,
            created_at:        now,
            updated_at:        now,
          });
          if (metaErr) throw new Error(`Metadata save failed: ${metaErr.message}`);

          doneCount++;
        } catch (err: unknown) {
          errorCount++;
          setUploads(prev => prev.map(u =>
            u.id === upload.id ? { ...u, status: 'error', error: (err as Error).message } : u
          ));
        }
      }

      // Complete session — non-critical
      try {
        await uploadSessionsApi.update(sessionIdValue, {
          status: errorCount === 0 ? 'COMPLETED' : 'FAILED',
        });
      } catch { /* non-critical */ }

      if (doneCount > 0)  toast.success(`${doneCount} file(s) uploaded successfully`);
      if (errorCount > 0) toast.error(`${errorCount} file(s) failed — see errors above`);
    } catch (err: unknown) {
      const msg = (err as { message?: string })?.message ?? '';
      toast.error(msg || 'Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  };

  const totalFiles = uploads.length;
  const doneFiles  = uploads.filter(u => u.status === 'done').length;
  const errorFiles = uploads.filter(u => u.status === 'error').length;
  const overallProgress = totalFiles > 0 ? (doneFiles / totalFiles) * 100 : 0;

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-2xl">
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Upload Files</h1>
        <p className="text-sm text-muted-foreground text-pretty">Upload up to 5 files per session</p>
      </div>

      {/* Drop zone */}
      <Card
        className={cn(
          'border-2 border-dashed transition-colors cursor-pointer',
          dragging ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50',
          uploads.length >= 5 && 'opacity-50 pointer-events-none'
        )}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => {
          if (uploads.length >= 5) return;
          const input = document.createElement('input');
          input.type = 'file';
          input.multiple = true;
          input.onchange = e => addFiles((e.target as HTMLInputElement).files!);
          input.click();
        }}
      >
        <CardContent className="flex flex-col items-center justify-center py-12 gap-3 text-center">
          <div className={cn(
            'w-14 h-14 rounded-full flex items-center justify-center transition-colors',
            dragging ? 'bg-primary/20' : 'bg-muted'
          )}>
            <Upload className={cn('w-6 h-6 transition-colors', dragging ? 'text-primary' : 'text-muted-foreground')} />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">Drop files here or click to browse</p>
            <p className="text-xs text-muted-foreground mt-1">Max 5 files · Any file type supported</p>
          </div>
        </CardContent>
      </Card>

      {/* File limit notice */}
      {uploads.length > 0 && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Info className="w-3.5 h-3.5 shrink-0" />
          <span>{uploads.length} / 5 files added</span>
          {sessionId && <span className="ml-2 text-primary">Session: {sessionId.slice(0, 8)}…</span>}
        </div>
      )}

      {/* File list */}
      {uploads.length > 0 && (
        <Card>
          <CardHeader className="pb-2 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-medium">Files ({uploads.length})</CardTitle>
            {uploading && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Uploading {doneFiles}/{totalFiles}
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-2">
            {totalFiles > 0 && uploading && (
              <div className="space-y-1 mb-3">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Overall progress</span>
                  <span>{doneFiles}/{totalFiles}</span>
                </div>
                <Progress value={overallProgress} className="h-1.5" />
              </div>
            )}
            {uploads.map(u => (
              <div key={u.id} className="flex items-center gap-3 p-2.5 rounded-md bg-muted/40 border border-border/50">
                <div className="w-8 h-8 rounded bg-background flex items-center justify-center text-[10px] font-bold text-primary shrink-0 border border-border">
                  {u.file.name.split('.').pop()?.toUpperCase() || 'FILE'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium truncate">{u.file.name}</p>
                    <span className="text-xs text-muted-foreground shrink-0">{formatBytes(u.file.size)}</span>
                  </div>
                  {u.status === 'uploading' && (
                    <Progress value={u.progress} className="h-1 mt-1.5" />
                  )}
                  {u.status === 'error' && (
                    <p className="text-xs text-destructive mt-0.5">{u.error}</p>
                  )}
                </div>
                <div className="shrink-0">
                  {u.status === 'done'     && <CheckCircle className="w-4 h-4 text-[hsl(var(--success))]" />}
                  {u.status === 'error'    && <AlertCircle className="w-4 h-4 text-destructive" />}
                  {u.status === 'pending'  && (
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => removeFile(u.id)}>
                      <X className="w-3.5 h-3.5" />
                    </Button>
                  )}
                  {u.status === 'uploading' && (
                    <RefreshCw className="w-4 h-4 animate-spin text-primary" />
                  )}
                </div>
              </div>
            ))}

            {errorFiles > 0 && (
              <div className="flex items-center gap-2 p-2.5 rounded-md bg-destructive/10 border border-destructive/20 text-xs text-destructive">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                {errorFiles} file(s) failed. Retry or remove them.
              </div>
            )}

            <Separator />
            <div className="flex items-center gap-2 pt-1">
              <Button
                onClick={handleUpload}
                disabled={uploading || uploads.filter(u => u.status === 'pending').length === 0}
                className="gap-2"
              >
                <Upload className="w-4 h-4" />
                {uploading ? 'Uploading…' : `Upload ${uploads.filter(u => u.status === 'pending').length} File(s)`}
              </Button>
              <Button variant="ghost" onClick={() => setUploads([])} disabled={uploading}>
                Clear all
              </Button>
              {doneFiles > 0 && (
                <Button
                  variant="ghost"
                  className="ml-auto gap-2"
                  onClick={() => navigate('/files')}
                >
                  <FolderOpen className="w-4 h-4" /> View files
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Status badges */}
      {doneFiles > 0 && (
        <div className="flex gap-2 flex-wrap">
          <Badge variant="secondary" className="gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-[hsl(var(--success))]" /> {doneFiles} uploaded
          </Badge>
          {errorFiles > 0 && (
            <Badge variant="destructive" className="gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" /> {errorFiles} failed
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}
