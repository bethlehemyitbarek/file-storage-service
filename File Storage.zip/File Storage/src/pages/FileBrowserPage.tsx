import { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  FolderOpen, Grid3X3, List, LayoutList, Search, Plus,
  Folder as FolderIcon, MoreVertical, Upload, Trash2, Archive, Eye,
  ChevronRight, ChevronDown, FileText, RefreshCw,
} from 'lucide-react';
import { filesApi, foldersApi } from '@/services/api';
import { supabase } from '@/db/supabase';
import type { FileMetadata, Folder } from '@/types';
import { formatBytes, formatDate, mimeToExt } from '@/lib/formatters';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useDebounce } from '@/hooks/use-debounce';

type ViewMode = 'list' | 'grid' | 'detailed';

interface BreadcrumbItem { id: string; name: string; }

export default function FileBrowserPage() {
  const navigate = useNavigate();
  const [files, setFiles] = useState<FileMetadata[]>([]);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<ViewMode>('list');
  const [search, setSearch] = useState('');
  const [currentFolder, setCurrentFolder] = useState<string | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([{ id: 'root', name: 'All Files' }]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const debouncedSearch = useDebounce(search, 350);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [fRes, dRes] = await Promise.allSettled([
        foldersApi.list({ parent_folder_id: currentFolder || '', limit: 50 }),
        currentFolder
          ? foldersApi.getFiles(currentFolder, { limit: 50, search: debouncedSearch })
          : filesApi.list({ limit: 50, search: debouncedSearch, status: 'ACTIVE' }),
      ]);
      if (fRes.status === 'fulfilled') setFolders(fRes.value?.data || []);
      if (dRes.status === 'fulfilled') {
        setFiles(dRes.value?.data || []);
      } else {
        // Backend unavailable — read directly from Supabase
        let query = supabase
          .from('file_metadata')
          .select('*')
          .eq('is_current', 1)
          .eq('status', 'ACTIVE')
          .order('created_at', { ascending: false })
          .limit(50);
        if (debouncedSearch) query = query.ilike('file_name', `%${debouncedSearch}%`);
        const { data } = await query;
        setFiles((data as FileMetadata[]) || []);
      }
    } catch {
      setFiles([]);
      setFolders([]);
    } finally {
      setLoading(false);
    }
  }, [currentFolder, debouncedSearch]);

  useEffect(() => { load(); }, [load]);

  const navigateToFolder = (folder: Folder) => {
    setCurrentFolder(folder.folder_id);
    setBreadcrumbs(prev => [...prev, { id: folder.folder_id, name: folder.folder_name }]);
    setSelectedIds(new Set());
  };

  const navigateToBreadcrumb = (idx: number) => {
    const crumb = breadcrumbs[idx];
    setBreadcrumbs(prev => prev.slice(0, idx + 1));
    setCurrentFolder(idx === 0 ? null : crumb.id);
    setSelectedIds(new Set());
  };

  const handleDelete = async (id: string) => {
    try {
      await filesApi.delete(id);
      toast.success('File deleted');
      load();
    } catch {
      // Backend unavailable — soft-delete in Supabase directly
      await supabase.from('file_metadata').update({ status: 'DELETED', is_current: 0 }).eq('document_id', id);
      setFiles(prev => prev.filter(f => f.document_id !== id));
      toast.success('File deleted');
    }
  };

  const handleArchive = async (id: string) => {
    try {
      await filesApi.archive(id);
      toast.success('File archived');
      load();
    } catch {
      // Backend unavailable — archive in Supabase directly
      await supabase.from('file_metadata').update({ status: 'ARCHIVED' }).eq('document_id', id);
      setFiles(prev => prev.filter(f => f.document_id !== id));
      toast.success('File archived');
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const statusBadgeVariant = (s: string) => {
    if (s === 'ACTIVE') return 'secondary';
    if (s === 'ARCHIVED') return 'outline';
    if (s === 'DELETED') return 'destructive';
    return 'secondary';
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">File Browser</h1>
          <p className="text-sm text-muted-foreground text-pretty">Browse, manage and organize your files</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button onClick={() => navigate('/upload')} className="gap-2">
            <Upload className="w-4 h-4" /> Upload
          </Button>
        </div>
      </div>

      {/* Breadcrumbs */}
      <nav className="flex items-center gap-1 text-sm overflow-x-auto whitespace-nowrap">
        {breadcrumbs.map((crumb, idx) => (
          <span key={crumb.id} className="flex items-center gap-1">
            {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
            <button
              onClick={() => navigateToBreadcrumb(idx)}
              className={cn(
                'hover:text-primary transition-colors px-1 py-0.5 rounded',
                idx === breadcrumbs.length - 1
                  ? 'text-foreground font-medium'
                  : 'text-muted-foreground'
              )}
            >
              {idx === 0 && <FolderOpen className="w-3.5 h-3.5 inline mr-1" />}
              {crumb.name}
            </button>
          </span>
        ))}
      </nav>

      {/* Toolbar */}
      <Card>
        <CardContent className="p-3 flex flex-row gap-2 items-center">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              className="pl-8 h-8 text-sm"
              placeholder="Search files…"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <Separator orientation="vertical" className="h-6 shrink-0" />
          {/* View toggles */}
          <div className="flex items-center gap-0.5 shrink-0">
            {([
              { mode: 'list' as ViewMode, Icon: List },
              { mode: 'grid' as ViewMode, Icon: Grid3X3 },
              { mode: 'detailed' as ViewMode, Icon: LayoutList },
            ] as const).map(({ mode, Icon }) => (
              <Button
                key={mode}
                variant="ghost"
                size="icon"
                className={cn('h-7 w-7', view === mode && 'bg-muted text-primary')}
                onClick={() => setView(mode)}
              >
                <Icon className="w-3.5 h-3.5" />
              </Button>
            ))}
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={load}>
            <RefreshCw className="w-3.5 h-3.5" />
          </Button>
        </CardContent>
      </Card>

      {/* Content */}
      {loading ? (
        <div className="space-y-2">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-12 w-full bg-muted rounded-md" />)}
        </div>
      ) : (
        <>
          {/* Folders */}
          {folders.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Folders</p>
              {view === 'grid' ? (
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  {folders.map(f => (
                    <Card
                      key={f.folder_id}
                      className="cursor-pointer hover:border-primary/50 transition-colors h-full"
                      onClick={() => navigateToFolder(f)}
                    >
                      <CardContent className="p-3 flex flex-col items-center gap-2 text-center">
                        <FolderIcon className="w-8 h-8 text-primary" />
                        <span className="text-xs font-medium text-foreground truncate w-full">{f.folder_name}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-0.5">
                  {folders.map(f => (
                    <div
                      key={f.folder_id}
                      onClick={() => navigateToFolder(f)}
                      className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted/60 cursor-pointer"
                    >
                      <FolderIcon className="w-4 h-4 text-primary shrink-0" />
                      <span className="text-sm font-medium flex-1 min-w-0 truncate">{f.folder_name}</span>
                      <ChevronDown className="w-3.5 h-3.5 text-muted-foreground rotate-[-90deg]" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Files */}
          <div className="space-y-2">
            {(folders.length > 0 || files.length > 0) && (
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Files</p>
            )}
            {files.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-16 gap-3 text-muted-foreground">
                  <FileText className="w-12 h-12 opacity-30" />
                  <p className="text-sm">No files found</p>
                  <Button onClick={() => navigate('/upload')} size="sm" className="gap-2">
                    <Plus className="w-4 h-4" /> Upload your first file
                  </Button>
                </CardContent>
              </Card>
            ) : view === 'grid' ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                {files.map(f => (
                  <Card
                    key={f.document_id}
                    className={cn(
                      'cursor-pointer hover:border-primary/50 transition-colors h-full flex flex-col',
                      selectedIds.has(f.document_id) && 'border-primary ring-1 ring-primary'
                    )}
                    onClick={() => toggleSelect(f.document_id)}
                    onDoubleClick={() => navigate(`/files/${f.document_id}`)}
                  >
                    <CardContent className="p-3 flex flex-col items-center gap-2 text-center flex-1">
                      <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center text-xs font-bold text-primary mt-1">
                        {mimeToExt(f.mime_type)}
                      </div>
                      <span className="text-xs font-medium text-foreground truncate w-full">{f.file_name}</span>
                      <span className="text-xs text-muted-foreground">{formatBytes(f.size_kb * 1024)}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm [&>div]:max-w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2.5 pl-3 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Name</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Size</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Type</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Status</th>
                        {view === 'detailed' && (
                          <>
                            <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Version</th>
                            <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Tier</th>
                          </>
                        )}
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Modified</th>
                        <th className="py-2.5 pr-3 w-10 text-xs text-muted-foreground font-medium"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {files.map(f => (
                        <tr
                          key={f.document_id}
                          className={cn(
                            'border-b border-border/50 hover:bg-muted/40 transition-colors cursor-pointer',
                            selectedIds.has(f.document_id) && 'bg-primary/5'
                          )}
                          onClick={() => toggleSelect(f.document_id)}
                        >
                          <td className="py-2.5 pl-3 pr-4">
                            <div className="flex items-center gap-2 min-w-0">
                              <div className="w-7 h-7 rounded bg-muted flex items-center justify-center text-[10px] font-bold text-primary shrink-0">
                                {mimeToExt(f.mime_type)}
                              </div>
                              <Link
                                to={`/files/${f.document_id}`}
                                className="font-medium text-foreground hover:text-primary truncate max-w-[180px]"
                                onClick={e => e.stopPropagation()}
                              >
                                {f.file_name}
                              </Link>
                            </div>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">
                            {formatBytes(f.size_kb * 1024)}
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">
                            {mimeToExt(f.mime_type)}
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant={statusBadgeVariant(f.status)} className="text-xs">
                              {f.status}
                            </Badge>
                          </td>
                          {view === 'detailed' && (
                            <>
                              <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">v{f.version}</td>
                              <td className="py-2.5 pr-4 whitespace-nowrap">
                                <Badge variant="outline" className="text-xs">{f.storage_tier}</Badge>
                              </td>
                            </>
                          )}
                          <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">
                            {formatDate(f.updated_at)}
                          </td>
                          <td className="py-2.5 pr-3">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6"
                                  onClick={e => e.stopPropagation()}
                                >
                                  <MoreVertical className="w-3.5 h-3.5" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => navigate(`/files/${f.document_id}`)}>
                                  <Eye className="w-4 h-4 mr-2" /> View details
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleArchive(f.document_id)}>
                                  <Archive className="w-4 h-4 mr-2" /> Archive
                                </DropdownMenuItem>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <DropdownMenuItem
                                      className="text-destructive focus:text-destructive"
                                      onSelect={e => e.preventDefault()}
                                    >
                                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                                    </DropdownMenuItem>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Delete file?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will soft-delete "{f.file_name}". The file can be restored from audit logs.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => handleDelete(f.document_id)}
                                        className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
          </div>
        </>
      )}
    </div>
  );
}
