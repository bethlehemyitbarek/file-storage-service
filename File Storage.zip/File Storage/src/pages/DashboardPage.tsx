import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  HardDrive, Files, Share2, Upload, Clock,
  TrendingUp, AlertTriangle, ArrowRight, FileText, TriangleAlert, X,
} from 'lucide-react';
import { filesApi, quotasApi, notificationsApi } from '@/services/api';
import { supabase } from '@/db/supabase';
import type { FileMetadata, StorageQuota, FileNotification } from '@/types';
import { formatBytes, formatDate } from '@/lib/formatters';

const QUOTA_WARN_THRESHOLD = 80; // show banner when usage ≥ 80%

export default function DashboardPage() {
  const [recentFiles, setRecentFiles] = useState<FileMetadata[]>([]);
  const [quota, setQuota] = useState<StorageQuota | null>(null);
  const [notifications, setNotifications] = useState<FileNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [quotaBannerDismissed, setQuotaBannerDismissed] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [filesRes, quotaRes, notifRes] = await Promise.allSettled([
          filesApi.list({ limit: 10, status: 'ACTIVE' }),
          quotasApi.getMe(),
          notificationsApi.list({ limit: 8, is_read: 0 }),
        ]);

        if (filesRes.status === 'fulfilled') {
          setRecentFiles(filesRes.value?.data || []);
        } else {
          // Backend unavailable — read directly from Supabase
          const { data } = await supabase
            .from('file_metadata')
            .select('*')
            .eq('is_current', 1)
            .eq('status', 'ACTIVE')
            .order('created_at', { ascending: false })
            .limit(10);
          setRecentFiles((data as FileMetadata[]) || []);
        }

        if (quotaRes.status === 'fulfilled') setQuota(quotaRes.value);
        if (notifRes.status === 'fulfilled') setNotifications(notifRes.value?.data || []);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const usedPct = quota
    ? Math.min(100, (quota.used_space_mb / quota.allocated_space_mb) * 100)
    : 0;

  const quotaColor =
    quota?.status === 'EXCEEDED_HARD' ? 'text-destructive' :
    quota?.status === 'EXCEEDED_SOFT' ? 'text-[hsl(var(--warning))]' :
    'text-[hsl(var(--success))]';

  const stats = [
    { label: 'Total Files',   value: loading ? '—' : (recentFiles.length || '0'), icon: Files, color: 'text-primary' },
    { label: 'Storage Used',  value: quota ? `${quota.used_space_mb.toFixed(0)} MB` : '—', icon: HardDrive, color: quotaColor },
    { label: 'Unread Alerts', value: loading ? '—' : notifications.length.toString(), icon: AlertTriangle, color: 'text-[hsl(var(--warning))]' },
    { label: 'Quota Usage',   value: quota ? `${usedPct.toFixed(0)}%` : '—', icon: TrendingUp, color: 'text-primary' },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Quota warning banner */}
      {!loading && !quotaBannerDismissed && usedPct >= QUOTA_WARN_THRESHOLD && (
        <div className="flex items-start gap-3 p-4 rounded-lg border border-warning/40 bg-warning/10 text-warning-foreground">
          <TriangleAlert className="w-5 h-5 text-warning shrink-0 mt-0.5" />
          <p className="flex-1 text-sm font-medium text-warning">
            Storage quota warning: you have used {usedPct.toFixed(0)}% of your allocated space.
            Upgrade or delete files to avoid service interruption.
          </p>
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0 h-6 w-6 text-warning hover:bg-warning/20 hover:text-warning"
            onClick={() => setQuotaBannerDismissed(true)}
          >
            <X className="w-3.5 h-3.5" />
            <span className="sr-only">Dismiss</span>
          </Button>
        </div>
      )}

      {/* Page header */}
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-foreground text-balance">Dashboard</h1>
        <p className="text-sm text-muted-foreground text-pretty">Overview of your file storage system</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="h-full">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`shrink-0 w-9 h-9 rounded-md bg-muted flex items-center justify-center ${color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                {loading ? (
                  <Skeleton className="h-5 w-12 mb-1 bg-muted" />
                ) : (
                  <p className={`text-xl font-bold ${color}`}>{value}</p>
                )}
                <p className="text-xs text-muted-foreground truncate">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Storage quota */}
        <Card className="md:col-span-1 h-full flex flex-col">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-primary" /> Storage Quota
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 space-y-4">
            {loading || !quota ? (
              <div className="space-y-3">
                <Skeleton className="h-3 w-full bg-muted" />
                <Skeleton className="h-4 w-2/3 bg-muted" />
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{quota.used_space_mb.toFixed(0)} MB used</span>
                    <span>{quota.allocated_space_mb.toFixed(0)} MB total</span>
                  </div>
                  <Progress value={usedPct} className="h-2" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Status</span>
                  <Badge
                    variant={quota.status === 'ACTIVE' ? 'secondary' : 'destructive'}
                    className="text-xs"
                  >
                    {quota.status}
                  </Badge>
                </div>
                {quota.status !== 'ACTIVE' && (
                  <div className="flex items-start gap-2 p-3 rounded-md bg-destructive/10 border border-destructive/20">
                    <AlertTriangle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                    <p className="text-xs text-destructive">
                      {quota.status === 'EXCEEDED_HARD'
                        ? 'Quota exceeded — uploads blocked.'
                        : 'Approaching quota limit.'}
                    </p>
                  </div>
                )}
                <Link to="/settings?tab=quota">
                  <Button variant="ghost" className="w-full justify-between text-xs h-8 mt-auto">
                    Manage quota <ArrowRight className="w-3 h-3" />
                  </Button>
                </Link>
              </>
            )}
          </CardContent>
        </Card>

        {/* Recent files */}
        <Card className="md:col-span-2 h-full flex flex-col">
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" /> Recent Files
            </CardTitle>
            <Link to="/files">
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
                View all <ArrowRight className="w-3 h-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="flex-1 min-h-0">
            {loading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Skeleton className="h-8 w-8 rounded bg-muted shrink-0" />
                    <div className="flex-1 space-y-1.5">
                      <Skeleton className="h-3 w-3/4 bg-muted" />
                      <Skeleton className="h-2.5 w-1/2 bg-muted" />
                    </div>
                  </div>
                ))}
              </div>
            ) : recentFiles.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-32 text-muted-foreground gap-2">
                <FileText className="w-8 h-8 opacity-40" />
                <p className="text-sm">No files yet</p>
                <Link to="/upload">
                  <Button size="sm" className="h-7 text-xs">Upload files</Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Name</th>
                      <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Size</th>
                      <th className="text-left py-2 text-xs text-muted-foreground font-medium whitespace-nowrap">Modified</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentFiles.map((f) => (
                      <tr key={f.document_id} className="border-b border-border/50 hover:bg-muted/40 transition-colors">
                        <td className="py-2 pr-4">
                          <Link
                            to={`/files/${f.document_id}`}
                            className="font-medium text-foreground hover:text-primary truncate max-w-[200px] block"
                          >
                            {f.file_name}
                          </Link>
                          <span className="text-xs text-muted-foreground">{f.mime_type}</span>
                        </td>
                        <td className="py-2 pr-4 whitespace-nowrap text-muted-foreground text-xs">
                          {formatBytes(f.size_kb * 1024)}
                        </td>
                        <td className="py-2 whitespace-nowrap text-muted-foreground text-xs">
                          {formatDate(f.updated_at)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Activity feed */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" /> Recent Activity
          </CardTitle>
          <Link to="/notifications">
            <Button variant="ghost" size="sm" className="h-7 text-xs gap-1">
              All alerts <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full bg-muted rounded-md" />
              ))}
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center py-8 text-muted-foreground gap-2">
              <Share2 className="w-8 h-8 opacity-40" />
              <p className="text-sm">All caught up — no unread notifications</p>
            </div>
          ) : (
            <div className="space-y-2">
              {notifications.map((n) => (
                <div
                  key={n.notification_id}
                  className="flex items-start gap-3 p-3 rounded-md bg-muted/40 border border-border/50"
                >
                  <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground text-pretty">{n.message}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{formatDate(n.created_at)}</p>
                  </div>
                  <Badge variant="secondary" className="text-xs shrink-0">
                    {n.notification_type.replace(/_/g, ' ')}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Upload Files',  to: '/upload',     icon: Upload },
          { label: 'Browse Files',  to: '/files',      icon: Files },
          { label: 'Shared Files',  to: '/shared',     icon: Share2 },
          { label: 'View Backups',  to: '/backups',    icon: HardDrive },
        ].map(({ label, to, icon: Icon }) => (
          <Link key={to} to={to}>
            <Card className="h-full cursor-pointer hover:border-primary/50 transition-colors group">
              <CardContent className="p-4 flex flex-col items-center justify-center gap-2 text-center">
                <Icon className="w-6 h-6 text-primary group-hover:scale-110 transition-transform" />
                <span className="text-xs font-medium text-foreground">{label}</span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}


