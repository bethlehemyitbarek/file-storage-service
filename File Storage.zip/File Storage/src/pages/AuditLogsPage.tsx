import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ClipboardList, Search, Download, Filter, Lock, Hash } from 'lucide-react';
import { auditLogsApi } from '@/services/api';
import type { FileAuditLog } from '@/types';
import { formatDate } from '@/lib/formatters';
import { toast } from 'sonner';
import { useDebounce } from '@/hooks/use-debounce';

const ACTION_COLORS: Record<string, string> = {
  CREATE:   'bg-[hsl(var(--success))]/10 text-[hsl(var(--success))] border-[hsl(var(--success))]/30',
  UPDATE:   'bg-primary/10 text-primary border-primary/30',
  DELETE:   'bg-destructive/10 text-destructive border-destructive/30',
  READ:     'bg-muted text-muted-foreground border-border',
  SHARE:    'bg-[hsl(var(--info))]/10 text-[hsl(var(--info))] border-[hsl(var(--info))]/30',
  DOWNLOAD: 'bg-[hsl(var(--info))]/10 text-[hsl(var(--info))] border-[hsl(var(--info))]/30',
  GRANT:    'bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))] border-[hsl(var(--warning))]/30',
  REVOKE:   'bg-destructive/10 text-destructive border-destructive/30',
  ARCHIVE:  'bg-muted text-muted-foreground border-border',
  RESTORE:  'bg-[hsl(var(--success))]/10 text-[hsl(var(--success))] border-[hsl(var(--success))]/30',
};

export default function AuditLogsPage() {
  const [logs, setLogs]         = useState<FileAuditLog[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(true);
  const [searchQ, setSearchQ]   = useState('');
  const [actionFilter, setAction] = useState('all');
  const [page, setPage]         = useState(1);
  const LIMIT = 50;

  const debouncedSearch = useDebounce(searchQ, 350);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number | undefined> = {
        limit: LIMIT,
        offset: (page - 1) * LIMIT,
      };
      if (debouncedSearch) params.search = debouncedSearch;
      if (actionFilter !== 'all') params.action = actionFilter;

      const res = await auditLogsApi.list(params);
      setLogs(res?.data || []);
      setTotal(res?.total || 0);
    } catch {
      // Backend unavailable in demo mode — show empty state silently
      setLogs([]);
      setTotal(0);
    } finally { setLoading(false); }
  }, [debouncedSearch, actionFilter, page]);

  useEffect(() => { load(); }, [load]);

  const handleExport = () => {
    const csv = [
      ['audit_id', 'action', 'actor_id', 'document_id', 'timestamp', 'ip_address', 'reason'].join(','),
      ...logs.map(l => [
        l.audit_id, l.action, l.actor_id, l.document_id || '',
        l.action_timestamp, l.ip_address || '', l.reason || '',
      ].join(',')),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-logs-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Audit log exported');
  };

  const totalPages = Math.ceil(total / LIMIT);

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Audit Logs</h1>
          <p className="text-sm text-muted-foreground text-pretty">
            Immutable audit trail with cryptographic chaining — 7-year retention
          </p>
        </div>
        <Button variant="secondary" className="gap-2 shrink-0" onClick={handleExport}>
          <Download className="w-4 h-4" /> Export CSV
        </Button>
      </div>

      {/* Integrity notice */}
      <div className="flex items-center gap-2 p-3 rounded-md bg-primary/5 border border-primary/20 text-xs text-primary">
        <Lock className="w-3.5 h-3.5 shrink-0" />
        Audit logs are append-only and cryptographically chained. No record can be modified or deleted.
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-3 flex flex-row gap-2 items-center flex-wrap">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              className="pl-8 h-8 text-sm"
              placeholder="Search actor, document ID…"
              value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-muted-foreground" />
            <Label className="text-xs text-muted-foreground whitespace-nowrap">Action</Label>
            <Select value={actionFilter} onValueChange={v => { setAction(v); setPage(1); }}>
              <SelectTrigger className="h-8 text-xs w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All actions</SelectItem>
                {['CREATE','UPDATE','DELETE','READ','SHARE','DOWNLOAD','UPLOAD','ARCHIVE','RESTORE','GRANT','REVOKE','EXPORT'].map(a => (
                  <SelectItem key={a} value={a}>{a}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <span className="text-xs text-muted-foreground shrink-0">{total.toLocaleString()} records</span>
        </CardContent>
      </Card>

      {/* Logs table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">
              {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-12 w-full bg-muted rounded-md" />)}
            </div>
          ) : logs.length === 0 ? (
            <div className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
              <ClipboardList className="w-12 h-12 opacity-20" />
              <p className="text-sm">No audit log entries found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr>
                    <th className="text-left py-2.5 pl-4 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Action</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Actor</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Document ID</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Timestamp</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">IP Address</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Role</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Reason</th>
                    <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Signature</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map(l => (
                    <tr key={l.audit_id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-2.5 pl-4 pr-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${ACTION_COLORS[l.action] || 'bg-muted text-muted-foreground border-border'}`}>
                          {l.action}
                        </span>
                      </td>
                      <td className="py-2.5 pr-4 whitespace-nowrap text-xs">{l.actor_id}</td>
                      <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground font-mono">
                        {l.document_id ? l.document_id.slice(0, 12) + '…' : '—'}
                      </td>
                      <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">
                        {formatDate(l.action_timestamp, true)}
                      </td>
                      <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{l.ip_address || '—'}</td>
                      <td className="py-2.5 pr-4 whitespace-nowrap">
                        <Badge variant="outline" className="text-[10px]">{l.viewer_role || '—'}</Badge>
                      </td>
                      <td className="py-2.5 pr-4 max-w-[120px] truncate text-xs text-muted-foreground">{l.reason || '—'}</td>
                      <td className="py-2.5 pr-4 whitespace-nowrap">
                        {l.audit_signature ? (
                          <div className="flex items-center gap-1 text-[hsl(var(--success))] text-xs">
                            <Hash className="w-3 h-3 shrink-0" />
                            <span className="font-mono">{l.audit_signature.slice(0, 8)}…</span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Page {page} of {totalPages}</span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" className="h-7 text-xs" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
              Previous
            </Button>
            <Button variant="ghost" size="sm" className="h-7 text-xs" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
