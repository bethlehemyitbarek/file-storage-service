import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Share2, Users, ArrowRight, FileText, Trash2 } from 'lucide-react';
import { permissionsApi } from '@/services/api';
import type { FilePermission } from '@/types';
import { formatDate } from '@/lib/formatters';
import { toast } from 'sonner';

export default function SharedFilesPage() {
  const navigate = useNavigate();
  const [sharedWithMe, setSharedWithMe]   = useState<FilePermission[]>([]);
  const [sharedByMe, setSharedByMe]       = useState<FilePermission[]>([]);
  const [loading, setLoading]             = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [wm, bm] = await Promise.allSettled([
        permissionsApi.sharedWithMe(),
        permissionsApi.sharedByMe(),
      ]);
      if (wm.status === 'fulfilled') setSharedWithMe(wm.value?.data || []);
      if (bm.status === 'fulfilled') setSharedByMe(bm.value?.data || []);
    } catch { toast.error('Failed to load shared files'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleRevoke = async (id: string) => {
    try {
      await permissionsApi.revoke(id, 'Revoked by owner');
      toast.success('Permission revoked');
      load();
    } catch (e: unknown) { toast.error((e as Error).message); }
  };

  const PermissionsTable = ({ items, showRevoke }: { items: FilePermission[]; showRevoke: boolean }) => (
    loading ? (
      <div className="space-y-2 p-4">
        {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-14 w-full bg-muted rounded-md" />)}
      </div>
    ) : items.length === 0 ? (
      <div className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
        <Share2 className="w-12 h-12 opacity-20" />
        <p className="text-sm">No shared files</p>
      </div>
    ) : (
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-border">
            <tr>
              <th className="text-left py-2.5 pl-4 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">File</th>
              <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">{showRevoke ? 'Shared With' : 'Shared By'}</th>
              <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Role</th>
              <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Access</th>
              <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Status</th>
              <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Expires</th>
              <th className="py-2.5 pr-4 w-10"></th>
            </tr>
          </thead>
          <tbody>
            {items.map(p => (
              <tr key={p.permission_id} className="border-b border-border/50 hover:bg-muted/40 transition-colors">
                <td className="py-2.5 pl-4 pr-4">
                  {p.document_id ? (
                    <button
                      onClick={() => navigate(`/files/${p.document_id}`)}
                      className="flex items-center gap-2 text-left hover:text-primary transition-colors min-w-0"
                    >
                      <FileText className="w-4 h-4 shrink-0 text-muted-foreground" />
                      <span className="text-sm font-medium truncate max-w-[140px]">
                        {p.file_metadata?.file_name || p.document_id?.slice(0, 12) + '…'}
                      </span>
                    </button>
                  ) : (
                    <span className="text-sm text-muted-foreground">Folder</span>
                  )}
                </td>
                <td className="py-2.5 pr-4 whitespace-nowrap text-sm">
                  {p.grantee_email || p.grantee_id?.slice(0, 12) + '…'}
                </td>
                <td className="py-2.5 pr-4 whitespace-nowrap">
                  <Badge variant={p.role === 'OWNER' ? 'default' : 'secondary'} className="text-xs">{p.role}</Badge>
                </td>
                <td className="py-2.5 pr-4 whitespace-nowrap">
                  <Badge variant="outline" className="text-xs">{p.access_level}</Badge>
                </td>
                <td className="py-2.5 pr-4 whitespace-nowrap">
                  <Badge
                    variant={p.status === 'ACTIVE' ? 'secondary' : 'destructive'}
                    className="text-xs"
                  >{p.status}</Badge>
                </td>
                <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">
                  {p.expires_at ? formatDate(p.expires_at) : 'Never'}
                </td>
                <td className="py-2.5 pr-4">
                  {showRevoke && p.status === 'ACTIVE' && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => handleRevoke(p.permission_id)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )
  );

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div>
        <h1 className="text-xl md:text-2xl font-semibold text-balance">Shared Files</h1>
        <p className="text-sm text-muted-foreground text-pretty">Files shared with you and files you have shared</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="h-full">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center shrink-0">
              <Users className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-xl font-bold text-primary">{sharedWithMe.length}</p>
              <p className="text-xs text-muted-foreground">Shared with me</p>
            </div>
          </CardContent>
        </Card>
        <Card className="h-full">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center shrink-0">
              <Share2 className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-xl font-bold text-primary">{sharedByMe.length}</p>
              <p className="text-xs text-muted-foreground">Shared by me</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="with-me">
        <TabsList className="grid grid-cols-2 w-full md:w-64">
          <TabsTrigger value="with-me" className="gap-1.5 text-xs">
            <Users className="w-3.5 h-3.5" /> Shared with me
          </TabsTrigger>
          <TabsTrigger value="by-me" className="gap-1.5 text-xs">
            <ArrowRight className="w-3.5 h-3.5" /> Shared by me
          </TabsTrigger>
        </TabsList>

        <TabsContent value="with-me" className="mt-4">
          <Card>
            <CardHeader className="pb-0 pt-3 px-4">
              <CardTitle className="text-sm font-medium">Files shared with me</CardTitle>
            </CardHeader>
            <CardContent className="p-0 mt-2">
              <PermissionsTable items={sharedWithMe} showRevoke={false} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="by-me" className="mt-4">
          <Card>
            <CardHeader className="pb-0 pt-3 px-4">
              <CardTitle className="text-sm font-medium">Files I have shared</CardTitle>
            </CardHeader>
            <CardContent className="p-0 mt-2">
              <PermissionsTable items={sharedByMe} showRevoke={true} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
