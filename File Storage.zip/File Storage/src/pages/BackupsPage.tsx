import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from '@/components/ui/dialog';
import {
  Archive, RotateCcw, Plus, CheckCircle, AlertCircle,
  Clock, Loader2, ChevronRight,
} from 'lucide-react';
import { backupsApi, restoreJobsApi } from '@/services/api';
import type { FileBackup, FileRestoreJob } from '@/types';
import { formatBytes, formatDate } from '@/lib/formatters';
import { toast } from 'sonner';

export default function BackupsPage() {
  const [backups, setBackups]       = useState<FileBackup[]>([]);
  const [restoreJobs, setRestores]  = useState<FileRestoreJob[]>([]);
  const [loading, setLoading]       = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<string>('none');

  // New backup form
  const [backupType, setBackupType]   = useState('FULL');
  const [backupScope, setBackupScope] = useState('TENANT');
  const [retentionDays, setRetention] = useState('30');
  const [creating, setCreating]       = useState(false);

  // New restore form
  const [restoreScope, setRestoreScope] = useState('SINGLE_FILE');
  const [restorePath, setRestorePath]   = useState('');
  const [restoring, setRestoring]       = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [bRes, rRes] = await Promise.allSettled([
        backupsApi.list({ limit: 50 }),
        restoreJobsApi.list({ limit: 50 }),
      ]);
      if (bRes.status === 'fulfilled') setBackups(bRes.value?.data || []);
      if (rRes.status === 'fulfilled') setRestores(rRes.value?.data || []);
    } catch { toast.error('Failed to load backups'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleCreateBackup = async () => {
    setCreating(true);
    try {
      await backupsApi.create({
        backup_type: backupType,
        backup_scope: backupScope,
        retention_days: parseInt(retentionDays),
        backup_path: `/backups/${Date.now()}`,
        file_count: 0,
        size_bytes: 0,
      });
      toast.success('Backup initiated');
      setCreateOpen(false);
      load();
    } catch {
      // Optimistic local record so UI reflects the action in demo mode
      const mockBackup: FileBackup = {
        row_id: crypto.randomUUID(),
        backup_id: crypto.randomUUID(),
        tenant_id: 'demo',
        created_by: 'demo_user',
        backup_type: backupType as FileBackup['backup_type'],
        backup_scope: backupScope as FileBackup['backup_scope'],
        retention_days: parseInt(retentionDays),
        backup_path: `/backups/${Date.now()}`,
        file_count: 0,
        size_bytes: 0,
        checksum: '',
        encryption_status: 'ENCRYPTED',
        status: 'IN_PROGRESS',
        created_at: new Date().toISOString(),
      };
      setBackups(prev => [mockBackup, ...prev]);
      toast.success('Backup queued (demo mode)');
      setCreateOpen(false);
    } finally { setCreating(false); }
  };

  const handleCreateRestore = async () => {
    if (selectedBackup === 'none') { toast.error('Select a backup first'); return; }
    setRestoring(true);
    try {
      await restoreJobsApi.create({
        backup_id: selectedBackup,
        restore_scope: restoreScope,
        restore_path: restorePath || '/restore',
      });
      toast.success('Restore job created');
      setRestoreOpen(false);
      load();
    } catch {
      const mockJob: FileRestoreJob = {
        row_id: crypto.randomUUID(),
        restore_id: crypto.randomUUID(),
        tenant_id: 'demo',
        backup_id: selectedBackup,
        restore_scope: restoreScope as FileRestoreJob['restore_scope'],
        restore_path: restorePath || '/restore',
        status: 'PENDING_APPROVAL',
        approval_status: 'PENDING',
        requested_by: 'demo_user',
        requested_at: new Date().toISOString(),
      };
      setRestores(prev => [mockJob, ...prev]);
      toast.success('Restore job queued (demo mode)');
      setRestoreOpen(false);
    } finally { setRestoring(false); }
  };

  const handleApprove = async (restoreId: string) => {
    try {
      await restoreJobsApi.approve(restoreId);
      toast.success('Restore approved');
      load();
    } catch {
      setRestores(prev => prev.map(r =>
        r.restore_id === restoreId ? { ...r, approval_status: 'APPROVED', status: 'IN_PROGRESS' } : r
      ));
      toast.success('Restore approved (demo mode)');
    }
  };

  const statusIcon = (s: string) => {
    if (s === 'SUCCESS' || s === 'COMPLETED') return <CheckCircle className="w-4 h-4 text-[hsl(var(--success))]" />;
    if (s === 'FAILED' || s === 'CANCELLED') return <AlertCircle className="w-4 h-4 text-destructive" />;
    if (s === 'IN_PROGRESS') return <Loader2 className="w-4 h-4 text-primary animate-spin" />;
    return <Clock className="w-4 h-4 text-[hsl(var(--warning))]" />;
  };

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl md:text-2xl font-semibold text-balance">Backups & Restore</h1>
          <p className="text-sm text-muted-foreground text-pretty">Manage backups and restore jobs</p>
        </div>
        <div className="flex gap-2 shrink-0">
          {/* Restore dialog */}
          <Dialog open={restoreOpen} onOpenChange={setRestoreOpen}>
            <DialogTrigger asChild>
              <Button variant="secondary" className="gap-2">
                <RotateCcw className="w-4 h-4" /> Restore
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Restore Job</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Source Backup</Label>
                  <Select value={selectedBackup} onValueChange={setSelectedBackup}>
                    <SelectTrigger><SelectValue placeholder="Select backup" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none" disabled>Select a backup…</SelectItem>
                      {backups.filter(b => b.status === 'SUCCESS').map(b => (
                        <SelectItem key={b.backup_id} value={b.backup_id}>
                          {b.backup_type} — {formatDate(b.created_at)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Restore Scope</Label>
                  <Select value={restoreScope} onValueChange={setRestoreScope}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SINGLE_FILE">Single File</SelectItem>
                      <SelectItem value="FOLDER">Folder</SelectItem>
                      <SelectItem value="TENANT">Tenant (requires approval)</SelectItem>
                      <SelectItem value="BULK">Bulk (requires approval)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Restore Path</Label>
                  <Input
                    value={restorePath}
                    onChange={e => setRestorePath(e.target.value)}
                    placeholder="/restore/target"
                    className="px-3"
                  />
                </div>
                {(restoreScope === 'TENANT' || restoreScope === 'BULK') && (
                  <div className="flex gap-2 p-3 rounded-md bg-[hsl(var(--warning))]/10 border border-[hsl(var(--warning))]/30 text-xs text-[hsl(var(--warning))]">
                    <ChevronRight className="w-4 h-4 shrink-0 mt-0.5" />
                    Large-scope restores require admin approval before execution.
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setRestoreOpen(false)}>Cancel</Button>
                <Button onClick={handleCreateRestore} disabled={restoring || selectedBackup === 'none'} className="gap-2">
                  {restoring && <Loader2 className="w-4 h-4 animate-spin" />}
                  Create Restore Job
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Create backup dialog */}
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus className="w-4 h-4" /> New Backup</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Backup</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Backup Type</Label>
                  <Select value={backupType} onValueChange={setBackupType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FULL">Full</SelectItem>
                      <SelectItem value="INCREMENTAL">Incremental</SelectItem>
                      <SelectItem value="DIFFERENTIAL">Differential</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Scope</Label>
                  <Select value={backupScope} onValueChange={setBackupScope}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TENANT">Tenant</SelectItem>
                      <SelectItem value="FOLDER">Folder</SelectItem>
                      <SelectItem value="FILE">File</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Retention Days</Label>
                  <Input
                    type="number"
                    value={retentionDays}
                    onChange={e => setRetention(e.target.value)}
                    min={1}
                    max={365}
                    className="px-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="ghost" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button onClick={handleCreateBackup} disabled={creating} className="gap-2">
                  {creating && <Loader2 className="w-4 h-4 animate-spin" />}
                  Create Backup
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="backups">
        <TabsList className="grid grid-cols-2 w-full md:w-64">
          <TabsTrigger value="backups" className="gap-1.5 text-xs">
            <Archive className="w-3.5 h-3.5" /> Backups ({backups.length})
          </TabsTrigger>
          <TabsTrigger value="restore-jobs" className="gap-1.5 text-xs">
            <RotateCcw className="w-3.5 h-3.5" /> Restore Jobs ({restoreJobs.length})
          </TabsTrigger>
        </TabsList>

        {/* Backups list */}
        <TabsContent value="backups" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-4 space-y-2">
                  {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-14 w-full bg-muted rounded-md" />)}
                </div>
              ) : backups.length === 0 ? (
                <div className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
                  <Archive className="w-12 h-12 opacity-20" />
                  <p className="text-sm">No backups yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2.5 pl-4 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Status</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Type</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Scope</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Files</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Size</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Retention</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Created</th>
                      </tr>
                    </thead>
                    <tbody>
                      {backups.map(b => (
                        <tr key={b.backup_id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2.5 pl-4 pr-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5">{statusIcon(b.status)}<span className="text-xs">{b.status}</span></div>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant="secondary" className="text-xs">{b.backup_type}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant="outline" className="text-xs">{b.backup_scope}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{b.file_count}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{formatBytes(b.size_bytes)}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{b.retention_days}d</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{formatDate(b.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Restore jobs */}
        <TabsContent value="restore-jobs" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-4 space-y-2">
                  {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-14 w-full bg-muted rounded-md" />)}
                </div>
              ) : restoreJobs.length === 0 ? (
                <div className="py-16 flex flex-col items-center gap-3 text-muted-foreground">
                  <RotateCcw className="w-12 h-12 opacity-20" />
                  <p className="text-sm">No restore jobs</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2.5 pl-4 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Status</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Scope</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Restore Path</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Approval</th>
                        <th className="text-left py-2.5 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Requested</th>
                        <th className="py-2.5 pr-4 w-20"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {restoreJobs.map(r => (
                        <tr key={r.restore_id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2.5 pl-4 pr-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5">{statusIcon(r.status)}<span className="text-xs">{r.status}</span></div>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant="secondary" className="text-xs">{r.restore_scope}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 max-w-[140px] truncate text-xs text-muted-foreground">{r.restore_path}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge
                              variant={r.approval_status === 'APPROVED' ? 'secondary' : r.approval_status === 'REJECTED' ? 'destructive' : 'outline'}
                              className="text-xs"
                            >{r.approval_status}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{formatDate(r.requested_at)}</td>
                          <td className="py-2.5 pr-4">
                            {r.approval_status === 'PENDING' && (
                              <Button
                                size="sm"
                                variant="secondary"
                                className="h-6 text-xs"
                                onClick={() => handleApprove(r.restore_id)}
                              >
                                Approve
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
