import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  ArrowLeft, FileText, GitBranch, Lock, MessageSquare,
  ClipboardList, Calendar, Save, Trash2, Plus, Send, Shield,
  Eye, ImageIcon, FileCode, AlertCircle, RefreshCw,
} from 'lucide-react';
import {
  filesApi, versionsApi, permissionsApi, auditLogsApi,
  discussionsApi, calendarEventsApi,
} from '@/services/api';
import { supabase } from '@/db/supabase';
import type {
  FileMetadata, FileVersion, FilePermission, FileAuditLog,
  FileDiscussion, FileCalendarEvent,
} from '@/types';
import { formatBytes, formatDate, mimeToExt } from '@/lib/formatters';
import { toast } from 'sonner';

// ── Preview helpers ──────────────────────────────────────────────────────────

type PreviewKind = 'pdf' | 'image' | 'text' | 'unsupported';

function getPreviewKind(mimeType: string): PreviewKind {
  if (mimeType === 'application/pdf') return 'pdf';
  if (mimeType.startsWith('image/')) return 'image';
  const textTypes = [
    'text/plain', 'text/csv', 'text/html', 'text/markdown',
    'application/json', 'text/xml', 'application/xml',
  ];
  if (textTypes.includes(mimeType) || mimeType.startsWith('text/')) return 'text';
  return 'unsupported';
}

interface FilePreviewProps {
  file: FileMetadata;
}

function FilePreview({ file }: FilePreviewProps) {
  const kind = getPreviewKind(file.mime_type);
  const [textContent, setTextContent] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);

  const loadText = useCallback(async () => {
    if (!file.storage_path) {
      setPreviewError('No storage path available for this file.');
      return;
    }
    setPreviewLoading(true);
    setPreviewError(null);
    try {
      const res = await fetch(file.storage_path);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      setTextContent(text);
    } catch (e: unknown) {
      setPreviewError(`Failed to load file content: ${(e as Error).message}`);
    } finally {
      setPreviewLoading(false);
    }
  }, [file.storage_path]);

  useEffect(() => {
    if (kind === 'text') loadText();
  }, [kind, loadText]);

  if (kind === 'unsupported') {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-20 text-muted-foreground">
        <AlertCircle className="w-12 h-12 opacity-30" />
        <p className="text-sm font-medium">Preview not available</p>
        <p className="text-xs text-center max-w-xs text-pretty">
          Preview is not supported for <span className="font-mono">{file.mime_type}</span> files.
          Download the file to view its contents.
        </p>
      </div>
    );
  }

  if (kind === 'pdf') {
    if (!file.storage_path) {
      return (
        <div className="flex flex-col items-center justify-center gap-3 py-20 text-muted-foreground">
          <AlertCircle className="w-10 h-10 opacity-30" />
          <p className="text-sm">No storage path available</p>
        </div>
      );
    }
    return (
      <div className="w-full rounded-md overflow-hidden border border-border">
        <iframe
          src={file.storage_path}
          title={file.file_name}
          className="w-full"
          style={{ height: '70vh', minHeight: 400 }}
        />
      </div>
    );
  }

  if (kind === 'image') {
    if (!file.storage_path) {
      return (
        <div className="flex flex-col items-center justify-center gap-3 py-20 text-muted-foreground">
          <ImageIcon className="w-10 h-10 opacity-30" />
          <p className="text-sm">No storage path available</p>
        </div>
      );
    }
    return (
      <div className="flex items-center justify-center w-full rounded-md border border-border bg-muted/30 overflow-hidden p-4"
        style={{ minHeight: 300 }}
      >
        <img
          src={file.storage_path}
          alt={file.file_name}
          className="max-w-full max-h-[65vh] object-contain rounded"
          onError={e => {
            (e.currentTarget as HTMLImageElement).style.display = 'none';
            setPreviewError('Failed to load image.');
          }}
        />
        {previewError && (
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <ImageIcon className="w-10 h-10 opacity-30" />
            <p className="text-sm">{previewError}</p>
          </div>
        )}
      </div>
    );
  }

  // text / code
  if (previewLoading) {
    return (
      <div className="space-y-2 p-1">
        {[...Array(12)].map((_, i) => (
          <Skeleton key={i} className="h-4 bg-muted rounded" style={{ width: `${55 + (i * 17) % 45}%` }} />
        ))}
      </div>
    );
  }

  if (previewError) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-16 text-muted-foreground">
        <AlertCircle className="w-10 h-10 opacity-30" />
        <p className="text-sm">{previewError}</p>
        <Button variant="secondary" size="sm" className="gap-2" onClick={loadText}>
          <RefreshCw className="w-3.5 h-3.5" /> Retry
        </Button>
      </div>
    );
  }

  if (textContent !== null) {
    return (
      <div className="rounded-md border border-border bg-muted/20 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2 border-b border-border bg-muted/40">
          <FileCode className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs text-muted-foreground font-mono">{file.file_name}</span>
          <span className="ml-auto text-xs text-muted-foreground">{textContent.split('\n').length} lines</span>
        </div>
        <pre className="overflow-auto p-4 text-xs font-mono text-foreground leading-relaxed"
          style={{ maxHeight: '65vh', tabSize: 2 }}
        >
          {textContent}
        </pre>
      </div>
    );
  }

  return null;
}

export default function FileDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [file, setFile] = useState<FileMetadata | null>(null);
  const [loading, setLoading] = useState(true);

  const [versions, setVersions]     = useState<FileVersion[]>([]);
  const [permissions, setPermissions] = useState<FilePermission[]>([]);
  const [auditLogs, setAuditLogs]   = useState<FileAuditLog[]>([]);
  const [discussions, setDiscussions] = useState<FileDiscussion[]>([]);
  const [events, setEvents]         = useState<FileCalendarEvent[]>([]);

  const [newMessage, setNewMessage] = useState('');
  const [editName, setEditName]     = useState('');
  const [editDesc, setEditDesc]     = useState('');
  const [saving, setSaving]         = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      let f: FileMetadata | null = null;
      try {
        f = await filesApi.getById(id);
      } catch {
        // Backend unavailable — read directly from Supabase
        const { data } = await supabase
          .from('file_metadata')
          .select('*')
          .eq('document_id', id)
          .eq('is_current', 1)
          .single();
        f = data as FileMetadata | null;
      }
      setFile(f);
      setEditName(f?.file_name || '');
      setEditDesc(f?.description || '');

      const [vRes, pRes, aRes, dRes, eRes] = await Promise.allSettled([
        versionsApi.list(id),
        permissionsApi.list({ document_id: id }),
        auditLogsApi.list({ document_id: id }),
        discussionsApi.list(id),
        calendarEventsApi.list({ document_id: id }),
      ]);
      if (vRes.status === 'fulfilled') setVersions(vRes.value?.data || []);
      if (pRes.status === 'fulfilled') setPermissions(pRes.value?.data || []);
      if (aRes.status === 'fulfilled') setAuditLogs(aRes.value?.data || []);
      if (dRes.status === 'fulfilled') setDiscussions(dRes.value?.data || []);
      if (eRes.status === 'fulfilled') setEvents(eRes.value?.data || []);
    } catch { toast.error('Failed to load file details'); }
    finally { setLoading(false); }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  const handleSaveMeta = async () => {
    if (!id) return;
    setSaving(true);
    try {
      await filesApi.update(id, { file_name: editName, description: editDesc });
      toast.success('Metadata saved');
      load();
    } catch {
      // Backend unavailable — update directly in Supabase
      await supabase.from('file_metadata')
        .update({ file_name: editName, description: editDesc, updated_at: new Date().toISOString() })
        .eq('document_id', id);
      setFile(prev => prev ? { ...prev, file_name: editName, description: editDesc } : prev);
      toast.success('Metadata saved');
    } finally { setSaving(false); }
  };

  const handlePostDiscussion = async () => {
    if (!id || !newMessage.trim()) return;
    try {
      await discussionsApi.create(id, { message_text: newMessage });
      setNewMessage('');
      toast.success('Comment posted');
      const d = await discussionsApi.list(id);
      setDiscussions(d?.data || []);
    } catch {
      // Optimistic local add
      const mock: FileDiscussion = {
        row_id: crypto.randomUUID(),
        discussion_id: crypto.randomUUID(),
        document_id: id,
        tenant_id: '00000000-0000-0000-0000-000000000001',
        user_id: '00000000-0000-0000-0000-000000000002',
        message_text: newMessage,
        thread_depth: 0,
        status: 'ACTIVE' as FileDiscussion['status'],
        is_edited: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setDiscussions(prev => [...prev, mock]);
      setNewMessage('');
      toast.success('Comment posted (demo mode)');
    }
  };

  const handleRevokePermission = async (permId: string) => {
    try {
      await permissionsApi.revoke(permId);
      toast.success('Permission revoked');
      const p = await permissionsApi.list({ document_id: id });
      setPermissions(p?.data || []);
    } catch {
      setPermissions(prev => prev.filter(p => p.permission_id !== permId));
      toast.success('Permission revoked');
    }
  };

  if (loading) {
    return (
      <div className="p-4 md:p-6 space-y-4">
        <Skeleton className="h-8 w-48 bg-muted" />
        <Skeleton className="h-32 w-full bg-muted rounded-xl" />
        <Skeleton className="h-64 w-full bg-muted rounded-xl" />
      </div>
    );
  }

  if (!file) {
    return (
      <div className="p-4 md:p-6 flex flex-col items-center gap-4 py-24">
        <FileText className="w-12 h-12 text-muted-foreground opacity-40" />
        <p className="text-muted-foreground">File not found</p>
        <Button onClick={() => navigate('/files')} variant="secondary">Back to files</Button>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-4">
      {/* Header */}
      <div className="flex items-start gap-3">
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0 mt-0.5" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="w-8 h-8 rounded-md bg-muted flex items-center justify-center text-[11px] font-bold text-primary shrink-0">
              {mimeToExt(file.mime_type)}
            </div>
            <h1 className="text-lg md:text-xl font-semibold text-balance truncate">{file.file_name}</h1>
            <Badge variant={file.status === 'ACTIVE' ? 'secondary' : 'outline'}>{file.status}</Badge>
            <Badge variant="outline" className="text-xs">v{file.version}</Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5 text-pretty">
            {formatBytes(file.size_kb * 1024)} · {file.mime_type} · Modified {formatDate(file.updated_at)}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="metadata">
        <TabsList className="grid grid-cols-4 md:grid-cols-7 h-auto gap-0.5">
          <TabsTrigger value="metadata"    className="gap-1.5 text-xs"><FileText className="w-3.5 h-3.5" /><span className="hidden md:inline">Metadata</span></TabsTrigger>
          <TabsTrigger value="preview"     className="gap-1.5 text-xs"><Eye className="w-3.5 h-3.5" /><span className="hidden md:inline">Preview</span></TabsTrigger>
          <TabsTrigger value="versions"    className="gap-1.5 text-xs"><GitBranch className="w-3.5 h-3.5" /><span className="hidden md:inline">Versions</span></TabsTrigger>
          <TabsTrigger value="permissions" className="gap-1.5 text-xs"><Lock className="w-3.5 h-3.5" /><span className="hidden md:inline">Permissions</span></TabsTrigger>
          <TabsTrigger value="discussions" className="gap-1.5 text-xs"><MessageSquare className="w-3.5 h-3.5" /><span className="hidden md:inline">Discussions</span></TabsTrigger>
          <TabsTrigger value="audit"       className="gap-1.5 text-xs"><ClipboardList className="w-3.5 h-3.5" /><span className="hidden md:inline">Audit Log</span></TabsTrigger>
          <TabsTrigger value="calendar"    className="gap-1.5 text-xs"><Calendar className="w-3.5 h-3.5" /><span className="hidden md:inline">Calendar</span></TabsTrigger>
        </TabsList>

        {/* ── METADATA ── */}
        <TabsContent value="metadata" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">File Metadata</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="fname" className="text-sm font-normal">File Name</Label>
                  <Input id="fname" value={editName} onChange={e => setEditName(e.target.value)} className="px-3" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">MIME Type</Label>
                  <Input value={file.mime_type} readOnly className="px-3 bg-muted/50" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Description</Label>
                  <Textarea
                    value={editDesc}
                    onChange={e => setEditDesc(e.target.value)}
                    rows={3}
                    className="px-3"
                    placeholder="Add a description…"
                  />
                </div>
                <div className="space-y-3">
                  {[
                    ['Document ID', file.document_id],
                    ['Size', formatBytes(file.size_kb * 1024)],
                    ['Storage Tier', file.storage_tier],
                    ['Encryption', file.encryption_status],
                    ['Checksum (SHA-256)', file.checksum?.slice(0, 20) + '…'],
                    ['Effective From', formatDate(file.effective_from, true)],
                    ['Effective To', formatDate(file.effective_to, true)],
                  ].map(([k, v]) => (
                    <div key={k} className="flex items-start justify-between gap-2 text-sm">
                      <span className="text-muted-foreground shrink-0">{k}</span>
                      <span className="text-foreground text-right break-all">{v}</span>
                    </div>
                  ))}
                </div>
              </div>
              {file.tags && Array.isArray(file.tags) && file.tags.length > 0 && (
                <div className="space-y-1.5">
                  <Label className="text-sm font-normal">Tags</Label>
                  <div className="flex flex-wrap gap-1.5">
                    {(file.tags as Array<{ name: string; category: string }>).map((t, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">{t.name}</Badge>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex gap-2 pt-2">
                <Button onClick={handleSaveMeta} disabled={saving} className="gap-2">
                  <Save className="w-4 h-4" /> {saving ? 'Saving…' : 'Save Changes'}
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" className="gap-2 border border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive">
                      <Trash2 className="w-4 h-4" /> Delete
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete this file?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will soft-delete "{file.file_name}". All versions and audit logs are preserved.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={async () => {
                          await filesApi.delete(id!);
                          toast.success('File deleted');
                          navigate('/files');
                        }}
                        className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                      >Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── PREVIEW ── */}
        <TabsContent value="preview" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Eye className="w-4 h-4 text-muted-foreground" />
                File Preview
                <Badge variant="outline" className="text-xs font-mono ml-1">{file.mime_type}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <FilePreview file={file} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── VERSIONS ── */}
        <TabsContent value="versions" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Version History ({versions.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {versions.length === 0 ? (
                <div className="py-12 text-center text-muted-foreground">
                  <GitBranch className="w-10 h-10 mx-auto opacity-30 mb-2" />
                  <p className="text-sm">No version history yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Version</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Size</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Summary</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Created</th>
                        <th className="text-left py-2 text-xs text-muted-foreground font-medium whitespace-nowrap">Tier</th>
                      </tr>
                    </thead>
                    <tbody>
                      {versions.map(v => (
                        <tr key={v.version_id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2.5 pr-4 whitespace-nowrap font-medium">v{v.version_number}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">{formatBytes(v.size_kb * 1024)}</td>
                          <td className="py-2.5 pr-4 max-w-[200px] truncate text-muted-foreground text-xs">{v.change_summary || '—'}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-muted-foreground text-xs">{formatDate(v.created_at)}</td>
                          <td className="py-2.5">
                            <Badge variant="outline" className="text-xs">{v.storage_tier}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── PERMISSIONS ── */}
        <TabsContent value="permissions" className="mt-4">
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium">Access Control ({permissions.length})</CardTitle>
              <Button size="sm" className="gap-2 h-7 text-xs" onClick={() => navigate(`/files/${id}/share`)}>
                <Plus className="w-3.5 h-3.5" /> Grant Access
              </Button>
            </CardHeader>
            <CardContent>
              {permissions.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <Shield className="w-10 h-10 mx-auto opacity-30 mb-2" />
                  <p className="text-sm">No permissions configured</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Grantee</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Type</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Role</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Status</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Expires</th>
                        <th className="py-2 w-10"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {permissions.map(p => (
                        <tr key={p.permission_id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2.5 pr-4 whitespace-nowrap">{p.grantee_email || p.grantee_id}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant="secondary" className="text-xs">{p.grantee_type}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant={p.role === 'OWNER' ? 'default' : 'outline'} className="text-xs">{p.role}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge
                              variant={p.status === 'ACTIVE' ? 'secondary' : 'destructive'}
                              className="text-xs"
                            >{p.status}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">
                            {p.expires_at ? formatDate(p.expires_at) : 'Never'}
                          </td>
                          <td className="py-2.5">
                            {p.status === 'ACTIVE' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/10"
                                onClick={() => handleRevokePermission(p.permission_id)}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── DISCUSSIONS ── */}
        <TabsContent value="discussions" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Discussions ({discussions.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* New comment */}
              <div className="flex gap-2">
                <Textarea
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder="Write a comment…"
                  rows={2}
                  className="flex-1 px-3 text-sm"
                />
                <Button onClick={handlePostDiscussion} className="shrink-0 gap-2" disabled={!newMessage.trim()}>
                  <Send className="w-4 h-4" />
                  <span className="sr-only md:not-sr-only">Post</span>
                </Button>
              </div>
              <Separator />
              {discussions.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground">
                  <MessageSquare className="w-10 h-10 mx-auto opacity-30 mb-2" />
                  <p className="text-sm">No comments yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {discussions.map(d => (
                    <div key={d.discussion_id} className="flex gap-3">
                      <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium text-primary shrink-0 mt-0.5">
                        {d.user_id.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-medium text-foreground">{d.user_id}</span>
                          <span className="text-xs text-muted-foreground">{formatDate(d.created_at)}</span>
                          {d.is_edited === 1 && <span className="text-xs text-muted-foreground">(edited)</span>}
                        </div>
                        <p className="text-sm text-foreground text-pretty">{d.message_text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── AUDIT LOG ── */}
        <TabsContent value="audit" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Audit Trail ({auditLogs.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {auditLogs.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <ClipboardList className="w-10 h-10 mx-auto opacity-30 mb-2" />
                  <p className="text-sm">No audit events yet</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Action</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Actor</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">Timestamp</th>
                        <th className="text-left py-2 pr-4 text-xs text-muted-foreground font-medium whitespace-nowrap">IP</th>
                        <th className="text-left py-2 text-xs text-muted-foreground font-medium whitespace-nowrap">Reason</th>
                      </tr>
                    </thead>
                    <tbody>
                      {auditLogs.map(a => (
                        <tr key={a.audit_id} className="border-b border-border/50 hover:bg-muted/30">
                          <td className="py-2.5 pr-4 whitespace-nowrap">
                            <Badge variant="secondary" className="text-xs">{a.action}</Badge>
                          </td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{a.actor_id}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{formatDate(a.action_timestamp, true)}</td>
                          <td className="py-2.5 pr-4 whitespace-nowrap text-xs text-muted-foreground">{a.ip_address || '—'}</td>
                          <td className="py-2.5 max-w-[150px] truncate text-xs text-muted-foreground">{a.reason || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── CALENDAR ── */}
        <TabsContent value="calendar" className="mt-4">
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-sm font-medium">Calendar Events ({events.length})</CardTitle>
              <Button size="sm" className="gap-2 h-7 text-xs" onClick={async () => {
                try {
                  await calendarEventsApi.create({
                    document_id: id,
                    event_title: `Event for ${file.file_name}`,
                    event_date: new Date().toISOString().split('T')[0],
                    importance_level: 'MEDIUM',
                  });
                  toast.success('Event created');
                  const e = await calendarEventsApi.list({ document_id: id });
                  setEvents(e?.data || []);
                } catch (err: unknown) { toast.error((err as Error).message); }
              }}>
                <Plus className="w-3.5 h-3.5" /> Add Event
              </Button>
            </CardHeader>
            <CardContent>
              {events.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground">
                  <Calendar className="w-10 h-10 mx-auto opacity-30 mb-2" />
                  <p className="text-sm">No calendar events</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {events.map(e => (
                    <div key={e.event_id} className="flex items-start gap-3 p-3 rounded-md bg-muted/40 border border-border/50">
                      <div
                        className="w-3 h-3 rounded-full shrink-0 mt-1"
                        style={{ background: e.color_code || 'hsl(var(--primary))' }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground">{e.event_title}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(e.event_date, true)}</p>
                        {e.event_description && (
                          <p className="text-xs text-muted-foreground mt-0.5 text-pretty">{e.event_description}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <Badge variant="outline" className="text-xs">{e.importance_level}</Badge>
                        <Badge variant="secondary" className="text-xs">{e.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
