import { useEffect, useState, useRef } from 'react';
import { notificationsApi } from '@/services/api';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';

const FALLBACK_POLL_MS = 5 * 60 * 1000; // 5 min fallback if Realtime fails

// Ref-guard state shape — extends a plain mutable object so no useRef needed
type MountGuard = {
  current: boolean;
  channel?: ReturnType<typeof supabase.channel>;
};

export type ConnectionStatus = 'unknown' | 'connected' | 'degraded';

export function useNotificationCount(): { count: number; connectionStatus: ConnectionStatus } {
  const { user } = useAuth();
  const [count, setCount] = useState(0);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('unknown');
  const fallbackRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    // Ref-guard: set true on entry, false in cleanup.
    // A microtask delay ensures the Strict Mode double-invoke cleanup fires
    // BEFORE the channel is ever created, so we never subscribe twice.
    const mountedRef: MountGuard = { current: true };

    let fetchCancelled = false;

    const fetchCount = async () => {
      try {
        const n = await notificationsApi.unreadCount();
        if (!fetchCancelled) setCount(n ?? 0);
      } catch {
        // non-critical — badge stays at last known value
      }
    };

    fetchCount();

    // Defer channel creation to next microtask so Strict Mode cleanup
    // (which runs synchronously before the second mount) can set mountedRef.current = false.
    Promise.resolve().then(() => {
      if (!mountedRef.current) return; // cleanup already ran — do not subscribe

      const channelName = `notification-count:${user?.id ?? 'anon'}:${crypto.randomUUID()}`;
      const channel = supabase
        .channel(channelName)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'file_notifications',
            filter: user?.id ? `user_id=eq.${user.id}` : undefined,
          },
          (payload) => {
            if (payload.new && (payload.new as { is_read?: number }).is_read === 0) {
              setCount(prev => prev + 1);
            }
          }
        )
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') {
            setConnectionStatus('connected');
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            setConnectionStatus('degraded');
            if (!fallbackRef.current) {
              fallbackRef.current = setInterval(fetchCount, FALLBACK_POLL_MS);
            }
          }
        });

      mountedRef.channel = channel;
    });

    return () => {
      mountedRef.current = false;
      fetchCancelled = true;
      if (mountedRef.channel) {
        supabase.removeChannel(mountedRef.channel);
        mountedRef.channel = undefined;
      }
      if (fallbackRef.current) {
        clearInterval(fallbackRef.current);
        fallbackRef.current = null;
      }
    };
  }, [user?.id]);

  return { count, connectionStatus };
}
