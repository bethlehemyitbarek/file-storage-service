import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api/v1';
const DEFAULT_TENANT_ID = import.meta.env.VITE_DEFAULT_TENANT_ID || 'default_tenant';
const DEFAULT_USER_ID = import.meta.env.VITE_DEFAULT_USER_ID || 'demo_user_001';

export const apiClient = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
    'x-tenant-id': DEFAULT_TENANT_ID,
    'x-user-id': DEFAULT_USER_ID,
  },
  timeout: 30000,
});

// Request interceptor for auth token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.error || error.message || 'Request failed';
    return Promise.reject(new Error(message));
  }
);

export const setTenantId = (tenantId: string) => {
  apiClient.defaults.headers['x-tenant-id'] = tenantId;
};

export const setUserId = (userId: string) => {
  apiClient.defaults.headers['x-user-id'] = userId;
};

export default apiClient;
