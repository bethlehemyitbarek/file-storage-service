import type { ReactNode } from 'react';
import AppLayout from '@/components/layouts/AppLayout';
import DashboardPage from './pages/DashboardPage';
import FileBrowserPage from './pages/FileBrowserPage';
import FileDetailPage from './pages/FileDetailPage';
import UploadPage from './pages/UploadPage';
import SearchPage from './pages/SearchPage';
import SharedFilesPage from './pages/SharedFilesPage';
import BackupsPage from './pages/BackupsPage';
import AuditLogsPage from './pages/AuditLogsPage';
import SettingsPage from './pages/SettingsPage';
import NotificationsPage from './pages/NotificationsPage';

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  /** Accessible without login. Routes without this flag require authentication. */
  public?: boolean;
}

const wrap = (el: ReactNode) => <AppLayout>{el}</AppLayout>;

export const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: wrap(<DashboardPage />),
  },
  {
    name: 'File Browser',
    path: '/files',
    element: wrap(<FileBrowserPage />),
  },
  {
    name: 'File Detail',
    path: '/files/:id',
    element: wrap(<FileDetailPage />),
  },
  {
    name: 'Upload',
    path: '/upload',
    element: wrap(<UploadPage />),
  },
  {
    name: 'Search',
    path: '/search',
    element: wrap(<SearchPage />),
  },
  {
    name: 'Shared Files',
    path: '/shared',
    element: wrap(<SharedFilesPage />),
  },
  {
    name: 'Backups',
    path: '/backups',
    element: wrap(<BackupsPage />),
  },
  {
    name: 'Audit Logs',
    path: '/audit-logs',
    element: wrap(<AuditLogsPage />),
  },
  {
    name: 'Settings',
    path: '/settings',
    element: wrap(<SettingsPage />),
  },
  {
    name: 'Notifications',
    path: '/notifications',
    element: wrap(<NotificationsPage />),
  },
];
