// global types

// Global BMapGL type declaration
/// <reference types="bmapgl" />
