import api from '@/lib/apiClient';
import type { FileMetadata, ApiListResponse, ApiResponse } from '@/types';

export const filesApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get<ApiListResponse<FileMetadata>>('/files', { params }).then(r => r.data),

  getById: (id: string) =>
    api.get<ApiResponse<FileMetadata>>(`/files/${id}`).then(r => r.data.data),

  create: (data: FormData | Record<string, unknown>) =>
    api.post<ApiResponse<FileMetadata>>('/files', data).then(r => r.data.data),

  update: (id: string, data: Record<string, unknown>) =>
    api.put<ApiResponse<FileMetadata>>(`/files/${id}`, data).then(r => r.data.data),

  delete: (id: string) =>
    api.delete(`/files/${id}`).then(r => r.data),

  archive: (id: string) =>
    api.post(`/files/${id}/archive`).then(r => r.data),

  restore: (id: string) =>
    api.post(`/files/${id}/restore`).then(r => r.data),

  getHistory: (id: string) =>
    api.get<ApiResponse<FileMetadata[]>>(`/files/${id}/history`).then(r => r.data.data),

  getAsOf: (id: string, asOf: string) =>
    api.get<ApiResponse<FileMetadata>>(`/files/${id}/as-of`, { params: { as_of: asOf } }).then(r => r.data.data),
};

export const foldersApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get('/folders', { params }).then(r => r.data),

  getById: (id: string) =>
    api.get(`/folders/${id}`).then(r => r.data.data),

  create: (data: Record<string, unknown>) =>
    api.post('/folders', data).then(r => r.data.data),

  update: (id: string, data: Record<string, unknown>) =>
    api.put(`/folders/${id}`, data).then(r => r.data.data),

  delete: (id: string) =>
    api.delete(`/folders/${id}`).then(r => r.data),

  getFiles: (id: string, params?: Record<string, string | number>) =>
    api.get(`/folders/${id}/files`, { params }).then(r => r.data),

  addFile: (folderId: string, documentId: string) =>
    api.post(`/folders/${folderId}/files`, { document_id: documentId }).then(r => r.data.data),

  removeFile: (folderId: string, documentId: string) =>
    api.delete(`/folders/${folderId}/files/${documentId}`).then(r => r.data),
};

export const versionsApi = {
  list: (documentId: string, params?: Record<string, string | number>) =>
    api.get(`/files/${documentId}/versions`, { params }).then(r => r.data),

  getByNumber: (documentId: string, versionNumber: number) =>
    api.get(`/files/${documentId}/versions/${versionNumber}`).then(r => r.data.data),
};

export const permissionsApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get('/permissions', { params }).then(r => r.data),

  grant: (data: Record<string, unknown>) =>
    api.post('/permissions', data).then(r => r.data.data),

  revoke: (id: string, reason?: string) =>
    api.delete(`/permissions/${id}`, { data: { revocation_reason: reason } }).then(r => r.data),

  sharedWithMe: (params?: Record<string, string | number>) =>
    api.get('/permissions/shared-with-me', { params }).then(r => r.data),

  sharedByMe: (params?: Record<string, string | number>) =>
    api.get('/permissions/shared-by-me', { params }).then(r => r.data),
};

export const auditLogsApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get('/audit-logs', { params }).then(r => r.data),

  create: (data: Record<string, unknown>) =>
    api.post('/audit-logs', data).then(r => r.data.data),
};

export const backupsApi = {
  list: (params?: Record<string, string | number>) =>
    api.get('/backups', { params }).then(r => r.data),

  getById: (id: string) =>
    api.get(`/backups/${id}`).then(r => r.data.data),

  create: (data: Record<string, unknown>) =>
    api.post('/backups', data).then(r => r.data.data),

  updateStatus: (id: string, status: string, failure_reason?: string) =>
    api.patch(`/backups/${id}/status`, { status, failure_reason }).then(r => r.data.data),
};

export const restoreJobsApi = {
  list: (params?: Record<string, string | number>) =>
    api.get('/restore-jobs', { params }).then(r => r.data),

  getById: (id: string) =>
    api.get(`/restore-jobs/${id}`).then(r => r.data.data),

  create: (data: Record<string, unknown>) =>
    api.post('/restore-jobs', data).then(r => r.data.data),

  approve: (id: string) =>
    api.post(`/restore-jobs/${id}/approve`).then(r => r.data.data),

  updateStatus: (id: string, status: string, failure_reason?: string) =>
    api.patch(`/restore-jobs/${id}/status`, { status, failure_reason }).then(r => r.data.data),
};

export const quotasApi = {
  list: (params?: Record<string, string | number>) =>
    api.get('/quotas', { params }).then(r => r.data),

  getMe: () =>
    api.get('/quotas/me').then(r => r.data.data),

  update: (id: string, data: Record<string, unknown>) =>
    api.put(`/quotas/${id}`, data).then(r => r.data.data),
};

export const calendarEventsApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get('/calendar-events', { params }).then(r => r.data),

  create: (data: Record<string, unknown>) =>
    api.post('/calendar-events', data).then(r => r.data.data),

  update: (id: string, data: Record<string, unknown>) =>
    api.put(`/calendar-events/${id}`, data).then(r => r.data.data),

  delete: (id: string) =>
    api.delete(`/calendar-events/${id}`).then(r => r.data),
};

export const discussionsApi = {
  list: (documentId: string, params?: Record<string, string | number>) =>
    api.get(`/files/${documentId}/discussions`, { params }).then(r => r.data),

  create: (documentId: string, data: Record<string, unknown>) =>
    api.post(`/files/${documentId}/discussions`, data).then(r => r.data.data),

  getReplies: (documentId: string, discussionId: string) =>
    api.get(`/files/${documentId}/discussions/${discussionId}/replies`).then(r => r.data.data),

  update: (documentId: string, id: string, message_text: string) =>
    api.put(`/files/${documentId}/discussions/${id}`, { message_text }).then(r => r.data.data),

  delete: (documentId: string, id: string) =>
    api.delete(`/files/${documentId}/discussions/${id}`).then(r => r.data),
};

export const notificationsApi = {
  list: (params?: Record<string, string | number | undefined>) =>
    api.get('/notifications', { params }).then(r => r.data),

  unreadCount: () =>
    api.get('/notifications/unread-count').then(r => r.data.data.count as number),

  markRead: (id: string) =>
    api.patch(`/notifications/${id}/read`).then(r => r.data.data),

  markAllRead: () =>
    api.post('/notifications/mark-all-read').then(r => r.data),
};

export const preferencesApi = {
  get: () =>
    api.get('/preferences').then(r => r.data.data),

  update: (data: Record<string, unknown>) =>
    api.put('/preferences', data).then(r => r.data.data),
};

export const fileRequestsApi = {
  list: (params?: Record<string, string | number>) =>
    api.get('/files/requests', { params }).then(r => r.data),

  create: (data: Record<string, unknown>) =>
    api.post('/files/requests', data).then(r => r.data.data),
};

export const uploadSessionsApi = {
  list: (params?: Record<string, string | number>) =>
    api.get('/upload-sessions', { params }).then(r => r.data),

  create: (data: Record<string, unknown>) =>
    api.post('/upload-sessions', data).then(r => r.data.data),

  getById: (id: string) =>
    api.get(`/upload-sessions/${id}`).then(r => r.data.data),

  update: (id: string, data: Record<string, unknown>) =>
    api.patch(`/upload-sessions/${id}`, data).then(r => r.data.data),

  resume: (id: string, bytes_uploaded: number) =>
    api.post(`/upload-sessions/${id}/resume`, { bytes_uploaded }).then(r => r.data.data),
};
