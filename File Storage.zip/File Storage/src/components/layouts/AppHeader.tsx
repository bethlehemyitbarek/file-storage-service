import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Menu, Bell, Search, User, LogOut, Settings, HardDrive,
  LayoutDashboard, FolderOpen, Upload, Share2, Archive,
  ClipboardList, Database, Sun, Moon, WifiOff,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNotificationCount } from '@/hooks/useNotificationCount';
import { useTheme } from '@/hooks/useTheme';

const navItems = [
  { path: '/',              label: 'Dashboard',    icon: LayoutDashboard },
  { path: '/files',         label: 'File Browser', icon: FolderOpen },
  { path: '/upload',        label: 'Upload',        icon: Upload },
  { path: '/search',        label: 'Search',        icon: Search },
  { path: '/shared',        label: 'Shared Files',  icon: Share2 },
  { path: '/backups',       label: 'Backups',        icon: Archive },
  { path: '/audit-logs',    label: 'Audit Logs',    icon: ClipboardList },
  { path: '/notifications', label: 'Notifications', icon: Bell, badge: true },
  { path: '/settings',      label: 'Settings',      icon: Settings },
];

export default function AppHeader() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { count: unreadCount, connectionStatus } = useNotificationCount();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { theme, toggle: toggleTheme } = useTheme();
  const prevStatusRef = useRef(connectionStatus);
  const prevCountRef = useRef(unreadCount);
  const [badgeBounce, setBadgeBounce] = useState(false);

  // Toast when Realtime recovers from degraded → connected
  useEffect(() => {
    if (prevStatusRef.current === 'degraded' && connectionStatus === 'connected') {
      toast.success('Notifications reconnected');
    }
    prevStatusRef.current = connectionStatus;
  }, [connectionStatus]);

  // Trigger scale-bounce when unread count increases
  useEffect(() => {
    if (unreadCount > prevCountRef.current) {
      setBadgeBounce(true);
    }
    prevCountRef.current = unreadCount;
  }, [unreadCount]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-background/95 backdrop-blur px-4 md:px-6">
      {/* Mobile hamburger */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden shrink-0">
            <Menu className="w-5 h-5" />
            <span className="sr-only">Open menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0 bg-sidebar">
          <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
            <div className="w-8 h-8 rounded-md bg-sidebar-primary flex items-center justify-center shrink-0">
              <HardDrive className="w-4 h-4 text-sidebar-primary-foreground" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-semibold text-sidebar-foreground">FileVault</p>
              <p className="text-xs text-sidebar-foreground/50">Enterprise Storage</p>
            </div>
          </div>
          <nav className="px-3 py-4 space-y-0.5">
            {navItems.map(({ path, label, icon: Icon, badge }) => {
              const active = path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);
              return (
                <Link
                  key={path}
                  to={path}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors min-h-12',
                    active
                      ? 'bg-sidebar-accent text-sidebar-primary'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  )}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="flex-1 min-w-0 truncate">{label}</span>
                  {badge && unreadCount > 0 && (
                    <Badge className="bg-sidebar-primary text-sidebar-primary-foreground text-xs px-1.5 py-0 h-5 shrink-0">
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </Badge>
                  )}
                </Link>
              );
            })}
          </nav>
          <div className="px-4 py-4 border-t border-sidebar-border">
            <div className="flex items-center gap-2 mb-2">
              <Database className="w-3.5 h-3.5 text-sidebar-foreground/50" />
              <span className="text-xs text-sidebar-foreground/60">Storage Used</span>
            </div>
            <div className="h-1.5 bg-sidebar-border rounded-full overflow-hidden">
              <div className="h-full w-2/3 bg-sidebar-primary rounded-full" />
            </div>
            <p className="mt-1.5 text-xs text-sidebar-foreground/50">6.8 GB / 10 GB</p>
          </div>
        </SheetContent>
      </Sheet>

      {/* Brand - mobile only */}
      <div className="flex items-center gap-2 lg:hidden">
        <HardDrive className="w-5 h-5 text-primary" />
        <span className="font-semibold text-sm">FileVault</span>
      </div>

      <div className="flex-1" />

      {/* Quick search */}
      <Button
        variant="ghost"
        size="icon"
        className="shrink-0"
        onClick={() => navigate('/search')}
      >
        <Search className="w-4 h-4" />
        <span className="sr-only">Search</span>
      </Button>

      {/* Theme toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="shrink-0"
        onClick={toggleTheme}
        title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {theme === 'dark'
          ? <Sun className="w-4 h-4" />
          : <Moon className="w-4 h-4" />
        }
        <span className="sr-only">Toggle theme</span>
      </Button>

      {/* Notifications */}
      <div className="relative shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="relative"
          onClick={() => navigate('/notifications')}
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <Badge
              className={cn(
                'absolute -top-1 -right-1 min-w-[1.125rem] h-[1.125rem] px-1 flex items-center justify-center text-[10px] font-semibold bg-primary text-primary-foreground leading-none pointer-events-none',
                badgeBounce && 'badge-bounce'
              )}
              onAnimationEnd={() => setBadgeBounce(false)}
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
          <span className="sr-only">Notifications</span>
        </Button>
        {/* Degraded connection indicator — uses design token text-warning */}
        {connectionStatus === 'degraded' && (
          <span
            className="absolute -bottom-0.5 -right-0.5 flex items-center justify-center w-4 h-4 rounded-full bg-background"
            title="Notifications delayed — reconnecting"
          >
            <WifiOff className="w-2.5 h-2.5 text-warning" />
          </span>
        )}
      </div>

      {/* User menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="shrink-0">
            <User className="w-4 h-4" />
            <span className="sr-only">User menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>
            <p className="text-sm font-medium">{user?.name || 'Guest'}</p>
            <p className="text-xs text-muted-foreground font-normal">{user?.email}</p>
            <Badge variant="secondary" className="mt-1 text-xs">{user?.role}</Badge>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => navigate('/settings')}>
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
            <LogOut className="w-4 h-4 mr-2" />
            Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
