import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, FolderOpen, Upload, Search, Share2,
  Archive, ClipboardList, Settings, Bell, Database,
  ChevronRight, HardDrive,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useNotificationCount } from '@/hooks/useNotificationCount';

const navItems = [
  { path: '/',              label: 'Dashboard',    icon: LayoutDashboard },
  { path: '/files',         label: 'File Browser', icon: FolderOpen },
  { path: '/upload',        label: 'Upload',        icon: Upload },
  { path: '/search',        label: 'Search',        icon: Search },
  { path: '/shared',        label: 'Shared Files',  icon: Share2 },
  { path: '/backups',       label: 'Backups',        icon: Archive },
  { path: '/audit-logs',    label: 'Audit Logs',    icon: ClipboardList },
  { path: '/notifications', label: 'Notifications', icon: Bell, badge: true },
  { path: '/settings',      label: 'Settings',      icon: Settings },
];

export default function AppSidebar() {
  const location = useLocation();
  const { count: unreadCount } = useNotificationCount();

  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 bg-sidebar border-r border-sidebar-border min-h-screen">
      {/* Brand */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-md bg-sidebar-primary flex items-center justify-center shrink-0">
          <HardDrive className="w-4 h-4 text-sidebar-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-sidebar-foreground truncate">FileVault</p>
          <p className="text-xs text-sidebar-foreground/50 truncate">Enterprise Storage</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        <p className="px-2 mb-2 text-xs font-medium text-sidebar-foreground/40 uppercase tracking-wider">Main Menu</p>
        {navItems.map(({ path, label, icon: Icon, badge }) => {
          const active = path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);
          return (
            <Link
              key={path}
              to={path}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors group',
                active
                  ? 'bg-sidebar-accent text-sidebar-primary'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1 min-w-0 truncate">{label}</span>
              {badge && unreadCount > 0 && (
                <Badge className="bg-sidebar-primary text-sidebar-primary-foreground text-xs px-1.5 py-0 h-5 shrink-0">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </Badge>
              )}
              {active && <ChevronRight className="w-3 h-3 shrink-0 opacity-60" />}
            </Link>
          );
        })}
      </nav>

      {/* Storage indicator */}
      <div className="px-4 py-4 border-t border-sidebar-border">
        <div className="flex items-center gap-2 mb-2">
          <Database className="w-3.5 h-3.5 text-sidebar-foreground/50" />
          <span className="text-xs text-sidebar-foreground/60">Storage Used</span>
        </div>
        <div className="h-1.5 bg-sidebar-border rounded-full overflow-hidden">
          <div className="h-full w-2/3 bg-sidebar-primary rounded-full" />
        </div>
        <p className="mt-1.5 text-xs text-sidebar-foreground/50">6.8 GB / 10 GB</p>
      </div>
    </aside>
  );
}
