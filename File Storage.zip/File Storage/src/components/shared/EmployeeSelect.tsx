import { useState, useEffect } from 'react';
import { supabase as _supabase } from '@/db/supabase';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

const supabase = _supabase as any; // eslint-disable-line @typescript-eslint/no-explicit-any

interface Employee { id: string; first_name: string; last_name: string; employee_no: string; }

interface EmployeeSelectProps {
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  label?: string;
  placeholder?: string;
  allowEmpty?: boolean;
  emptyLabel?: string;
}

export function EmployeeSelect({
  value, onChange, required = false,
  label = 'Employee', placeholder = 'Select employee',
  allowEmpty = false, emptyLabel = 'None / Anonymous',
}: EmployeeSelectProps) {
  const [employees, setEmployees] = useState<Employee[]>([]);

  useEffect(() => {
    supabase.from('employees')
      .select('id, first_name, last_name, employee_no')
      .eq('employment_status', 'active')
      .order('first_name')
      .limit(200)
      .then(({ data }: { data: Employee[] | null }) => setEmployees(data || []));
  }, []);

  return (
    <div className="space-y-1.5">
      <Label>{label}{required && ' *'}</Label>
      <Select value={value} onValueChange={onChange} required={required}>
        <SelectTrigger>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {allowEmpty && <SelectItem value="none">{emptyLabel}</SelectItem>}
          {employees.map(e => (
            <SelectItem key={e.id} value={e.id}>
              {e.first_name} {e.last_name} ({e.employee_no})
            </SelectItem>
          ))}
          {employees.length === 0 && (
            <SelectItem value="loading" disabled>Loading employees…</SelectItem>
          )}
        </SelectContent>
      </Select>
    </div>
  );
}
