﻿import { Table } from '@/shared/ui/Tables/Table';
import { ReactNode } from 'react';

interface DataTableProps<T> {
  data: T[];
  columns: { key: string; header: string; render?: (row: T) => ReactNode }[];
  keyExtractor: (row: T) => string;
}

export function DataTable<T>(props: DataTableProps<T>) {
  return <Table {...props} />;
}
