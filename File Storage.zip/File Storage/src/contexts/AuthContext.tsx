import React, { createContext, useContext, useState, useCallback } from 'react';
import { setTenantId, setUserId } from '@/lib/apiClient';

export type UserRole = 'STORAGE_ADMIN' | 'TENANT_ADMIN' | 'AUDIT_OFFICER' | 'SECURITY_AUDITOR' | 'END_USER';

export interface CurrentUser {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  tenantId: string;
  avatarUrl?: string;
}

interface AuthContextValue {
  user: CurrentUser | null;
  isAuthenticated: boolean;
  login: (user: CurrentUser) => void;
  logout: () => void;
  hasRole: (...roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

// Demo user for development — no real auth in this prototype
const DEMO_USER: CurrentUser = {
  id: 'demo_user_001',
  email: 'admin@filestorage.demo',
  name: 'Demo Admin',
  role: 'STORAGE_ADMIN',
  tenantId: 'default_tenant',
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<CurrentUser | null>(DEMO_USER);

  const login = useCallback((u: CurrentUser) => {
    setUser(u);
    setTenantId(u.tenantId);
    setUserId(u.id);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const hasRole = useCallback((...roles: UserRole[]) => {
    if (!user) return false;
    return roles.includes(user.role);
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout, hasRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
