
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- TABLE 1: file_requests
-- =============================================
CREATE TABLE file_requests (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  request_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  file_name VARCHAR(255) NOT NULL,
  file_url VARCHAR(2000),
  mime_type VARCHAR(100) NOT NULL,
  size_kb INTEGER NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'RECEIVED' CHECK (status IN ('RECEIVED','VALIDATED','FAILED','EXPIRED')),
  ip_address VARCHAR(45),
  source VARCHAR(10) NOT NULL DEFAULT 'HTTP' CHECK (source IN ('HTTP','KAFKA')),
  failure_reason VARCHAR(1000),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_file_requests_tenant_request ON file_requests (tenant_id, request_id) WHERE is_current = 1;
CREATE INDEX idx_file_requests_tenant_status ON file_requests (tenant_id, status) WHERE is_current = 1;
CREATE INDEX idx_file_requests_created ON file_requests (tenant_id, created_at DESC);

-- =============================================
-- TABLE 2: upload_sessions
-- =============================================
CREATE TABLE upload_sessions (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  file_count INTEGER NOT NULL CHECK (file_count <= 5),
  total_size_kb INTEGER NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS' CHECK (status IN ('IN_PROGRESS','COMPLETED','FAILED','EXPIRED')),
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  expiry_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '1 hour'),
  failure_reason VARCHAR(1000),
  resume_token VARCHAR(255),
  bytes_uploaded BIGINT NOT NULL DEFAULT 0,
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_upload_sessions_session ON upload_sessions (session_id) WHERE is_current = 1;
CREATE INDEX idx_upload_sessions_user ON upload_sessions (tenant_id, user_id, status) WHERE is_current = 1;
CREATE INDEX idx_upload_sessions_expiry ON upload_sessions (expiry_at, status) WHERE status = 'IN_PROGRESS';

-- =============================================
-- TABLE 3: folders
-- =============================================
CREATE TABLE folders (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  folder_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  parent_folder_id UUID,
  owner_user_id UUID NOT NULL DEFAULT auth.uid(),
  folder_name VARCHAR(255) NOT NULL,
  folder_path VARCHAR(2000),
  description VARCHAR(1000),
  color_code CHAR(7),
  is_public SMALLINT NOT NULL DEFAULT 0,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_folders_folder_id ON folders (folder_id) WHERE is_current = 1;
CREATE INDEX idx_folders_parent ON folders (tenant_id, parent_folder_id) WHERE is_current = 1;
CREATE INDEX idx_folders_owner ON folders (tenant_id, owner_user_id) WHERE is_current = 1;

-- =============================================
-- TABLE 4: file_metadata
-- =============================================
CREATE TABLE file_metadata (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  document_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  file_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  size_kb INTEGER NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','ARCHIVED','DELETED','PENDING')),
  description VARCHAR(1000),
  tags JSONB,
  extracted_text TEXT,
  checksum VARCHAR(128) NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  storage_tier VARCHAR(10) NOT NULL DEFAULT 'HOT' CHECK (storage_tier IN ('HOT','WARM','COLD')),
  encryption_status VARCHAR(20) NOT NULL DEFAULT 'ENCRYPTED' CHECK (encryption_status IN ('ENCRYPTED','UNENCRYPTED','ENCRYPTION_FAILED')),
  encryption_key_ref VARCHAR(200),
  iv VARCHAR(64),
  last_accessed_at TIMESTAMPTZ,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_file_metadata_doc ON file_metadata (document_id) WHERE is_current = 1;
CREATE INDEX idx_file_metadata_user ON file_metadata (tenant_id, user_id, status) WHERE is_current = 1;
CREATE INDEX idx_file_metadata_name ON file_metadata (tenant_id, file_name) WHERE is_current = 1;
CREATE INDEX idx_file_metadata_temporal ON file_metadata (document_id, effective_from, effective_to);

-- =============================================
-- TABLE 5: folder_file_mappings
-- =============================================
CREATE TABLE folder_file_mappings (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  mapping_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  folder_id UUID NOT NULL,
  document_id UUID NOT NULL,
  tenant_id VARCHAR(36) NOT NULL,
  added_by UUID NOT NULL DEFAULT auth.uid(),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_ffm_folder_doc ON folder_file_mappings (folder_id, document_id) WHERE is_current = 1;
CREATE INDEX idx_ffm_tenant_doc ON folder_file_mappings (tenant_id, document_id) WHERE is_current = 1;

-- =============================================
-- TABLE 6: file_versions
-- =============================================
CREATE TABLE file_versions (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  version_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  document_id UUID NOT NULL,
  tenant_id VARCHAR(36) NOT NULL,
  version_number INTEGER NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  checksum VARCHAR(128) NOT NULL,
  size_kb INTEGER NOT NULL,
  change_summary VARCHAR(1000),
  encryption_status VARCHAR(20) NOT NULL DEFAULT 'ENCRYPTED' CHECK (encryption_status IN ('ENCRYPTED','UNENCRYPTED')),
  encryption_key_ref VARCHAR(200),
  iv VARCHAR(64),
  storage_tier VARCHAR(10) NOT NULL DEFAULT 'HOT' CHECK (storage_tier IN ('HOT','WARM','COLD')),
  is_orphaned SMALLINT NOT NULL DEFAULT 0,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_file_versions_vid ON file_versions (version_id) WHERE is_current = 1;
CREATE UNIQUE INDEX idx_file_versions_doc_ver ON file_versions (document_id, version_number) WHERE is_current = 1;
CREATE INDEX idx_file_versions_tenant ON file_versions (tenant_id, document_id, version_number DESC);

-- =============================================
-- TABLE 7: file_permissions
-- =============================================
CREATE TABLE file_permissions (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  permission_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  document_id UUID,
  folder_id UUID,
  tenant_id VARCHAR(36) NOT NULL,
  grantee_type VARCHAR(20) NOT NULL DEFAULT 'USER' CHECK (grantee_type IN ('USER','ROLE','GROUP','EXTERNAL')),
  grantee_id VARCHAR(36) NOT NULL,
  grantee_email VARCHAR(255),
  external_tenant_id VARCHAR(36),
  role VARCHAR(20) NOT NULL CHECK (role IN ('OWNER','EDITOR','VIEWER','COMMENTOR','NONE')),
  access_level VARCHAR(20) NOT NULL CHECK (access_level IN ('READ','WRITE','COMMENT','DOWNLOAD','MANAGE')),
  share_link_token VARCHAR(255),
  share_link_enabled SMALLINT NOT NULL DEFAULT 0,
  share_link_password_hash VARCHAR(255),
  share_message VARCHAR(500),
  apply_recursively SMALLINT NOT NULL DEFAULT 1,
  exclude_subfolders JSONB,
  granted_by UUID NOT NULL DEFAULT auth.uid(),
  granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','REVOKED','EXPIRED','PENDING_APPROVAL')),
  revoked_at TIMESTAMPTZ,
  revocation_reason VARCHAR(500),
  last_accessed_at TIMESTAMPTZ,
  access_count INTEGER NOT NULL DEFAULT 0,
  propagation_status VARCHAR(20) DEFAULT 'PENDING' CHECK (propagation_status IN ('PENDING','IN_PROGRESS','COMPLETED','FAILED')),
  propagation_completed_at TIMESTAMPTZ,
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_fp_perm_id ON file_permissions (permission_id) WHERE is_current = 1;
CREATE INDEX idx_fp_grantee ON file_permissions (tenant_id, grantee_id, status) WHERE is_current = 1;
CREATE INDEX idx_fp_token ON file_permissions (tenant_id, share_link_token) WHERE share_link_token IS NOT NULL;
CREATE INDEX idx_fp_expires ON file_permissions (tenant_id, expires_at, status) WHERE expires_at IS NOT NULL AND status = 'ACTIVE';

-- =============================================
-- TABLE 8: file_audit_logs
-- =============================================
CREATE TABLE file_audit_logs (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  audit_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  document_id UUID,
  tenant_id VARCHAR(36) NOT NULL,
  actor_id UUID NOT NULL DEFAULT auth.uid(),
  actor_type VARCHAR(20) NOT NULL DEFAULT 'USER' CHECK (actor_type IN ('USER','SYSTEM','API_CLIENT')),
  action VARCHAR(20) NOT NULL CHECK (action IN ('CREATE','UPDATE','DELETE','READ','SHARE','VALIDATE','UPLOAD','DOWNLOAD','ARCHIVE','RESTORE','GRANT','REVOKE','EXPORT','PRINT')),
  action_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  old_value JSONB,
  new_value JSONB,
  reason VARCHAR(1000),
  viewer_role VARCHAR(50) NOT NULL DEFAULT 'END_USER',
  ip_address VARCHAR(45),
  user_agent VARCHAR(500),
  correlation_id UUID,
  session_id UUID,
  audit_signature VARCHAR(128),
  previous_audit_hash VARCHAR(128),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_audit_id ON file_audit_logs (audit_id) WHERE is_current = 1;
CREATE INDEX idx_audit_tenant_doc ON file_audit_logs (tenant_id, document_id, action_timestamp DESC);
CREATE INDEX idx_audit_tenant_actor ON file_audit_logs (tenant_id, actor_id, action_timestamp DESC);
CREATE INDEX idx_audit_tenant_action ON file_audit_logs (tenant_id, action, action_timestamp DESC);

-- =============================================
-- TABLE 9: file_backups
-- =============================================
CREATE TABLE file_backups (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  backup_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  document_id UUID,
  tenant_id VARCHAR(36) NOT NULL,
  backup_path VARCHAR(500) NOT NULL,
  backup_type VARCHAR(20) NOT NULL CHECK (backup_type IN ('FULL','INCREMENTAL','DIFFERENTIAL')),
  backup_scope VARCHAR(20) NOT NULL DEFAULT 'TENANT' CHECK (backup_scope IN ('TENANT','FILE','FOLDER')),
  checksum VARCHAR(128) NOT NULL,
  size_bytes BIGINT NOT NULL,
  file_count INTEGER NOT NULL DEFAULT 0,
  encryption_status VARCHAR(20) NOT NULL DEFAULT 'ENCRYPTED' CHECK (encryption_status IN ('ENCRYPTED','UNENCRYPTED')),
  encryption_key_ref VARCHAR(200),
  retention_days INTEGER NOT NULL DEFAULT 30,
  status VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS' CHECK (status IN ('SUCCESS','FAILED','IN_PROGRESS','PARTIAL')),
  failure_reason TEXT,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  verified_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_backups_id ON file_backups (backup_id) WHERE is_current = 1;
CREATE INDEX idx_backups_tenant ON file_backups (tenant_id, status, created_at DESC);

-- =============================================
-- TABLE 10: file_restore_jobs
-- =============================================
CREATE TABLE file_restore_jobs (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  restore_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  document_id UUID,
  folder_id UUID,
  tenant_id VARCHAR(36) NOT NULL,
  backup_id UUID NOT NULL,
  restore_scope VARCHAR(20) NOT NULL CHECK (restore_scope IN ('SINGLE_FILE','FOLDER','TENANT','BULK')),
  restore_path VARCHAR(500) NOT NULL,
  restore_target_version INTEGER,
  restore_target_time TIMESTAMPTZ,
  requested_by UUID NOT NULL DEFAULT auth.uid(),
  restored_file_count INTEGER NOT NULL DEFAULT 0,
  failed_file_count INTEGER NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING_APPROVAL' CHECK (status IN ('IN_PROGRESS','COMPLETED','FAILED','CANCELLED','PENDING_APPROVAL')),
  failure_reason TEXT,
  approval_status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (approval_status IN ('PENDING','APPROVED','REJECTED')),
  approved_by UUID,
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_restore_id ON file_restore_jobs (restore_id) WHERE is_current = 1;
CREATE INDEX idx_restore_tenant ON file_restore_jobs (tenant_id, status, requested_at DESC);

-- =============================================
-- TABLE 11: user_storage_preferences
-- =============================================
CREATE TABLE user_storage_preferences (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  preference_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  preferred_view VARCHAR(10) NOT NULL DEFAULT 'LIST' CHECK (preferred_view IN ('LIST','GRID','DETAILED')),
  default_sort_field VARCHAR(50) NOT NULL DEFAULT 'created_at',
  default_sort_order VARCHAR(4) NOT NULL DEFAULT 'DESC' CHECK (default_sort_order IN ('ASC','DESC')),
  items_per_page INTEGER NOT NULL DEFAULT 25 CHECK (items_per_page <= 100),
  notification_settings JSONB NOT NULL DEFAULT '{}',
  quiet_hours JSONB,
  thumbnail_preview_enabled SMALLINT NOT NULL DEFAULT 1,
  auto_save_interval_seconds INTEGER NOT NULL DEFAULT 30,
  default_upload_folder_id UUID,
  theme VARCHAR(10) NOT NULL DEFAULT 'SYSTEM' CHECK (theme IN ('LIGHT','DARK','SYSTEM')),
  language VARCHAR(10) NOT NULL DEFAULT 'en',
  effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_prefs_user ON user_storage_preferences (tenant_id, user_id) WHERE is_deleted = 0;

-- =============================================
-- TABLE 12: storage_quotas
-- =============================================
CREATE TABLE storage_quotas (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quota_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID,
  quota_type VARCHAR(20) NOT NULL DEFAULT 'USER' CHECK (quota_type IN ('USER','TENANT','DEPARTMENT')),
  allocated_space_mb BIGINT NOT NULL,
  used_space_mb BIGINT NOT NULL DEFAULT 0,
  soft_limit_mb BIGINT NOT NULL,
  hard_limit_mb BIGINT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','EXCEEDED_SOFT','EXCEEDED_HARD','SUSPENDED')),
  last_checked_at TIMESTAMPTZ,
  last_alert_sent_at TIMESTAMPTZ,
  effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_quotas_id ON storage_quotas (quota_id) WHERE is_current = 1;
CREATE INDEX idx_quotas_user ON storage_quotas (tenant_id, user_id) WHERE is_current = 1 AND user_id IS NOT NULL;
CREATE INDEX idx_quotas_status ON storage_quotas (tenant_id, status) WHERE is_current = 1;

-- =============================================
-- TABLE 13: file_calendar_events
-- =============================================
CREATE TABLE file_calendar_events (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  document_id UUID,
  event_title VARCHAR(255) NOT NULL,
  event_description VARCHAR(2000),
  event_date TIMESTAMPTZ NOT NULL,
  event_end_date TIMESTAMPTZ,
  all_day SMALLINT NOT NULL DEFAULT 0,
  importance_level VARCHAR(10) NOT NULL DEFAULT 'MEDIUM' CHECK (importance_level IN ('LOW','MEDIUM','HIGH','URGENT')),
  reminder_minutes_before JSONB,
  reminder_sent JSONB,
  recurrence_rule VARCHAR(500),
  color_code CHAR(7),
  status VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED' CHECK (status IN ('SCHEDULED','COMPLETED','CANCELLED','EXPIRED')),
  external_calendar_id VARCHAR(255),
  last_synced_at TIMESTAMPTZ,
  created_by UUID NOT NULL DEFAULT auth.uid(),
  effective_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_events_id ON file_calendar_events (event_id) WHERE is_deleted = 0;
CREATE INDEX idx_events_user ON file_calendar_events (tenant_id, user_id, event_date, status);
CREATE INDEX idx_events_doc ON file_calendar_events (tenant_id, document_id, event_date) WHERE document_id IS NOT NULL;

-- =============================================
-- TABLE 14: file_discussions
-- =============================================
CREATE TABLE file_discussions (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  discussion_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  document_id UUID NOT NULL,
  user_id UUID NOT NULL DEFAULT auth.uid(),
  message_text TEXT NOT NULL CHECK (char_length(message_text) <= 10000),
  parent_message_id UUID,
  thread_depth INTEGER NOT NULL DEFAULT 0 CHECK (thread_depth <= 10),
  mentions JSONB,
  attachments JSONB,
  edited_at TIMESTAMPTZ,
  edited_by UUID,
  is_edited SMALLINT NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','ARCHIVED','HIDDEN_BY_ADMIN','DELETED_BY_USER')),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_discussions_id ON file_discussions (discussion_id) WHERE is_current = 1;
CREATE INDEX idx_discussions_doc ON file_discussions (tenant_id, document_id, created_at DESC);
CREATE INDEX idx_discussions_parent ON file_discussions (tenant_id, parent_message_id, created_at);
CREATE INDEX idx_discussions_user ON file_discussions (tenant_id, user_id, created_at DESC);

-- =============================================
-- TABLE 15: file_notifications
-- =============================================
CREATE TABLE file_notifications (
  row_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  notification_id UUID NOT NULL DEFAULT uuid_generate_v4(),
  tenant_id VARCHAR(36) NOT NULL,
  user_id UUID NOT NULL,
  document_id UUID,
  notification_type VARCHAR(30) NOT NULL CHECK (notification_type IN ('FILE_SHARED','FILE_UPLOADED','FILE_UPDATED','FILE_DELETED','COMMENT_ADDED','MENTIONED','SHARE_EXPIRING','QUOTA_WARNING','RESTORE_COMPLETED')),
  message VARCHAR(2000) NOT NULL,
  is_read SMALLINT NOT NULL DEFAULT 0,
  read_at TIMESTAMPTZ,
  action_url VARCHAR(500),
  delivery_method VARCHAR(20) NOT NULL DEFAULT 'IN_APP' CHECK (delivery_method IN ('IN_APP','EMAIL','SMS','PUSH')),
  row_start TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current SMALLINT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by UUID NOT NULL DEFAULT auth.uid(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by UUID,
  is_active SMALLINT NOT NULL DEFAULT 1,
  is_deleted SMALLINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_notif_id ON file_notifications (notification_id) WHERE is_current = 1;
CREATE INDEX idx_notif_user ON file_notifications (tenant_id, user_id, is_read, created_at DESC);
CREATE INDEX idx_notif_doc ON file_notifications (tenant_id, document_id, created_at DESC) WHERE document_id IS NOT NULL;
CREATE INDEX idx_notif_type ON file_notifications (tenant_id, notification_type, created_at DESC);
