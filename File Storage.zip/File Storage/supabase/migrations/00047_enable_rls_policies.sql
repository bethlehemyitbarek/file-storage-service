
-- Enable RLS on all tables
ALTER TABLE file_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE upload_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE folders ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE folder_file_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_restore_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_storage_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE storage_quotas ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_calendar_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_discussions ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_notifications ENABLE ROW LEVEL SECURITY;

-- =============================================
-- SECURITY DEFINER helper function for tenant context
-- =============================================
CREATE OR REPLACE FUNCTION get_user_tenant_id()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT COALESCE(
    (current_setting('app.tenant_id', true)),
    'default_tenant'
  );
$$;

-- =============================================
-- file_requests policies
-- =============================================
CREATE POLICY "file_requests_select" ON file_requests FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_requests_insert" ON file_requests FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "file_requests_update" ON file_requests FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "file_requests_anon_deny" ON file_requests FOR ALL TO anon
  USING (false);

-- =============================================
-- upload_sessions policies
-- =============================================
CREATE POLICY "upload_sessions_select" ON upload_sessions FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "upload_sessions_insert" ON upload_sessions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "upload_sessions_update" ON upload_sessions FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "upload_sessions_anon_deny" ON upload_sessions FOR ALL TO anon
  USING (false);

-- =============================================
-- folders policies
-- =============================================
CREATE POLICY "folders_select" ON folders FOR SELECT TO authenticated
  USING (owner_user_id = auth.uid() OR is_public = 1 OR tenant_id = get_user_tenant_id());
CREATE POLICY "folders_insert" ON folders FOR INSERT TO authenticated
  WITH CHECK (owner_user_id = auth.uid());
CREATE POLICY "folders_update" ON folders FOR UPDATE TO authenticated
  USING (owner_user_id = auth.uid());
CREATE POLICY "folders_delete" ON folders FOR DELETE TO authenticated
  USING (owner_user_id = auth.uid());
CREATE POLICY "folders_anon_deny" ON folders FOR ALL TO anon
  USING (false);

-- =============================================
-- file_metadata policies
-- =============================================
CREATE POLICY "file_metadata_select" ON file_metadata FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_metadata_insert" ON file_metadata FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "file_metadata_update" ON file_metadata FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_metadata_anon_deny" ON file_metadata FOR ALL TO anon
  USING (false);

-- =============================================
-- folder_file_mappings policies
-- =============================================
CREATE POLICY "ffm_select" ON folder_file_mappings FOR SELECT TO authenticated
  USING (added_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "ffm_insert" ON folder_file_mappings FOR INSERT TO authenticated
  WITH CHECK (added_by = auth.uid());
CREATE POLICY "ffm_delete" ON folder_file_mappings FOR DELETE TO authenticated
  USING (added_by = auth.uid());
CREATE POLICY "ffm_anon_deny" ON folder_file_mappings FOR ALL TO anon
  USING (false);

-- =============================================
-- file_versions policies
-- =============================================
CREATE POLICY "file_versions_select" ON file_versions FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_versions_insert" ON file_versions FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "file_versions_anon_deny" ON file_versions FOR ALL TO anon
  USING (false);

-- =============================================
-- file_permissions policies
-- =============================================
CREATE POLICY "file_permissions_select" ON file_permissions FOR SELECT TO authenticated
  USING (granted_by = auth.uid() OR grantee_id = auth.uid()::text OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_permissions_insert" ON file_permissions FOR INSERT TO authenticated
  WITH CHECK (granted_by = auth.uid());
CREATE POLICY "file_permissions_update" ON file_permissions FOR UPDATE TO authenticated
  USING (granted_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "file_permissions_anon_deny" ON file_permissions FOR ALL TO anon
  USING (false);

-- =============================================
-- file_audit_logs policies (read-only for most users, insert for system)
-- =============================================
CREATE POLICY "audit_logs_select" ON file_audit_logs FOR SELECT TO authenticated
  USING (actor_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "audit_logs_insert" ON file_audit_logs FOR INSERT TO authenticated
  WITH CHECK (actor_id = auth.uid());
CREATE POLICY "audit_logs_anon_deny" ON file_audit_logs FOR ALL TO anon
  USING (false);

-- =============================================
-- file_backups policies
-- =============================================
CREATE POLICY "backups_select" ON file_backups FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "backups_insert" ON file_backups FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "backups_update" ON file_backups FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "backups_anon_deny" ON file_backups FOR ALL TO anon
  USING (false);

-- =============================================
-- file_restore_jobs policies
-- =============================================
CREATE POLICY "restore_jobs_select" ON file_restore_jobs FOR SELECT TO authenticated
  USING (requested_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "restore_jobs_insert" ON file_restore_jobs FOR INSERT TO authenticated
  WITH CHECK (requested_by = auth.uid());
CREATE POLICY "restore_jobs_update" ON file_restore_jobs FOR UPDATE TO authenticated
  USING (requested_by = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "restore_jobs_anon_deny" ON file_restore_jobs FOR ALL TO anon
  USING (false);

-- =============================================
-- user_storage_preferences policies
-- =============================================
CREATE POLICY "prefs_select" ON user_storage_preferences FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "prefs_insert" ON user_storage_preferences FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "prefs_update" ON user_storage_preferences FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "prefs_anon_deny" ON user_storage_preferences FOR ALL TO anon
  USING (false);

-- =============================================
-- storage_quotas policies
-- =============================================
CREATE POLICY "quotas_select" ON storage_quotas FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "quotas_insert" ON storage_quotas FOR INSERT TO authenticated
  WITH CHECK (created_by = auth.uid());
CREATE POLICY "quotas_update" ON storage_quotas FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "quotas_anon_deny" ON storage_quotas FOR ALL TO anon
  USING (false);

-- =============================================
-- file_calendar_events policies
-- =============================================
CREATE POLICY "events_select" ON file_calendar_events FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR tenant_id = get_user_tenant_id());
CREATE POLICY "events_insert" ON file_calendar_events FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "events_update" ON file_calendar_events FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "events_delete" ON file_calendar_events FOR DELETE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "events_anon_deny" ON file_calendar_events FOR ALL TO anon
  USING (false);

-- =============================================
-- file_discussions policies
-- =============================================
CREATE POLICY "discussions_select" ON file_discussions FOR SELECT TO authenticated
  USING (tenant_id = get_user_tenant_id() OR user_id = auth.uid());
CREATE POLICY "discussions_insert" ON file_discussions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "discussions_update" ON file_discussions FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "discussions_delete" ON file_discussions FOR DELETE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "discussions_anon_deny" ON file_discussions FOR ALL TO anon
  USING (false);

-- =============================================
-- file_notifications policies
-- =============================================
CREATE POLICY "notifs_select" ON file_notifications FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "notifs_insert" ON file_notifications FOR INSERT TO authenticated
  WITH CHECK (true);
CREATE POLICY "notifs_update" ON file_notifications FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "notifs_anon_deny" ON file_notifications FOR ALL TO anon
  USING (false);
