-- Drop and recreate get_dsar_cron_history with correct signature
DROP FUNCTION IF EXISTS get_dsar_cron_history();

CREATE OR REPLACE FUNCTION get_dsar_cron_history()
RETURNS TABLE (
  jobid       bigint,
  runid       bigint,
  job_pid     integer,
  database    text,
  username    text,
  command     text,
  status      text,
  return_message text,
  start_time  timestamptz,
  end_time    timestamptz
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT
    r.jobid,
    r.runid,
    r.job_pid,
    r.database,
    r.username,
    r.command,
    r.status,
    r.return_message,
    r.start_time,
    r.end_time
  FROM cron.job_run_details r
  JOIN cron.job j ON j.jobid = r.jobid
  WHERE j.jobname = 'send-dsar-reminders'
  ORDER BY r.start_time DESC
  LIMIT 10;
$$;

GRANT EXECUTE ON FUNCTION get_dsar_cron_history() TO authenticated;

-- Enable RLS with open-access policies for trainers
ALTER TABLE trainers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "trainers_all_access" ON trainers FOR ALL USING (true) WITH CHECK (true);

-- Enable RLS with open-access policies for data_subject_access_requests
ALTER TABLE data_subject_access_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "dsar_all_access" ON data_subject_access_requests FOR ALL USING (true) WITH CHECK (true);