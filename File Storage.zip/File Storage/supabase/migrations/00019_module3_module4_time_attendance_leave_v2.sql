
-- ============================================================
-- MODULE 3: TIME & ATTENDANCE
-- ============================================================

-- 3.0 Fiscal Years
CREATE TABLE fiscal_years (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fiscal_year_id      UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id           UUID,
  year_label          VARCHAR(20) NOT NULL,
  start_date          DATE NOT NULL,
  end_date            DATE NOT NULL,
  is_current          SMALLINT NOT NULL DEFAULT 0,
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX fiscal_years_current_idx ON fiscal_years (is_current);

INSERT INTO fiscal_years (year_label, start_date, end_date, is_current)
VALUES ('2025/2026', '2025-07-01', '2026-06-30', 1);

-- 3.1 Work Calendars
CREATE TABLE work_calendars (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  calendar_id         UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id           UUID,
  business_unit_id    UUID REFERENCES business_units(id),
  calendar_name       VARCHAR(200) NOT NULL,
  working_days        JSONB NOT NULL DEFAULT '["Mon","Tue","Wed","Thu","Fri"]',
  daily_hours         DECIMAL(4,2) NOT NULL DEFAULT 8.00,
  effective_from      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by          UUID REFERENCES employees(id),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by          UUID REFERENCES employees(id),
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX work_calendars_tenant_bu_idx ON work_calendars (tenant_id, business_unit_id, effective_from, effective_to);

INSERT INTO work_calendars (calendar_name, working_days, daily_hours)
VALUES ('Standard BKG Calendar', '["Mon","Tue","Wed","Thu","Fri"]', 8.00);

-- 3.2 Holidays (FK to work_calendars.id, not calendar_id)
CREATE TABLE holidays (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  holiday_id          UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id           UUID,
  work_calendar_id    UUID REFERENCES work_calendars(id),
  calendar_ref        UUID,
  holiday_name        VARCHAR(200) NOT NULL,
  holiday_date        DATE NOT NULL,
  is_recurring        SMALLINT NOT NULL DEFAULT 0,
  recurrence_type     VARCHAR(10) NOT NULL DEFAULT 'NONE' CHECK (recurrence_type IN ('NONE','YEARLY','MONTHLY')),
  effective_from      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by          UUID REFERENCES employees(id),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by          UUID REFERENCES employees(id),
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX holidays_tenant_calendar_idx ON holidays (tenant_id, work_calendar_id, holiday_date);

INSERT INTO holidays (holiday_name, holiday_date, is_recurring, recurrence_type) VALUES
  ('Ethiopian New Year (Enkutatash)',     '2025-09-11', 1, 'YEARLY'),
  ('Meskel (Finding of True Cross)',      '2025-09-27', 1, 'YEARLY'),
  ('Christmas (Genna)',                   '2026-01-07', 1, 'YEARLY'),
  ('Epiphany (Timkat)',                   '2026-01-19', 1, 'YEARLY'),
  ('Adwa Victory Day',                    '2026-03-02', 1, 'YEARLY'),
  ('Good Friday (Siklet)',                '2026-04-10', 1, 'YEARLY'),
  ('Easter Sunday (Fasika)',              '2026-04-12', 1, 'YEARLY'),
  ('Ethiopian Labour Day',               '2026-05-01', 1, 'YEARLY'),
  ('Patriots Victory Day',               '2026-05-05', 1, 'YEARLY'),
  ('Derg Downfall Day',                  '2026-05-28', 1, 'YEARLY'),
  ('Eid al-Fitr',                        '2026-03-30', 1, 'YEARLY'),
  ('Eid al-Adha',                        '2026-06-06', 1, 'YEARLY'),
  ('Prophet Muhammad Birthday (Mawlid)', '2025-09-04', 1, 'YEARLY');

-- 3.3 Shifts — ALTER existing
ALTER TABLE shifts
  ADD COLUMN IF NOT EXISTS shift_id               UUID DEFAULT gen_random_uuid() UNIQUE,
  ADD COLUMN IF NOT EXISTS shift_code             VARCHAR(30),
  ADD COLUMN IF NOT EXISTS break_duration_minutes INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS department_id          UUID REFERENCES departments(id),
  ADD COLUMN IF NOT EXISTS grace_period_minutes   INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS effective_from         TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to           TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999+00',
  ADD COLUMN IF NOT EXISTS tenant_id              UUID,
  ADD COLUMN IF NOT EXISTS created_by             UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS updated_by             UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS is_deleted             SMALLINT NOT NULL DEFAULT 0;

UPDATE shifts SET shift_id = gen_random_uuid() WHERE shift_id IS NULL;
UPDATE shifts SET shift_code = code WHERE shift_code IS NULL AND code IS NOT NULL;

-- 3.4 Overtime Rules (FK to work_calendars.id)
CREATE TABLE overtime_rules (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  overtime_rule_id    UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id           UUID,
  work_calendar_id    UUID REFERENCES work_calendars(id),
  overtime_type       VARCHAR(20) NOT NULL CHECK (overtime_type IN ('WEEKDAY','WEEKEND','HOLIDAY','NIGHT')),
  threshold_hours     DECIMAL(4,2) NOT NULL DEFAULT 8.00,
  multiplier_rate     DECIMAL(4,2) NOT NULL DEFAULT 1.50,
  effective_from      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by          UUID REFERENCES employees(id),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by          UUID REFERENCES employees(id),
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX overtime_rules_tenant_calendar_idx ON overtime_rules (tenant_id, work_calendar_id, overtime_type);

INSERT INTO overtime_rules (overtime_type, threshold_hours, multiplier_rate) VALUES
  ('WEEKDAY',  8.00, 1.25),
  ('WEEKEND',  0.00, 1.50),
  ('HOLIDAY',  0.00, 2.00),
  ('NIGHT',    0.00, 1.25);

-- 3.5 Attendance Events
CREATE TABLE attendance_events (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id              UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id             UUID,
  employee_id           UUID NOT NULL REFERENCES employees(id),
  event_source          VARCHAR(20) NOT NULL CHECK (event_source IN ('BIOMETRIC','MOBILE','WEB','MANUAL')),
  event_type            VARCHAR(20) NOT NULL CHECK (event_type IN ('CHECK_IN','CHECK_OUT')),
  event_timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  device_id             VARCHAR(100),
  gps_latitude          DECIMAL(10,7),
  gps_longitude         DECIMAL(10,7),
  device_fingerprint    VARCHAR(50),
  raw_data              JSONB,
  is_corrected          SMALLINT NOT NULL DEFAULT 0,
  correction_id         UUID,
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current            SMALLINT NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID REFERENCES employees(id),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID REFERENCES employees(id),
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX attendance_events_emp_time_idx ON attendance_events (tenant_id, employee_id, event_timestamp);
CREATE INDEX attendance_events_source_idx ON attendance_events (tenant_id, event_source);

-- 3.6 Daily Attendance Summaries
CREATE TABLE daily_attendance_summaries (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  summary_id                UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id                 UUID,
  employee_id               UUID NOT NULL REFERENCES employees(id),
  attendance_date           DATE NOT NULL,
  shift_id                  UUID REFERENCES shifts(id),
  first_check_in            TIMESTAMPTZ,
  last_check_out            TIMESTAMPTZ,
  total_worked_hours        DECIMAL(5,2) DEFAULT 0,
  regular_hours             DECIMAL(5,2) DEFAULT 0,
  overtime_hours            DECIMAL(5,2) DEFAULT 0,
  overtime_type             VARCHAR(20) CHECK (overtime_type IN ('WEEKDAY','WEEKEND','HOLIDAY','NIGHT')),
  late_minutes              INTEGER DEFAULT 0,
  early_leave_minutes       INTEGER DEFAULT 0,
  attendance_status         VARCHAR(20) NOT NULL DEFAULT 'PRESENT' CHECK (attendance_status IN ('PRESENT','ABSENT','HALF_DAY','ON_LEAVE','HOLIDAY','WEEKEND','EXCUSED')),
  leave_request_id          UUID,
  is_anomaly                SMALLINT NOT NULL DEFAULT 0,
  anomaly_type              VARCHAR(50),
  is_locked                 SMALLINT NOT NULL DEFAULT 0,
  locked_by_payroll_run_id  UUID,
  effective_from            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to              TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  row_start                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current                SMALLINT NOT NULL DEFAULT 1,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                UUID REFERENCES employees(id),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                UUID REFERENCES employees(id),
  is_active                 SMALLINT NOT NULL DEFAULT 1,
  is_deleted                SMALLINT NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX daily_att_summary_current_uidx ON daily_attendance_summaries (tenant_id, employee_id, attendance_date) WHERE is_current = 1;
CREATE INDEX daily_att_summary_date_idx ON daily_attendance_summaries (tenant_id, attendance_date);
CREATE INDEX daily_att_summary_status_idx ON daily_attendance_summaries (tenant_id, attendance_status);
CREATE INDEX daily_att_summary_locked_idx ON daily_attendance_summaries (tenant_id, is_locked);

-- 3.7 Attendance Corrections
CREATE TABLE attendance_corrections (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  correction_id         UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id             UUID,
  employee_id           UUID NOT NULL REFERENCES employees(id),
  attendance_date       DATE NOT NULL,
  correction_type       VARCHAR(30) NOT NULL CHECK (correction_type IN ('MISSED_PUNCH','TIME_ADJUSTMENT','STATUS_OVERRIDE','BULK')),
  original_value        TEXT,
  corrected_value       TEXT,
  justification         VARCHAR(2000) NOT NULL,
  corrected_by          UUID REFERENCES employees(id),
  workflow_instance_id  UUID,
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current            SMALLINT NOT NULL DEFAULT 1,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID REFERENCES employees(id),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID REFERENCES employees(id),
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX att_corrections_emp_date_idx ON attendance_corrections (tenant_id, employee_id, attendance_date);

-- 3.8 Attendance Exception Rules
CREATE TABLE attendance_exception_rules (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exception_id    UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id       UUID,
  employee_id     UUID NOT NULL REFERENCES employees(id),
  exception_type  VARCHAR(30) NOT NULL CHECK (exception_type IN ('EXEMPT_FROM_ATTENDANCE','FLEXIBLE_HOURS','REMOTE_WORK')),
  effective_from  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to    TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  row_start       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end         TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  is_current      SMALLINT NOT NULL DEFAULT 1,
  reason          VARCHAR(1000),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by      UUID REFERENCES employees(id),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by      UUID REFERENCES employees(id),
  is_active       SMALLINT NOT NULL DEFAULT 1,
  is_deleted      SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX att_exception_emp_idx ON attendance_exception_rules (tenant_id, employee_id);

-- ============================================================
-- MODULE 4: LEAVE MANAGEMENT
-- ============================================================

-- 4.1 Leave Types — ALTER existing
ALTER TABLE leave_types
  ADD COLUMN IF NOT EXISTS leave_type_id            UUID DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS leave_name               VARCHAR(100),
  ADD COLUMN IF NOT EXISTS leave_category           VARCHAR(20) DEFAULT 'ANNUAL',
  ADD COLUMN IF NOT EXISTS is_attachment_required   SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS allowed_attachment_types VARCHAR(100),
  ADD COLUMN IF NOT EXISTS max_days_per_year        INTEGER,
  ADD COLUMN IF NOT EXISTS gender_restriction       VARCHAR(10),
  ADD COLUMN IF NOT EXISTS min_service_months       INTEGER,
  ADD COLUMN IF NOT EXISTS tenant_id                UUID,
  ADD COLUMN IF NOT EXISTS effective_from           TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to             TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999+00',
  ADD COLUMN IF NOT EXISTS created_by               UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS updated_by               UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS is_deleted               SMALLINT NOT NULL DEFAULT 0;

UPDATE leave_types SET leave_type_id = gen_random_uuid() WHERE leave_type_id IS NULL;
UPDATE leave_types SET leave_name = name WHERE leave_name IS NULL AND name IS NOT NULL;
UPDATE leave_types SET max_days_per_year = days_per_year WHERE max_days_per_year IS NULL AND days_per_year IS NOT NULL;

-- 4.2 Leave Policies
CREATE TABLE leave_policies (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  policy_id                   UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  tenant_id                   UUID,
  leave_type_id               UUID NOT NULL REFERENCES leave_types(id),
  policy_name                 VARCHAR(200) NOT NULL,
  entitlement_days            DECIMAL(5,1) NOT NULL DEFAULT 0,
  accrual_frequency           VARCHAR(20) CHECK (accrual_frequency IN ('MONTHLY','QUARTERLY','YEARLY','UPFRONT')),
  accrual_rate                DECIMAL(5,2),
  is_pro_rata                 SMALLINT NOT NULL DEFAULT 0,
  is_auto_credit              SMALLINT NOT NULL DEFAULT 0,
  carry_forward_limit_days    DECIMAL(5,1) DEFAULT 0,
  carry_forward_expiry_months INTEGER,
  is_carry_forward_auto       SMALLINT NOT NULL DEFAULT 0,
  is_encashment_allowed       SMALLINT NOT NULL DEFAULT 0,
  is_negative_balance_allowed SMALLINT NOT NULL DEFAULT 0,
  max_backdated_days          INTEGER DEFAULT 0,
  version_number              INTEGER NOT NULL DEFAULT 1,
  effective_from              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to                TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59.999999+00',
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                  UUID REFERENCES employees(id),
  updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                  UUID REFERENCES employees(id),
  is_active                   SMALLINT NOT NULL DEFAULT 1,
  is_deleted                  SMALLINT NOT NULL DEFAULT 0
);
CREATE INDEX leave_policies_type_idx ON leave_policies (tenant_id, leave_type_id);
CREATE INDEX leave_policies_active_idx ON leave_policies (tenant_id, is_active);

-- 4.3 Leave Balances — ALTER existing
ALTER TABLE leave_balances
  ADD COLUMN IF NOT EXISTS balance_id           UUID DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS tenant_id            UUID,
  ADD COLUMN IF NOT EXISTS fiscal_year_id       UUID REFERENCES fiscal_years(id),
  ADD COLUMN IF NOT EXISTS accrued_days         DECIMAL(5,1) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS carried_forward_days DECIMAL(5,1) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS adjustment_days      DECIMAL(5,1) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS available_days       DECIMAL(5,1) DEFAULT 0,
  ADD COLUMN IF NOT EXISTS effective_from       TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS effective_to         TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999+00',
  ADD COLUMN IF NOT EXISTS row_start            TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS row_end              TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999+00',
  ADD COLUMN IF NOT EXISTS is_current           SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS created_by           UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS updated_by           UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS is_deleted           SMALLINT NOT NULL DEFAULT 0;

UPDATE leave_balances SET balance_id = gen_random_uuid() WHERE balance_id IS NULL;
UPDATE leave_balances SET available_days = COALESCE(entitled_days, 0) - COALESCE(used_days, 0) WHERE available_days = 0;
UPDATE leave_balances SET carried_forward_days = COALESCE(carried_forward, 0) WHERE carried_forward_days = 0;

-- 4.4 Leave Requests — ALTER existing
ALTER TABLE leave_requests
  ADD COLUMN IF NOT EXISTS request_id             UUID DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS tenant_id              UUID,
  ADD COLUMN IF NOT EXISTS contact_info           VARCHAR(255),
  ADD COLUMN IF NOT EXISTS substitute_employee_id UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS request_status         VARCHAR(20) DEFAULT 'DRAFT',
  ADD COLUMN IF NOT EXISTS workflow_instance_id   UUID,
  ADD COLUMN IF NOT EXISTS cancellation_reason    VARCHAR(1000),
  ADD COLUMN IF NOT EXISTS cancelled_at           TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS is_backdated           SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS row_start              TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS row_end                TIMESTAMPTZ DEFAULT '9999-12-31 23:59:59.999999+00',
  ADD COLUMN IF NOT EXISTS is_current             SMALLINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS created_by             UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS updated_by             UUID REFERENCES employees(id),
  ADD COLUMN IF NOT EXISTS is_deleted             SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS approved_by_id         UUID REFERENCES employees(id);

UPDATE leave_requests SET request_id = gen_random_uuid() WHERE request_id IS NULL;
UPDATE leave_requests SET request_status = status WHERE request_status IS NULL AND status IS NOT NULL;

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE daily_attendance_summaries;
ALTER PUBLICATION supabase_realtime ADD TABLE attendance_events;
ALTER PUBLICATION supabase_realtime ADD TABLE leave_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE leave_balances;
