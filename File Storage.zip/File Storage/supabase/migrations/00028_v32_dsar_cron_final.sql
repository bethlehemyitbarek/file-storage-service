-- Remove previous failed job if it exists
SELECT cron.unschedule('dsar-deadline-reminder-daily');

-- Create helper function in public schema
CREATE OR REPLACE FUNCTION trigger_dsar_deadline_reminder()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _url text := 'https://jqzzslutgqlkpbsvbckd.supabase.co/functions/v1/dsar-deadline-reminder';
  _key text;
BEGIN
  -- Try to read service role key from vault
  BEGIN
    SELECT decrypted_secret INTO _key
    FROM vault.decrypted_secrets
    WHERE name = 'SUPABASE_SERVICE_ROLE_KEY'
    LIMIT 1;
  EXCEPTION WHEN OTHERS THEN
    _key := NULL;
  END;

  PERFORM net.http_post(
    url     := _url,
    headers := jsonb_build_object(
      'Content-Type',  'application/json',
      'Authorization', 'Bearer ' || COALESCE(_key, '')
    ),
    body    := '{}'::jsonb
  );
END;
$$;

-- Grant execute to postgres role (used by pg_cron)
GRANT EXECUTE ON FUNCTION trigger_dsar_deadline_reminder() TO postgres;

-- Schedule: every day at 08:00 UTC
SELECT cron.schedule(
  'dsar-deadline-reminder-daily',
  '0 8 * * *',
  'SELECT trigger_dsar_deadline_reminder()'
);