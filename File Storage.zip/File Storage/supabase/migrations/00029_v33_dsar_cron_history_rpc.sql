-- RPC function: return last 10 pg_cron run details for the DSAR deadline reminder job
-- Accessible from the frontend via supabase.rpc('get_dsar_cron_history')
CREATE OR REPLACE FUNCTION get_dsar_cron_history()
RETURNS TABLE (
  runid           bigint,
  jobid           bigint,
  job_pid         integer,
  database        text,
  username        text,
  command         text,
  status          text,
  return_message  text,
  start_time      timestamptz,
  end_time        timestamptz
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    jrd.runid,
    jrd.jobid,
    jrd.job_pid,
    jrd.database,
    jrd.username,
    jrd.command,
    jrd.status,
    jrd.return_message,
    jrd.start_time,
    jrd.end_time
  FROM cron.job_run_details jrd
  JOIN cron.job             j    ON j.jobid = jrd.jobid
  WHERE j.jobname = 'dsar-deadline-reminder-daily'
  ORDER BY jrd.start_time DESC
  LIMIT 10;
$$;

-- Allow authenticated users (HR admins) to call this function
GRANT EXECUTE ON FUNCTION get_dsar_cron_history() TO authenticated;