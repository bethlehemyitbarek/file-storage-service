
-- Enable RLS on all tables
ALTER TABLE business_units ENABLE ROW LEVEL SECURITY;
ALTER TABLE divisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_centers ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE dependants ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_education ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_work_experience ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE employment_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE overtime_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public_holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE salary_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_salary_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_postings ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_cycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE training_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefit_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_repayments ENABLE ROW LEVEL SECURITY;
ALTER TABLE transfer_promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding_checklists ENABLE ROW LEVEL SECURITY;
ALTER TABLE onboarding_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_onboarding ENABLE ROW LEVEL SECURITY;
ALTER TABLE separation_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE disciplinary_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE grievance_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE expense_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE timesheets ENABLE ROW LEVEL SECURITY;
ALTER TABLE timesheet_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE policy_acknowledgements ENABLE ROW LEVEL SECURITY;

-- Allow full access for authenticated users (HRMS internal tool)
-- Reference tables - read by all authenticated
CREATE POLICY "allow_authenticated_read" ON business_units FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON business_units FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON divisions FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON divisions FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON departments FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON departments FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON sections FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON sections FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON teams FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON teams FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON locations FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON locations FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON cost_centers FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON cost_centers FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON job_grades FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON job_grades FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON positions FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON positions FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON employees FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON employees FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON emergency_contacts FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON dependants FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_education FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_work_experience FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_bank_accounts FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employment_details FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_contracts FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON shifts FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON shifts FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON work_schedules FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON attendance_records FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON overtime_requests FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON leave_types FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON leave_types FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON leave_balances FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON leave_requests FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_read" ON public_holidays FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON public_holidays FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON payroll_periods FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON payroll_records FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_read" ON salary_components FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON salary_components FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_salary_components FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON job_postings FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON candidates FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON interviews FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON performance_cycles FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON performance_goals FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON performance_reviews FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON training_programs FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON training_programs FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON training_sessions FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON training_enrollments FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON benefit_plans FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON benefit_plans FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_benefits FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON loan_applications FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON loan_repayments FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON transfer_promotions FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON onboarding_checklists FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON onboarding_checklists FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_read" ON onboarding_tasks FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON onboarding_tasks FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON employee_onboarding FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON separation_requests FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON disciplinary_cases FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON grievance_cases FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_all" ON documents FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON assets FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON notifications FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON expense_claims FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON expense_items FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON timesheets FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON timesheet_entries FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_authenticated_read" ON compliance_policies FOR SELECT TO authenticated USING (true);
CREATE POLICY "allow_authenticated_all" ON compliance_policies FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "allow_authenticated_all" ON policy_acknowledgements FOR ALL TO authenticated USING (true) WITH CHECK (true);
