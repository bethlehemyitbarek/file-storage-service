
-- ═══════════════════════════════════════════════════
-- MODULE 11: COMPENSATION AND BENEFITS
-- ═══════════════════════════════════════════════════

-- 11.1 AllowanceType
CREATE TABLE allowance_types (
  row_id                UUID NOT NULL DEFAULT gen_random_uuid(),
  allowance_type_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL,
  allowance_code        VARCHAR(50) NOT NULL,
  allowance_name        VARCHAR(200) NOT NULL,
  allowance_category    VARCHAR(30) NOT NULL CHECK (allowance_category IN ('TRANSPORT','HOUSING','MEAL','COMMUNICATION','HARDSHIP','POSITION','REPRESENTATION','FUEL','OTHER')),
  calculation_method    VARCHAR(20) NOT NULL CHECK (calculation_method IN ('FIXED','PERCENTAGE_OF_BASIC','PERCENTAGE_OF_GROSS','FORMULA')),
  default_amount        DECIMAL(18,2),
  default_percentage    DECIMAL(5,2),
  is_taxable            SMALLINT NOT NULL DEFAULT 1,
  is_pensionable        SMALLINT NOT NULL DEFAULT 0,
  frequency             VARCHAR(20) NOT NULL DEFAULT 'MONTHLY' CHECK (frequency IN ('MONTHLY','QUARTERLY','ANNUAL','ONE_TIME')),
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_current            SMALLINT DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_allowance_type_code UNIQUE (tenant_id, allowance_code)
);

-- 11.2 CompensationStructure
CREATE TABLE compensation_structures (
  row_id                UUID NOT NULL DEFAULT gen_random_uuid(),
  structure_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL,
  structure_name        VARCHAR(200) NOT NULL,
  structure_code        VARCHAR(50) NOT NULL,
  structure_type        VARCHAR(20) NOT NULL DEFAULT 'HYBRID' CHECK (structure_type IN ('PAYROLL','COMPENSATION','HYBRID')),
  description           VARCHAR(2000),
  effective_from        DATE NOT NULL,
  effective_to          DATE,
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  version_number        INTEGER NOT NULL DEFAULT 1,
  workflow_instance_id  UUID,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  is_current            SMALLINT NOT NULL DEFAULT 1,
  CONSTRAINT uq_comp_structure_code UNIQUE (tenant_id, structure_code)
);
CREATE INDEX idx_comp_structure_type ON compensation_structures (tenant_id, structure_type);

-- 11.3 CompensationComponent
CREATE TABLE compensation_components (
  row_id                       UUID NOT NULL DEFAULT gen_random_uuid(),
  component_id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                    UUID NOT NULL,
  structure_id                 UUID NOT NULL REFERENCES compensation_structures(structure_id),
  component_name               VARCHAR(200) NOT NULL,
  component_code               VARCHAR(50) NOT NULL,
  component_type               VARCHAR(20) NOT NULL CHECK (component_type IN ('EARNING','DEDUCTION','EMPLOYER_CONTRIBUTION')),
  component_subtype            VARCHAR(30) CHECK (component_subtype IN ('BASIC_SALARY','ALLOWANCE','BONUS','OVERTIME','COMMISSION','TAX','PENSION','SOCIAL_SECURITY','LOAN_REPAYMENT','BENEFIT','OTHER')),
  calculation_method           VARCHAR(20) NOT NULL CHECK (calculation_method IN ('FIXED','PERCENTAGE','FORMULA','TABLE_LOOKUP')),
  formula                      VARCHAR(2000),
  default_value                DECIMAL(18,2),
  is_taxable                   SMALLINT NOT NULL DEFAULT 1,
  is_pensionable               SMALLINT NOT NULL DEFAULT 0,
  source                       VARCHAR(20) DEFAULT 'STANDARD' CHECK (source IN ('STANDARD','STATUTORY','ALLOWANCE','BENEFIT','LOAN','CUSTOM')),
  statutory_deduction_type_id  UUID,
  display_order                INTEGER,
  effective_from               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to                 TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                      TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  created_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                   UUID,
  updated_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                   UUID,
  is_active                    SMALLINT NOT NULL DEFAULT 1,
  is_deleted                   SMALLINT NOT NULL DEFAULT 0,
  is_current                   SMALLINT NOT NULL DEFAULT 1,
  CONSTRAINT uq_comp_component_code UNIQUE (tenant_id, structure_id, component_code)
);
CREATE INDEX idx_comp_component_structure ON compensation_components (tenant_id, structure_id);
CREATE INDEX idx_comp_component_type ON compensation_components (tenant_id, component_type);
CREATE INDEX idx_comp_component_source ON compensation_components (tenant_id, source);

-- 11.4 EmployeeCompensation
CREATE TABLE employee_compensations (
  row_id                UUID NOT NULL DEFAULT gen_random_uuid(),
  compensation_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL,
  employee_id           UUID NOT NULL,
  structure_id          UUID REFERENCES compensation_structures(structure_id),
  base_salary           DECIMAL(18,2) NOT NULL,
  currency_code         CHAR(3) NOT NULL DEFAULT 'ETB',
  payment_type          VARCHAR(20) NOT NULL CHECK (payment_type IN ('MONTHLY','DAILY','HOURLY','WEEKLY')),
  effective_from        DATE NOT NULL,
  effective_to          DATE,
  row_start             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reason                VARCHAR(1000),
  workflow_instance_id  UUID,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  is_current            SMALLINT DEFAULT 1
);
CREATE INDEX idx_emp_compensation_emp ON employee_compensations (tenant_id, employee_id, is_active);
CREATE INDEX idx_emp_compensation_from ON employee_compensations (tenant_id, effective_from);

-- 11.5 BonusConfiguration
CREATE TABLE bonus_configurations (
  bonus_config_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id             UUID NOT NULL,
  bonus_name            VARCHAR(200) NOT NULL,
  bonus_code            VARCHAR(50) NOT NULL,
  bonus_type            VARCHAR(20) NOT NULL CHECK (bonus_type IN ('PERFORMANCE','ANNUAL','SPOT','RETENTION','OTHER')),
  calculation_method    VARCHAR(20) CHECK (calculation_method IN ('FIXED','PERCENTAGE','FORMULA')),
  default_value         DECIMAL(18,2),
  cycle_frequency       VARCHAR(20) CHECK (cycle_frequency IN ('MONTHLY','QUARTERLY','SEMI_ANNUAL','ANNUAL','ONE_TIME')),
  effective_from        DATE NOT NULL,
  effective_to          DATE,
  workflow_instance_id  UUID,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by            UUID,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by            UUID,
  is_active             SMALLINT NOT NULL DEFAULT 1,
  is_deleted            SMALLINT NOT NULL DEFAULT 0,
  CONSTRAINT uq_bonus_code UNIQUE (tenant_id, bonus_code)
);

-- 11.6 BenefitPlan
CREATE TABLE benefit_plans (
  row_id                   UUID NOT NULL DEFAULT gen_random_uuid(),
  benefit_plan_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                UUID NOT NULL,
  plan_name                VARCHAR(200) NOT NULL,
  plan_code                VARCHAR(50) NOT NULL,
  plan_type                VARCHAR(30) NOT NULL CHECK (plan_type IN ('MEDICAL','DENTAL','VISION','LIFE_INSURANCE','PENSION','DISABILITY','OTHER')),
  provider_name            VARCHAR(200),
  effective_start_date     DATE NOT NULL,
  effective_end_date       DATE NOT NULL,
  min_service_months       INTEGER DEFAULT 0,
  eligible_employment_type VARCHAR(20) DEFAULT 'ALL' CHECK (eligible_employment_type IN ('FULL_TIME','PART_TIME','CONTRACT','ALL')),
  min_age                  INTEGER,
  max_age                  INTEGER,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by               UUID,
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by               UUID,
  is_active                SMALLINT NOT NULL DEFAULT 1,
  is_deleted               SMALLINT NOT NULL DEFAULT 0,
  is_current               SMALLINT NOT NULL DEFAULT 0,
  effective_from           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to             TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                  TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  CONSTRAINT uq_benefit_plan_code UNIQUE (tenant_id, plan_code)
);
CREATE INDEX idx_benefit_plan_type ON benefit_plans (tenant_id, plan_type);

-- 11.7 CoverageTier
CREATE TABLE coverage_tiers (
  row_id                             UUID NOT NULL DEFAULT gen_random_uuid(),
  coverage_tier_id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                          UUID NOT NULL,
  benefit_plan_id                    UUID NOT NULL REFERENCES benefit_plans(benefit_plan_id),
  tier_name                          VARCHAR(100) NOT NULL,
  max_dependents                     INTEGER,
  employee_contribution_percent      DECIMAL(18,2),
  employer_contribution_percent      DECIMAL(18,2),
  premium_amount                     DECIMAL(18,2),
  created_at                         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                         UUID,
  updated_at                         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                         UUID,
  is_active                          SMALLINT NOT NULL DEFAULT 1,
  is_deleted                         SMALLINT NOT NULL DEFAULT 0,
  is_current                         SMALLINT NOT NULL DEFAULT 0,
  effective_from                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to                       TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                            TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);
CREATE INDEX idx_coverage_tier_plan ON coverage_tiers (tenant_id, benefit_plan_id);

-- 11.8 BenefitEnrollment
CREATE TABLE benefit_enrollments (
  row_id                         UUID NOT NULL DEFAULT gen_random_uuid(),
  benefit_enrollment_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id                      UUID NOT NULL,
  benefit_plan_id                UUID REFERENCES benefit_plans(benefit_plan_id),
  employee_id                    UUID NOT NULL,
  coverage_tier_id               UUID NOT NULL REFERENCES coverage_tiers(coverage_tier_id),
  life_event_type                VARCHAR(30) CHECK (life_event_type IN ('NEW_HIRE','MARRIAGE','BIRTH','DIVORCE','TERMINATION','OPEN_ENROLLMENT','OTHER')),
  enrollment_status              VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (enrollment_status IN ('PENDING','ACTIVE','CANCELLED','EXPIRED')),
  employee_deduction_monthly     DECIMAL(18,2),
  employer_contribution_monthly  DECIMAL(18,2),
  enrollment_date                DATE NOT NULL,
  effective_date                 DATE NOT NULL,
  termination_date               DATE,
  created_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by                     UUID,
  updated_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by                     UUID,
  is_active                      SMALLINT NOT NULL DEFAULT 1,
  is_deleted                     SMALLINT NOT NULL DEFAULT 0,
  is_current                     SMALLINT NOT NULL DEFAULT 0,
  effective_from                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  effective_to                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00',
  row_start                      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  row_end                        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31 23:59:59+00'
);
CREATE INDEX idx_benefit_enrollment_emp ON benefit_enrollments (tenant_id, employee_id);
CREATE INDEX idx_benefit_enrollment_plan ON benefit_enrollments (tenant_id, benefit_plan_id);
CREATE INDEX idx_benefit_enrollment_status ON benefit_enrollments (tenant_id, enrollment_status);

-- RLS
ALTER TABLE allowance_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE compensation_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE compensation_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_compensations ENABLE ROW LEVEL SECURITY;
ALTER TABLE bonus_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefit_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE coverage_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefit_enrollments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_all_allowance_types" ON allowance_types FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_compensation_structures" ON compensation_structures FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_compensation_components" ON compensation_components FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_employee_compensations" ON employee_compensations FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_bonus_configurations" ON bonus_configurations FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_benefit_plans" ON benefit_plans FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_coverage_tiers" ON coverage_tiers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_benefit_enrollments" ON benefit_enrollments FOR ALL USING (true) WITH CHECK (true);
