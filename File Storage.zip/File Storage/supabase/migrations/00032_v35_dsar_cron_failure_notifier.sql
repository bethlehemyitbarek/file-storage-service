-- Function: notify HR admins when the DSAR cron job's last run had status='failed'
-- Called by a pg_cron job that runs 5 minutes after the main job finishes.

CREATE OR REPLACE FUNCTION notify_dsar_cron_failure()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_last_status   text;
  v_last_msg      text;
  v_run_id        bigint;
  v_hr_id         uuid;
BEGIN
  -- Get the most recent run of the DSAR cron job
  SELECT r.status, r.return_message, r.runid
  INTO v_last_status, v_last_msg, v_run_id
  FROM cron.job_run_details r
  JOIN cron.job j ON j.jobid = r.jobid
  WHERE j.jobname = 'send-dsar-reminders'
  ORDER BY r.start_time DESC
  LIMIT 1;

  -- Only notify on 'failed' status
  IF v_last_status IS DISTINCT FROM 'failed' THEN
    RETURN;
  END IF;

  -- Check we haven't already notified for this run (idempotency)
  IF EXISTS (
    SELECT 1 FROM notifications
    WHERE notification_type = 'DSAR_CRON_FAILED'
      AND entity_id = v_run_id::text::uuid  -- store run_id as reference
  ) THEN
    RETURN;
  END IF;

  -- Insert a notification for every HR admin / HR manager / super_admin
  INSERT INTO notifications (
    recipient_id,
    title,
    message,
    notification_type,
    module,
    is_read,
    created_at,
    action_url
  )
  SELECT
    p.id,
    '⚠️ DSAR Cron Job Failed',
    COALESCE(
      'The DSAR deadline reminder job (run #' || v_run_id || ') failed: '
        || left(v_last_msg, 200),
      'The DSAR deadline reminder cron job reported a failure. Please check the DSAR Admin page.'
    ),
    'DSAR_CRON_FAILED',
    'dsar',
    false,
    now(),
    '/compliance/dsar-admin'
  FROM profiles p
  WHERE p.role IN ('hr_admin', 'hr_manager', 'super_admin');
END;
$$;

GRANT EXECUTE ON FUNCTION notify_dsar_cron_failure() TO postgres;

-- Schedule the failure-checker to run 10 min after the main DSAR cron (which runs at 08:00 UTC)
SELECT cron.schedule(
  'check-dsar-cron-failure',
  '10 8 * * *',
  $$SELECT notify_dsar_cron_failure();$$
);