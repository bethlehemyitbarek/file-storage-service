
INSERT INTO file_metadata (
  row_id, document_id, tenant_id, user_id,
  file_name, mime_type, size_kb, version, status,
  description, checksum, storage_path, storage_tier, encryption_status,
  effective_from, effective_to, is_current, created_at, created_by, updated_at
) VALUES
(
  gen_random_uuid(), 'aaaaaaaa-0001-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'Q3-Financial-Report.pdf', 'application/pdf', 1842, 3, 'ACTIVE',
  'Q3 2025 quarterly financial performance report',
  'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2',
  '', 'HOT', 'ENCRYPTED',
  now() - interval '10 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '10 days', '00000000-0000-0000-0000-000000000002', now() - interval '2 days'
),
(
  gen_random_uuid(), 'aaaaaaaa-0002-0000-0000-000000000002',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'Product-Roadmap-2026.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 245, 2, 'ACTIVE',
  '2026 product roadmap and feature planning document',
  'b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3',
  '', 'HOT', 'UNENCRYPTED',
  now() - interval '7 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '7 days', '00000000-0000-0000-0000-000000000002', now() - interval '1 day'
),
(
  gen_random_uuid(), 'aaaaaaaa-0003-0000-0000-000000000003',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'Architecture-Diagram.png', 'image/png', 892, 1, 'ACTIVE',
  'System architecture diagram for the storage platform',
  'c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4',
  '', 'HOT', 'UNENCRYPTED',
  now() - interval '5 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '5 days', '00000000-0000-0000-0000-000000000002', now() - interval '5 days'
),
(
  gen_random_uuid(), 'aaaaaaaa-0004-0000-0000-000000000004',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'API-Reference.json', 'application/json', 128, 5, 'ACTIVE',
  'REST API reference specification (OpenAPI 3.0)',
  'd4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5',
  '', 'HOT', 'UNENCRYPTED',
  now() - interval '14 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '14 days', '00000000-0000-0000-0000-000000000002', now() - interval '3 hours'
),
(
  gen_random_uuid(), 'aaaaaaaa-0005-0000-0000-000000000005',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'Employee-Handbook.pdf', 'application/pdf', 3412, 1, 'ACTIVE',
  'Company employee handbook — policies and procedures',
  'e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6',
  '', 'WARM', 'ENCRYPTED',
  now() - interval '30 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '30 days', '00000000-0000-0000-0000-000000000002', now() - interval '30 days'
),
(
  gen_random_uuid(), 'aaaaaaaa-0006-0000-0000-000000000006',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'database-schema.sql', 'text/plain', 64, 7, 'ACTIVE',
  'Production database schema — latest version',
  'f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1',
  '', 'HOT', 'UNENCRYPTED',
  now() - interval '2 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '2 days', '00000000-0000-0000-0000-000000000002', now() - interval '2 hours'
),
(
  gen_random_uuid(), 'aaaaaaaa-0007-0000-0000-000000000007',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'Marketing-Assets.zip', 'application/zip', 15360, 1, 'ARCHIVED',
  'Q2 2025 marketing campaign assets archive',
  'a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b3',
  '', 'COLD', 'ENCRYPTED',
  now() - interval '60 days', '9999-12-31 23:59:59+00', 1,
  now() - interval '60 days', '00000000-0000-0000-0000-000000000002', now() - interval '60 days'
),
(
  gen_random_uuid(), 'aaaaaaaa-0008-0000-0000-000000000008',
  '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002',
  'meeting-notes-2026-06.txt', 'text/plain', 18, 2, 'ACTIVE',
  'June 2026 all-hands meeting notes and action items',
  'b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b3c4',
  '', 'HOT', 'UNENCRYPTED',
  now() - interval '1 day', '9999-12-31 23:59:59+00', 1,
  now() - interval '1 day', '00000000-0000-0000-0000-000000000002', now() - interval '4 hours'
);
