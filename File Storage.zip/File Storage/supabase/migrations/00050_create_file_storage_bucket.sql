
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('file-storage', 'file-storage', true, 52428800, null);

CREATE POLICY "anon_select_storage"
  ON storage.objects FOR SELECT TO anon USING (bucket_id = 'file-storage');

CREATE POLICY "anon_insert_storage"
  ON storage.objects FOR INSERT TO anon WITH CHECK (bucket_id = 'file-storage');

CREATE POLICY "anon_update_storage"
  ON storage.objects FOR UPDATE TO anon USING (bucket_id = 'file-storage');

CREATE POLICY "anon_delete_storage"
  ON storage.objects FOR DELETE TO anon USING (bucket_id = 'file-storage');
