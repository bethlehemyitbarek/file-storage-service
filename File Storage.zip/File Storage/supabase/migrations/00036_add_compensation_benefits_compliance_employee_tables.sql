
-- ── Compensation Hub new tables ──────────────────────────────────────────────

-- Merit Matrix (FR-Comp-25)
CREATE TABLE merit_matrix (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  performance_rating  text NOT NULL,
  position_in_range   text NOT NULL,
  merit_pct           numeric(5,2) NOT NULL DEFAULT 0,
  updated_at          timestamptz DEFAULT now(),
  UNIQUE (performance_rating, position_in_range)
);

-- Compensation Budgets (FR-Comp-24)
CREATE TABLE compensation_budgets (
  budget_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dept_name         text,
  fiscal_year       text NOT NULL,
  total_budget      numeric(15,2) NOT NULL,
  committed         numeric(15,2) DEFAULT 0,
  remaining         numeric(15,2) GENERATED ALWAYS AS (total_budget - committed) STORED,
  utilization_pct   numeric(6,2) GENERATED ALWAYS AS (CASE WHEN total_budget > 0 THEN ROUND((committed / total_budget) * 100, 2) ELSE 0 END) STORED,
  notes             text,
  created_at        timestamptz DEFAULT now()
);

-- Compensation Exceptions (FR-Comp-26)
CREATE TABLE compensation_exceptions (
  exception_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id       uuid NOT NULL,
  full_name         text,
  request_type      text NOT NULL,
  current_amount    numeric(15,2),
  proposed_amount   numeric(15,2),
  reason            text,
  status            text NOT NULL DEFAULT 'PENDING',
  requested_date    date DEFAULT CURRENT_DATE,
  approved_by       text,
  approved_at       timestamptz,
  created_at        timestamptz DEFAULT now()
);

-- ── Benefits new tables ───────────────────────────────────────────────────────

-- Life Events (FR-BEN-007)
CREATE TABLE benefit_life_events (
  event_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id       uuid NOT NULL,
  event_type        text NOT NULL,
  event_date        date DEFAULT CURRENT_DATE,
  supporting_doc    text,
  status            text DEFAULT 'PENDING_REVIEW',
  notes             text,
  created_at        timestamptz DEFAULT now()
);

-- Benefit Cost Tracking (FR-BEN-008/009)
CREATE TABLE benefit_cost_tracking (
  cost_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name         text NOT NULL,
  period            text,
  total_enrolled    integer,
  employer_cost     numeric(15,2),
  employee_cost     numeric(15,2),
  notes             text,
  created_at        timestamptz DEFAULT now()
);

-- Carrier Billing (FR-BEN-010)
CREATE TABLE carrier_billing (
  billing_id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  carrier_name      text NOT NULL,
  plan_name         text,
  billing_period    text,
  billed_amount     numeric(15,2),
  expected_amount   numeric(15,2),
  variance          numeric(15,2) GENERATED ALWAYS AS (billed_amount - expected_amount) STORED,
  status            text DEFAULT 'PENDING',
  notes             text,
  created_at        timestamptz DEFAULT now()
);

-- ── Compliance new tables ─────────────────────────────────────────────────────

-- Warning Letter Templates (FR-CG-012)
CREATE TABLE warning_letter_templates (
  template_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_name     text NOT NULL,
  warning_level     text NOT NULL DEFAULT 'VERBAL',
  subject           text,
  body_template     text,
  created_at        timestamptz DEFAULT now()
);

-- Progressive Discipline (FR-CG-013)
CREATE TABLE progressive_discipline (
  pd_id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id       uuid NOT NULL,
  full_name         text,
  incident_date     date DEFAULT CURRENT_DATE,
  incident_type     text DEFAULT 'CONDUCT',
  action_taken      text NOT NULL,
  issued_by         text,
  notes             text,
  status            text DEFAULT 'ACTIVE',
  created_at        timestamptz DEFAULT now()
);

-- ── Employee Change History (FR-EM-024) ───────────────────────────────────────
CREATE TABLE employee_change_history (
  change_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id       uuid,
  full_name         text,
  change_type       text,
  field_name        text,
  old_value         text,
  new_value         text,
  changed_by        text,
  change_date       timestamptz DEFAULT now(),
  reason            text
);

-- ── Org Restructuring (FR-OSM-012) ────────────────────────────────────────────
CREATE TABLE org_restructuring (
  restructure_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title             text NOT NULL,
  restructure_type  text NOT NULL DEFAULT 'REORGANIZATION',
  effective_date    date,
  status            text DEFAULT 'DRAFT',
  scope             text,
  rationale         text,
  approved_by       text,
  created_at        timestamptz DEFAULT now()
);

CREATE TABLE org_restructuring_units (
  unit_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restructure_id    uuid NOT NULL REFERENCES org_restructuring(restructure_id) ON DELETE CASCADE,
  unit_type         text NOT NULL DEFAULT 'DEPARTMENT',
  unit_name         text NOT NULL,
  action            text NOT NULL DEFAULT 'MERGE',
  new_name          text,
  new_parent        text,
  employee_count    integer,
  notes             text,
  created_at        timestamptz DEFAULT now()
);

-- ── RLS (public read/write — no auth required for now) ───────────────────────
ALTER TABLE merit_matrix              ENABLE ROW LEVEL SECURITY;
ALTER TABLE compensation_budgets      ENABLE ROW LEVEL SECURITY;
ALTER TABLE compensation_exceptions   ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefit_life_events       ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefit_cost_tracking     ENABLE ROW LEVEL SECURITY;
ALTER TABLE carrier_billing           ENABLE ROW LEVEL SECURITY;
ALTER TABLE warning_letter_templates  ENABLE ROW LEVEL SECURITY;
ALTER TABLE progressive_discipline    ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_change_history   ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_restructuring         ENABLE ROW LEVEL SECURITY;
ALTER TABLE org_restructuring_units   ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_all_merit_matrix"              ON merit_matrix              FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_compensation_budgets"      ON compensation_budgets      FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_compensation_exceptions"   ON compensation_exceptions   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_benefit_life_events"       ON benefit_life_events       FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_benefit_cost_tracking"     ON benefit_cost_tracking     FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_carrier_billing"           ON carrier_billing           FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_warning_letter_templates"  ON warning_letter_templates  FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_progressive_discipline"    ON progressive_discipline    FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_employee_change_history"   ON employee_change_history   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_org_restructuring"         ON org_restructuring         FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_org_restructuring_units"   ON org_restructuring_units   FOR ALL USING (true) WITH CHECK (true);
