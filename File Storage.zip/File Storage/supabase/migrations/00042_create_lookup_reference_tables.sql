
-- ════════════════════════════════════════════════════════════════
-- R.1  Country
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_countries (
  country_id      uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code    char(3)     NOT NULL UNIQUE,
  country_code_2  char(2)     NOT NULL UNIQUE,
  country_name    varchar(200) NOT NULL,
  nationality_name varchar(200),
  phone_code      varchar(10),
  currency_code   char(3),
  region_name     varchar(100),
  is_active       boolean     NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_lookup_countries_name ON lookup_countries(country_name);

-- ════════════════════════════════════════════════════════════════
-- R.2  Currency
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_currencies (
  currency_id     uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  currency_code   char(3)     NOT NULL UNIQUE,
  currency_name   varchar(100) NOT NULL,
  currency_symbol varchar(10),
  decimal_places  integer     NOT NULL DEFAULT 2,
  is_active       boolean     NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- R.3  Exchange Rate
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_exchange_rates (
  exchange_rate_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  from_currency_code char(3)     NOT NULL,
  to_currency_code   char(3)     NOT NULL,
  rate               numeric(18,8) NOT NULL,
  effective_date     date        NOT NULL,
  source             varchar(50) DEFAULT 'MANUAL',
  is_active          boolean     NOT NULL DEFAULT true,
  is_deleted         boolean     NOT NULL DEFAULT false,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE(from_currency_code, to_currency_code, effective_date)
);
CREATE INDEX idx_exchange_rates_date ON lookup_exchange_rates(effective_date DESC);

-- ════════════════════════════════════════════════════════════════
-- R.4  Bank
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_banks (
  bank_id      uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_code    varchar(20) NOT NULL UNIQUE,
  bank_name    varchar(200) NOT NULL,
  swift_code   varchar(20),
  country_code char(3),
  is_active    boolean     NOT NULL DEFAULT true,
  is_deleted   boolean     NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_lookup_banks_name ON lookup_banks(bank_name);

-- ════════════════════════════════════════════════════════════════
-- R.5  Bank Branch
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_bank_branches (
  bank_branch_id uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_id        uuid        NOT NULL REFERENCES lookup_banks(bank_id),
  branch_code    varchar(20) NOT NULL,
  branch_name    varchar(200) NOT NULL,
  city           varchar(100),
  address        varchar(500),
  is_active      boolean     NOT NULL DEFAULT true,
  is_deleted     boolean     NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE(bank_id, branch_code)
);
CREATE INDEX idx_bank_branches_bank ON lookup_bank_branches(bank_id);

-- ════════════════════════════════════════════════════════════════
-- R.6  Region Master
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_regions (
  region_id        uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  country_code     char(3)     NOT NULL,
  region_code      varchar(20) NOT NULL,
  region_name      varchar(200) NOT NULL,
  region_level     varchar(20) NOT NULL CHECK (region_level IN ('REGION','ZONE','WOREDA','KEBELE','STATE','PROVINCE','COUNTY')),
  parent_region_id uuid        REFERENCES lookup_regions(region_id),
  is_active        boolean     NOT NULL DEFAULT true,
  is_deleted       boolean     NOT NULL DEFAULT false,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE(country_code, region_code)
);
CREATE INDEX idx_regions_parent ON lookup_regions(parent_region_id);
CREATE INDEX idx_regions_level  ON lookup_regions(region_level);

-- ════════════════════════════════════════════════════════════════
-- R.7  Language
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_languages (
  language_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  language_code varchar(10) NOT NULL UNIQUE,
  language_name varchar(100) NOT NULL,
  is_active     boolean     NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- R.9  Skill
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_skills (
  skill_id       uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_name     varchar(200) NOT NULL,
  skill_code     varchar(50) NOT NULL UNIQUE,
  skill_category varchar(50) NOT NULL CHECK (skill_category IN ('TECHNICAL','SOFT','LEADERSHIP','DOMAIN','LANGUAGE','CERTIFICATION')),
  description    varchar(1000),
  is_active      boolean     NOT NULL DEFAULT true,
  is_deleted     boolean     NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_skills_category ON lookup_skills(skill_category);

-- ════════════════════════════════════════════════════════════════
-- R.11  Religion
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_religions (
  religion_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  religion_name varchar(100) NOT NULL UNIQUE,
  is_active     boolean     NOT NULL DEFAULT true,
  is_deleted    boolean     NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- R.12  Ethnicity
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_ethnicities (
  ethnicity_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  ethnicity_name varchar(100) NOT NULL UNIQUE,
  is_active      boolean     NOT NULL DEFAULT true,
  is_deleted     boolean     NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- R.13  Title
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_titles (
  title_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  title_code varchar(10) NOT NULL UNIQUE,
  title_name varchar(50) NOT NULL,
  is_active  boolean     NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- T.1  Tax Bracket
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_tax_brackets (
  tax_bracket_id    uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  tax_jurisdiction  varchar(50)   NOT NULL,
  bracket_name      varchar(100)  NOT NULL,
  min_income        numeric(18,2) NOT NULL,
  max_income        numeric(18,2),
  tax_rate          numeric(5,4)  NOT NULL,
  fixed_amount      numeric(18,2) NOT NULL DEFAULT 0,
  effective_from    date          NOT NULL,
  effective_to      date,
  is_active         boolean       NOT NULL DEFAULT true,
  is_deleted        boolean       NOT NULL DEFAULT false,
  created_at        timestamptz   NOT NULL DEFAULT now(),
  updated_at        timestamptz   NOT NULL DEFAULT now()
);
CREATE INDEX idx_tax_brackets_jurisdiction ON lookup_tax_brackets(tax_jurisdiction, effective_from);

-- ════════════════════════════════════════════════════════════════
-- T.2  Pension Schema
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_pension_schemas (
  pension_scheme_id          uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  scheme_name                varchar(200)  NOT NULL,
  scheme_code                varchar(50)   NOT NULL UNIQUE,
  employee_contribution_rate numeric(5,4)  NOT NULL,
  employer_contribution_rate numeric(5,4)  NOT NULL,
  max_pensionable_salary     numeric(18,2),
  effective_from             date          NOT NULL,
  effective_to               date,
  country_code               char(3),
  statutory_reference        varchar(200),
  is_active                  boolean       NOT NULL DEFAULT true,
  is_deleted                 boolean       NOT NULL DEFAULT false,
  created_at                 timestamptz   NOT NULL DEFAULT now(),
  updated_at                 timestamptz   NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- T.3  Statutory Deduction Type
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_statutory_deductions (
  deduction_type_id   uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  deduction_code      varchar(50)   NOT NULL UNIQUE,
  deduction_name      varchar(200)  NOT NULL,
  deduction_category  varchar(30)   NOT NULL CHECK (deduction_category IN ('TAX','PENSION','SOCIAL_SECURITY','PROFESSIONAL_TAX','UNION_FEE','OTHER_STATUTORY')),
  calculation_method  varchar(20)   NOT NULL CHECK (calculation_method IN ('PERCENTAGE','FIXED','TABLE_LOOKUP')),
  rate_or_amount      numeric(18,4),
  applies_to          varchar(20)   DEFAULT 'BOTH' CHECK (applies_to IN ('EMPLOYEE','EMPLOYER','BOTH')),
  is_mandatory        boolean       NOT NULL DEFAULT true,
  effective_from      date          NOT NULL,
  effective_to        date,
  statutory_reference varchar(200),
  is_active           boolean       NOT NULL DEFAULT true,
  is_deleted          boolean       NOT NULL DEFAULT false,
  created_at          timestamptz   NOT NULL DEFAULT now(),
  updated_at          timestamptz   NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- J.1  Job Family
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_job_families (
  job_family_id uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  family_name   varchar(200) NOT NULL,
  family_code   varchar(50) NOT NULL UNIQUE,
  description   varchar(1000),
  is_active     boolean     NOT NULL DEFAULT true,
  is_deleted    boolean     NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ════════════════════════════════════════════════════════════════
-- J.2  Job Title Master
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_job_titles (
  job_title_id   uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  job_title_code varchar(50) NOT NULL UNIQUE,
  job_title_name varchar(200) NOT NULL,
  job_family_id  uuid        REFERENCES lookup_job_families(job_family_id),
  job_level      varchar(20) CHECK (job_level IN ('ENTRY','JUNIOR','MID','SENIOR','LEAD','MANAGER','DIRECTOR','EXECUTIVE')),
  default_grade  varchar(50),
  is_managerial  boolean     NOT NULL DEFAULT false,
  description    varchar(2000),
  is_active      boolean     NOT NULL DEFAULT true,
  is_deleted     boolean     NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_job_titles_family ON lookup_job_titles(job_family_id);
CREATE INDEX idx_job_titles_level  ON lookup_job_titles(job_level);

-- ════════════════════════════════════════════════════════════════
-- J.3  Grade
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_grades (
  grade_id       uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  grade_code     varchar(50)   NOT NULL UNIQUE,
  grade_name     varchar(200)  NOT NULL,
  grade_level    integer       NOT NULL,
  min_salary     numeric(18,2),
  mid_salary     numeric(18,2),
  max_salary     numeric(18,2),
  currency_code  char(3)       DEFAULT 'ETB',
  description    varchar(1000),
  effective_from date          NOT NULL,
  effective_to   date,
  is_active      boolean       NOT NULL DEFAULT true,
  is_deleted     boolean       NOT NULL DEFAULT false,
  created_at     timestamptz   NOT NULL DEFAULT now(),
  updated_at     timestamptz   NOT NULL DEFAULT now()
);
CREATE INDEX idx_grades_level ON lookup_grades(grade_level);

-- ════════════════════════════════════════════════════════════════
-- J.4  Step (salary steps within a grade)
-- ════════════════════════════════════════════════════════════════
CREATE TABLE lookup_steps (
  step_id                uuid          PRIMARY KEY DEFAULT gen_random_uuid(),
  grade_id               uuid          NOT NULL REFERENCES lookup_grades(grade_id),
  step_number            integer       NOT NULL,
  step_amount            numeric(18,2) NOT NULL,
  years_in_grade_required integer,
  effective_from         date          NOT NULL,
  effective_to           date,
  is_active              boolean       NOT NULL DEFAULT true,
  is_deleted             boolean       NOT NULL DEFAULT false,
  created_at             timestamptz   NOT NULL DEFAULT now(),
  updated_at             timestamptz   NOT NULL DEFAULT now(),
  UNIQUE(grade_id, step_number)
);
CREATE INDEX idx_steps_grade ON lookup_steps(grade_id);
