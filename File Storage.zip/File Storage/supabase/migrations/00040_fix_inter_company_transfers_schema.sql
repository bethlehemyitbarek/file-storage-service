
-- Extend inter_company_transfers with columns the page expects
ALTER TABLE inter_company_transfers
  ADD COLUMN source_entity          text,
  ADD COLUMN destination_entity     text,
  ADD COLUMN destination_department text,
  ADD COLUMN reviewer_comments      text,
  ADD COLUMN reviewed_at            timestamptz,
  ADD COLUMN executed_at            timestamptz;

-- Back-fill from existing columns
UPDATE inter_company_transfers SET source_entity = from_entity, destination_entity = to_entity;

-- Audit log table for inter-company transfers
CREATE TABLE ict_audit_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transfer_id uuid REFERENCES inter_company_transfers(id) ON DELETE CASCADE,
  action      text NOT NULL,
  actor_id    uuid,
  description text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE ict_audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth_all_ict_audit_logs" ON ict_audit_logs FOR ALL TO authenticated USING (true) WITH CHECK (true);
