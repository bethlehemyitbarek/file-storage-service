
-- Drop old simplified tables before creating canonical Module 11 replacements
DROP TABLE IF EXISTS employee_benefits CASCADE;
DROP TABLE IF EXISTS benefit_plans CASCADE;
