
-- ── leave_get_pass (FR-LEAVE-020/021) ──────────────────────────────────────
CREATE TABLE leave_get_pass (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id     uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  request_date    date NOT NULL,
  exit_time       time NOT NULL,
  return_time     time,
  purpose         text,
  destination     text,
  status          text NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','approved','rejected','cancelled')),
  approved_by     uuid REFERENCES employees(id),
  approved_at     timestamptz,
  rejection_note  text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE leave_get_pass ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave_get_pass_all" ON leave_get_pass FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── leave_blackout_periods (FR-LEAVE-022) ──────────────────────────────────
CREATE TABLE leave_blackout_periods (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name            text NOT NULL,
  start_date      date NOT NULL,
  end_date        date NOT NULL,
  department_id   uuid REFERENCES departments(id),
  leave_type_id   uuid REFERENCES leave_types(id),
  reason          text,
  is_active       boolean NOT NULL DEFAULT true,
  created_by      uuid REFERENCES employees(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT blackout_date_order CHECK (end_date >= start_date)
);

ALTER TABLE leave_blackout_periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave_blackout_all" ON leave_blackout_periods FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── leave_substitutions (FR-LEAVE-023) ─────────────────────────────────────
CREATE TABLE leave_substitutions (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  leave_request_id    uuid REFERENCES leave_requests(id) ON DELETE CASCADE,
  employee_id         uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  substitute_id       uuid NOT NULL REFERENCES employees(id),
  start_date          date NOT NULL,
  end_date            date NOT NULL,
  substitute_status   text NOT NULL DEFAULT 'pending'
                        CHECK (substitute_status IN ('pending','accepted','rejected')),
  notes               text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE leave_substitutions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave_substitutions_all" ON leave_substitutions FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── leave_audit_log (FR-LEAVE-030) ─────────────────────────────────────────
CREATE TABLE leave_audit_log (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  leave_request_id uuid REFERENCES leave_requests(id) ON DELETE SET NULL,
  employee_id     uuid REFERENCES employees(id),
  action          text NOT NULL,
  old_status      text,
  new_status      text NOT NULL,
  changed_by      uuid REFERENCES employees(id),
  changed_at      timestamptz NOT NULL DEFAULT now(),
  reason          text,
  metadata        jsonb
);

ALTER TABLE leave_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave_audit_all" ON leave_audit_log FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── payroll_variance_flags (FR-PR-031) ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS payroll_variance_flags (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payroll_period_id uuid REFERENCES payroll_periods(id),
  employee_id     uuid REFERENCES employees(id),
  prev_amount     numeric(14,2) NOT NULL DEFAULT 0,
  curr_amount     numeric(14,2) NOT NULL DEFAULT 0,
  variance_pct    numeric(7,2),
  flagged         boolean NOT NULL DEFAULT false,
  reviewed_by     uuid REFERENCES employees(id),
  reviewed_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE payroll_variance_flags ENABLE ROW LEVEL SECURITY;
CREATE POLICY "payroll_variance_all" ON payroll_variance_flags FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── timesheet_adjustments (FR-TS-014) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS timesheet_adjustments (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  timesheet_id    uuid REFERENCES timesheets(id) ON DELETE CASCADE,
  employee_id     uuid REFERENCES employees(id),
  adjustment_type text NOT NULL CHECK (adjustment_type IN ('add_hours','deduct_hours','correction','retro')),
  hours_delta     numeric(7,2) NOT NULL DEFAULT 0,
  reason          text,
  approved_by     uuid REFERENCES employees(id),
  approved_at     timestamptz,
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at      timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE timesheet_adjustments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "timesheet_adjustments_all" ON timesheet_adjustments FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- ── Realtime publication ────────────────────────────────────────────────────
ALTER PUBLICATION supabase_realtime ADD TABLE leave_audit_log;
ALTER PUBLICATION supabase_realtime ADD TABLE leave_get_pass;
ALTER PUBLICATION supabase_realtime ADD TABLE leave_substitutions;
