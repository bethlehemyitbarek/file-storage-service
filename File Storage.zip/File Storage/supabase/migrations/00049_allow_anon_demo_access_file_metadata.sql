
-- Allow anon role full CRUD on file_metadata for demo/preview mode
-- (no auth is wired in this app; the backend normally handles writes via service role)
CREATE POLICY "anon_select_file_metadata"
  ON file_metadata FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "anon_insert_file_metadata"
  ON file_metadata FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "anon_update_file_metadata"
  ON file_metadata FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "anon_delete_file_metadata"
  ON file_metadata FOR DELETE
  TO anon
  USING (true);
