
-- ============================================================
-- v30: Announcements, Projects, ProjectTasks, TimesheetEntries (v2), AuditLogs
-- ============================================================

-- ── 1. Announcements ──────────────────────────────────────────
CREATE TABLE announcements (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  announcement_id     UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id           UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  title               VARCHAR(100) NOT NULL,
  description         TEXT,
  type                VARCHAR(30) NOT NULL DEFAULT 'INFORMATIVE'
                        CHECK (type IN ('INFORMATIVE','EMERGENCY','PERSONAL')),
  targets             VARCHAR(30) NOT NULL DEFAULT 'ALL'
                        CHECK (targets IN ('ALL','DEPARTMENT','LOCATION','ROLE','CUSTOM')),
  target_criteria     JSONB,
  priority            VARCHAR(10) NOT NULL DEFAULT 'NORMAL'
                        CHECK (priority IN ('LOW','NORMAL','HIGH','URGENT')),
  published_at        TIMESTAMPTZ,
  announcement_status VARCHAR(20) NOT NULL DEFAULT 'DRAFT'
                        CHECK (announcement_status IN ('DRAFT','PUBLISHED','ARCHIVED')),
  expiry_date         TIMESTAMPTZ,
  posted_by           UUID REFERENCES employees(id) ON DELETE SET NULL,
  is_active           SMALLINT NOT NULL DEFAULT 1,
  is_current          SMALLINT NOT NULL DEFAULT 1,
  is_deleted          SMALLINT NOT NULL DEFAULT 0,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by          UUID REFERENCES employees(id) ON DELETE SET NULL,
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by          UUID REFERENCES employees(id) ON DELETE SET NULL
);

CREATE INDEX idx_announcements_tenant_status   ON announcements (tenant_id, announcement_status);
CREATE INDEX idx_announcements_tenant_pub      ON announcements (tenant_id, published_at);

-- ── 2. Projects ───────────────────────────────────────────────
CREATE TABLE projects (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id      UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id       UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_name    VARCHAR(200) NOT NULL,
  project_code    VARCHAR(50)  NOT NULL,
  description     VARCHAR(2000),
  manager_id      UUID REFERENCES employees(id) ON DELETE SET NULL,
  department_id   UUID REFERENCES departments(id) ON DELETE SET NULL,
  start_date      DATE,
  end_date        DATE,
  project_status  VARCHAR(20) NOT NULL DEFAULT 'DRAFT'
                    CHECK (project_status IN ('DRAFT','ACTIVE','ON_HOLD','CLOSED','CANCELLED')),
  is_active       SMALLINT NOT NULL DEFAULT 1,
  is_deleted      SMALLINT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by      UUID REFERENCES employees(id) ON DELETE SET NULL,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by      UUID REFERENCES employees(id) ON DELETE SET NULL,
  UNIQUE (tenant_id, project_code)
);

CREATE INDEX idx_projects_tenant_dept    ON projects (tenant_id, department_id);
CREATE INDEX idx_projects_tenant_status  ON projects (tenant_id, project_status);

-- ── 3. ProjectTasks ────────────────────────────────────────────
CREATE TABLE project_tasks (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id              UUID NOT NULL DEFAULT gen_random_uuid(),
  tenant_id            UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  project_id           UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  task_name            VARCHAR(200) NOT NULL,
  description          VARCHAR(2000),
  assigned_employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  start_date           DATE,
  end_date             DATE,
  task_status          VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                         CHECK (task_status IN ('PENDING','IN_PROGRESS','COMPLETED','CANCELLED')),
  is_active            SMALLINT NOT NULL DEFAULT 1,
  is_deleted           SMALLINT NOT NULL DEFAULT 0,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by           UUID REFERENCES employees(id) ON DELETE SET NULL,
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by           UUID REFERENCES employees(id) ON DELETE SET NULL
);

CREATE INDEX idx_project_tasks_tenant_project ON project_tasks (tenant_id, project_id);
CREATE INDEX idx_project_tasks_assigned       ON project_tasks (assigned_employee_id);

-- ── 4. Timesheet Entries v2 (project/task linked) ─────────────
-- Enhance existing timesheet_entries with project/task FK columns
ALTER TABLE timesheet_entries
  ADD COLUMN IF NOT EXISTS project_id  UUID REFERENCES projects(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS task_id     UUID REFERENCES project_tasks(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS hours_logged NUMERIC(4,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_billable  SMALLINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS remark      VARCHAR(1000);

-- ── 5. AuditLogs ──────────────────────────────────────────────
CREATE TABLE audit_logs (
  audit_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         UUID NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001',
  module            VARCHAR(50) NOT NULL
                      CHECK (module IN ('ORG_STRUCTURE','EMPLOYEE','PAYROLL','LEAVE','ATTENDANCE',
                        'RECRUITMENT','ONBOARDING','OFFBOARDING','TRAINING','PERFORMANCE',
                        'COMPENSATION','BENEFITS','LOAN','TRANSFER','COMPLIANCE','DOCUMENT',
                        'TIMESHEET','USER_AUTH','REPORTING','INTEGRATION')),
  entity_type       VARCHAR(50) NOT NULL,
  entity_id         UUID,
  employee_id       UUID REFERENCES employees(id) ON DELETE SET NULL,
  action_type       VARCHAR(20) NOT NULL
                      CHECK (action_type IN ('CREATE','READ','UPDATE','DELETE','EXPORT',
                        'MERGE','ASSIGN','IMPORT','ARCHIVE','RESTORE')),
  old_value         JSONB,
  new_value         JSONB,
  performed_by      UUID REFERENCES employees(id) ON DELETE SET NULL,
  event_timestamp   TIMESTAMPTZ NOT NULL DEFAULT now(),
  device_fingerprint VARCHAR(50),
  session_id        VARCHAR(255),
  reason            VARCHAR(1000),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by        UUID REFERENCES employees(id) ON DELETE SET NULL,
  is_active         SMALLINT NOT NULL DEFAULT 1
);

CREATE INDEX idx_audit_logs_tenant_module    ON audit_logs (tenant_id, module, entity_type);
CREATE INDEX idx_audit_logs_tenant_emp_ts    ON audit_logs (tenant_id, employee_id, event_timestamp DESC);
CREATE INDEX idx_audit_logs_tenant_ts        ON audit_logs (tenant_id, event_timestamp DESC);
CREATE INDEX idx_audit_logs_tenant_by        ON audit_logs (tenant_id, performed_by);
CREATE INDEX idx_audit_logs_module           ON audit_logs (tenant_id, module);
CREATE INDEX idx_audit_logs_action_ts        ON audit_logs (tenant_id, action_type, event_timestamp DESC);

-- ── 6. RLS Policies ───────────────────────────────────────────
ALTER TABLE announcements    ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects         ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_tasks    ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs       ENABLE ROW LEVEL SECURITY;

CREATE POLICY "announcements_all_access" ON announcements    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "projects_all_access"      ON projects         FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "project_tasks_all_access" ON project_tasks    FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "audit_logs_all_access"    ON audit_logs       FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- ── 7. Seed sample announcements ──────────────────────────────
INSERT INTO announcements (title, description, type, targets, priority, announcement_status, published_at, created_at, updated_at)
VALUES
  ('Welcome to BKG HRMS v2.0', 'We are excited to announce the launch of our upgraded HR Management System. Please explore the new Governance, Timesheet, and Audit modules.', 'INFORMATIVE', 'ALL', 'HIGH', 'PUBLISHED', now(), now(), now()),
  ('Q2 Performance Reviews Due', 'All managers are required to complete Q2 performance reviews by June 30. Please log in to the Performance module to submit your reviews.', 'INFORMATIVE', 'ALL', 'NORMAL', 'PUBLISHED', now(), now(), now()),
  ('Office Closure – National Holiday', 'The office will be closed on June 12 for the national holiday. Please plan your leave accordingly.', 'INFORMATIVE', 'ALL', 'NORMAL', 'PUBLISHED', now(), now(), now()),
  ('IT Security Policy Update', 'Our IT Security Policy has been updated. All employees are required to read and acknowledge the updated policy in the Compliance section.', 'INFORMATIVE', 'ALL', 'URGENT', 'DRAFT', now(), now(), now());

-- ── 8. Seed sample projects ────────────────────────────────────
INSERT INTO projects (project_name, project_code, description, project_status, start_date, end_date, created_at, updated_at)
VALUES
  ('HRMS Digital Transformation', 'PROJ-HRMS-001', 'Full digital transformation of HR processes including payroll automation, ESS portal, and compliance tracking.', 'ACTIVE', '2026-01-01', '2026-12-31', now(), now()),
  ('Employee Wellness Initiative', 'PROJ-EWI-002', 'Company-wide wellness program including mental health support, fitness subsidies, and flexible work arrangements.', 'ACTIVE', '2026-03-01', '2026-09-30', now(), now()),
  ('Recruitment Automation Phase 2', 'PROJ-REC-003', 'Automating recruitment workflows including AI-assisted resume screening and interview scheduling.', 'DRAFT', '2026-07-01', '2026-12-31', now(), now());
