-- audit_logs.performed_by references auth.users (UUID) not employees
-- Add FK so PostgREST can join to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_schema='public' AND table_name='audit_logs'
    AND constraint_name='audit_logs_performed_by_fkey'
  ) THEN
    ALTER TABLE audit_logs
      ADD CONSTRAINT audit_logs_performed_by_fkey
      FOREIGN KEY (performed_by) REFERENCES auth.users(id) ON DELETE SET NULL;
  END IF;
END $$;