
CREATE TABLE salary_bands (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  band_code     text NOT NULL UNIQUE,
  band_name     text NOT NULL,
  job_grade     text,
  job_level     text,
  currency      text NOT NULL DEFAULT 'ETB',
  min_salary    numeric(15,2) NOT NULL,
  mid_salary    numeric(15,2),
  max_salary    numeric(15,2) NOT NULL,
  effective_date date,
  description   text,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE merit_cycles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_name   text NOT NULL,
  fiscal_year  int  NOT NULL,
  start_date   date NOT NULL,
  end_date     date NOT NULL,
  budget_pct   numeric(6,2),
  status       text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','ACTIVE','CLOSED')),
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE bonus_cycles (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_name    text NOT NULL,
  bonus_type    text NOT NULL DEFAULT 'ANNUAL' CHECK (bonus_type IN ('ANNUAL','QUARTERLY','SPOT','PROJECT')),
  fiscal_year   int  NOT NULL,
  payout_date   date,
  budget_amount numeric(15,2),
  currency      text NOT NULL DEFAULT 'ETB',
  status        text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','ACTIVE','PAID','CANCELLED')),
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE variable_pay_plans (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_name      text NOT NULL,
  plan_type      text NOT NULL DEFAULT 'COMMISSION' CHECK (plan_type IN ('COMMISSION','KPI','PROFIT_SHARE','INCENTIVE')),
  target_pct     numeric(6,2),
  max_pct        numeric(6,2),
  currency       text NOT NULL DEFAULT 'ETB',
  effective_date date,
  is_active      boolean NOT NULL DEFAULT true,
  description    text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE compensation_budget_pools (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pool_name     text NOT NULL,
  fiscal_year   int  NOT NULL,
  pool_type     text NOT NULL DEFAULT 'MERIT' CHECK (pool_type IN ('MERIT','BONUS','VARIABLE','EQUITY')),
  department_id uuid REFERENCES departments(id) ON DELETE SET NULL,
  total_amount  numeric(15,2) NOT NULL,
  allocated     numeric(15,2) NOT NULL DEFAULT 0,
  currency      text NOT NULL DEFAULT 'ETB',
  status        text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','LOCKED','CLOSED')),
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE employee_salaries (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id    uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  salary_band_id uuid REFERENCES salary_bands(id) ON DELETE SET NULL,
  base_salary    numeric(15,2) NOT NULL,
  currency       text NOT NULL DEFAULT 'ETB',
  effective_date date NOT NULL,
  end_date       date,
  salary_type    text NOT NULL DEFAULT 'MONTHLY' CHECK (salary_type IN ('MONTHLY','ANNUAL','HOURLY')),
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE pay_equity_snapshots (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_date date NOT NULL DEFAULT CURRENT_DATE,
  department    text,
  job_grade     text,
  gender        text,
  avg_salary    numeric(15,2),
  median_salary numeric(15,2),
  headcount     int,
  pay_gap_pct   numeric(6,2),
  currency      text NOT NULL DEFAULT 'ETB',
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE inter_company_transfers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id   uuid NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  from_entity   text NOT NULL,
  to_entity     text NOT NULL,
  transfer_date date NOT NULL,
  reason        text,
  status        text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','COMPLETED','CANCELLED')),
  notes         text,
  approved_by   uuid REFERENCES employees(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE policy_register (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  policy_code    text NOT NULL UNIQUE,
  title          text NOT NULL,
  category       text NOT NULL DEFAULT 'HR',
  owner          text,
  effective_date date,
  review_date    date,
  status         text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('DRAFT','ACTIVE','UNDER_REVIEW','RETIRED')),
  document_url   text,
  description    text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE warning_templates (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_code  text NOT NULL UNIQUE,
  title          text NOT NULL,
  offense_type   text NOT NULL DEFAULT 'GENERAL',
  severity       text NOT NULL DEFAULT 'MINOR' CHECK (severity IN ('MINOR','MODERATE','MAJOR','GROSS')),
  body_template  text NOT NULL,
  is_active      boolean NOT NULL DEFAULT true,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE salary_bands              ENABLE ROW LEVEL SECURITY;
ALTER TABLE merit_cycles              ENABLE ROW LEVEL SECURITY;
ALTER TABLE bonus_cycles              ENABLE ROW LEVEL SECURITY;
ALTER TABLE variable_pay_plans        ENABLE ROW LEVEL SECURITY;
ALTER TABLE compensation_budget_pools ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_salaries         ENABLE ROW LEVEL SECURITY;
ALTER TABLE pay_equity_snapshots      ENABLE ROW LEVEL SECURITY;
ALTER TABLE inter_company_transfers   ENABLE ROW LEVEL SECURITY;
ALTER TABLE policy_register           ENABLE ROW LEVEL SECURITY;
ALTER TABLE warning_templates         ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth_all_salary_bands"              ON salary_bands              FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_merit_cycles"              ON merit_cycles              FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_bonus_cycles"              ON bonus_cycles              FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_variable_pay_plans"        ON variable_pay_plans        FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_compensation_budget_pools" ON compensation_budget_pools FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_employee_salaries"         ON employee_salaries         FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_pay_equity_snapshots"      ON pay_equity_snapshots      FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_inter_company_transfers"   ON inter_company_transfers   FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_policy_register"           ON policy_register           FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_warning_templates"         ON warning_templates         FOR ALL TO authenticated USING (true) WITH CHECK (true);
