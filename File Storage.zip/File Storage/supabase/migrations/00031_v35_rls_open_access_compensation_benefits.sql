-- All compensation/benefit tables have RLS enabled but zero policies → blocked
-- Add open authenticated-access policies for all affected tables

CREATE POLICY "allowance_types_all_access" ON allowance_types
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "compensation_structures_all_access" ON compensation_structures
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "compensation_components_all_access" ON compensation_components
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "employee_compensations_all_access" ON employee_compensations
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "benefit_plans_all_access" ON benefit_plans
  FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY "benefit_enrollments_all_access" ON benefit_enrollments
  FOR ALL USING (true) WITH CHECK (true);

-- Also check announcements/projects/audit_logs – verify policies exist
-- (they already exist from prior migrations, this is a safety net)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename='announcements' AND policyname='announcements_all_access'
  ) THEN
    EXECUTE 'CREATE POLICY "announcements_all_access" ON announcements FOR ALL USING (true) WITH CHECK (true)';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename='projects' AND policyname='projects_all_access'
  ) THEN
    EXECUTE 'CREATE POLICY "projects_all_access" ON projects FOR ALL USING (true) WITH CHECK (true)';
  END IF;
END $$;