import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';

import { errorHandler, notFound, requestLogger } from './middleware';

import fileRequestsRouter from './modules/file-requests/routes';
import uploadSessionsRouter from './modules/upload-sessions/routes';
import fileMetadataRouter from './modules/file-metadata/routes';
import fileVersionsRouter from './modules/file-versions/routes';
import filePermissionsRouter from './modules/file-permissions/routes';
import fileAuditLogsRouter from './modules/file-audit-logs/routes';
import fileBackupsRouter from './modules/file-backups/routes';
import fileRestoreJobsRouter from './modules/file-restore-jobs/routes';
import storageQuotasRouter from './modules/storage-quotas/routes';
import fileCalendarEventsRouter from './modules/file-calendar-events/routes';
import fileDiscussionsRouter from './modules/file-discussions/routes';
import foldersRouter from './modules/folders/routes';
import fileNotificationsRouter from './modules/file-notifications/routes';
import userPreferencesRouter from './modules/user-preferences/routes';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined'));
app.use(requestLogger);

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API Routes v1
const API_PREFIX = '/api/v1';

// API root — discovery / sanity-check endpoint
app.get(API_PREFIX, (_req, res) => {
  res.json({
    success: true,
    version: 'v1',
    base: `http://localhost:${PORT}${API_PREFIX}`,
    endpoints: [
      `${API_PREFIX}/files`,
      `${API_PREFIX}/files/requests`,
      `${API_PREFIX}/files/:documentId/versions`,
      `${API_PREFIX}/files/:documentId/discussions`,
      `${API_PREFIX}/upload-sessions`,
      `${API_PREFIX}/permissions`,
      `${API_PREFIX}/audit-logs`,
      `${API_PREFIX}/backups`,
      `${API_PREFIX}/restore-jobs`,
      `${API_PREFIX}/quotas`,
      `${API_PREFIX}/calendar-events`,
      `${API_PREFIX}/folders`,
      `${API_PREFIX}/notifications`,
      `${API_PREFIX}/preferences`,
    ],
  });
});

app.use(`${API_PREFIX}/files/requests`, fileRequestsRouter);
app.use(`${API_PREFIX}/upload-sessions`, uploadSessionsRouter);
app.use(`${API_PREFIX}/files`, fileMetadataRouter);
app.use(`${API_PREFIX}/files/:documentId/versions`, fileVersionsRouter);
app.use(`${API_PREFIX}/files/:documentId/discussions`, fileDiscussionsRouter);
app.use(`${API_PREFIX}/permissions`, filePermissionsRouter);
app.use(`${API_PREFIX}/audit-logs`, fileAuditLogsRouter);
app.use(`${API_PREFIX}/backups`, fileBackupsRouter);
app.use(`${API_PREFIX}/restore-jobs`, fileRestoreJobsRouter);
app.use(`${API_PREFIX}/quotas`, storageQuotasRouter);
app.use(`${API_PREFIX}/calendar-events`, fileCalendarEventsRouter);
app.use(`${API_PREFIX}/folders`, foldersRouter);
app.use(`${API_PREFIX}/notifications`, fileNotificationsRouter);
app.use(`${API_PREFIX}/preferences`, userPreferencesRouter);

// Error handling
app.use(notFound);
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`[Server] File Storage API running on http://localhost:${PORT}`);
  console.log(`[Server] API base: http://localhost:${PORT}${API_PREFIX}`);
});

export default app;
