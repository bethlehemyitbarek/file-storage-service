export type FileStatus = 'ACTIVE' | 'ARCHIVED' | 'DELETED' | 'PENDING';
export type StorageTier = 'HOT' | 'WARM' | 'COLD';
export type EncryptionStatus = 'ENCRYPTED' | 'UNENCRYPTED' | 'ENCRYPTION_FAILED';
export type FileRequestStatus = 'RECEIVED' | 'VALIDATED' | 'FAILED' | 'EXPIRED';
export type UploadSessionStatus = 'IN_PROGRESS' | 'COMPLETED' | 'FAILED' | 'EXPIRED';
export type PermissionRole = 'OWNER' | 'EDITOR' | 'VIEWER' | 'COMMENTOR' | 'NONE';
export type AccessLevel = 'READ' | 'WRITE' | 'COMMENT' | 'DOWNLOAD' | 'MANAGE';
export type PermissionStatus = 'ACTIVE' | 'REVOKED' | 'EXPIRED' | 'PENDING_APPROVAL';
export type GranteeType = 'USER' | 'ROLE' | 'GROUP' | 'EXTERNAL';
export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'READ' | 'SHARE' | 'VALIDATE' | 'UPLOAD' | 'DOWNLOAD' | 'ARCHIVE' | 'RESTORE' | 'GRANT' | 'REVOKE' | 'EXPORT' | 'PRINT';
export type ActorType = 'USER' | 'SYSTEM' | 'API_CLIENT';
export type BackupType = 'FULL' | 'INCREMENTAL' | 'DIFFERENTIAL';
export type BackupScope = 'TENANT' | 'FILE' | 'FOLDER';
export type BackupStatus = 'SUCCESS' | 'FAILED' | 'IN_PROGRESS' | 'PARTIAL';
export type RestoreScope = 'SINGLE_FILE' | 'FOLDER' | 'TENANT' | 'BULK';
export type RestoreStatus = 'IN_PROGRESS' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'PENDING_APPROVAL';
export type ApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';
export type QuotaType = 'USER' | 'TENANT' | 'DEPARTMENT';
export type QuotaStatus = 'ACTIVE' | 'EXCEEDED_SOFT' | 'EXCEEDED_HARD' | 'SUSPENDED';
export type ImportanceLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
export type EventStatus = 'SCHEDULED' | 'COMPLETED' | 'CANCELLED' | 'EXPIRED';
export type DiscussionStatus = 'ACTIVE' | 'ARCHIVED' | 'HIDDEN_BY_ADMIN' | 'DELETED_BY_USER';
export type NotificationType = 'FILE_SHARED' | 'FILE_UPLOADED' | 'FILE_UPDATED' | 'FILE_DELETED' | 'COMMENT_ADDED' | 'MENTIONED' | 'SHARE_EXPIRING' | 'QUOTA_WARNING' | 'RESTORE_COMPLETED';
export type DeliveryMethod = 'IN_APP' | 'EMAIL' | 'SMS' | 'PUSH';
export type PreferredView = 'LIST' | 'GRID' | 'DETAILED';
export type TagCategory = 'USER_DEFINED' | 'SYSTEM_GENERATED' | 'CONFIDENTIAL' | 'COMPLIANCE';

export interface PaginationParams {
  page?: number;
  limit?: number;
  cursor?: string;
}

export interface ApiResponse<T> {
  data: T;
  error?: string;
  meta?: {
    total?: number;
    page?: number;
    limit?: number;
    nextCursor?: string;
  };
}

export interface FileTag {
  name: string;
  category: TagCategory;
}

export interface FileRequest {
  row_id: string;
  request_id: string;
  tenant_id: string;
  user_id: string;
  file_name: string;
  file_url?: string;
  mime_type: string;
  size_kb: number;
  status: FileRequestStatus;
  ip_address?: string;
  source: 'HTTP' | 'KAFKA';
  failure_reason?: string;
  is_current: number;
  created_at: string;
  updated_at: string;
}

export interface UploadSession {
  row_id: string;
  session_id: string;
  tenant_id: string;
  user_id: string;
  file_count: number;
  total_size_kb: number;
  status: UploadSessionStatus;
  started_at: string;
  completed_at?: string;
  expiry_at: string;
  failure_reason?: string;
  resume_token?: string;
  bytes_uploaded: number;
  created_at: string;
  updated_at: string;
}

export interface FileMetadata {
  row_id: string;
  document_id: string;
  tenant_id: string;
  user_id: string;
  file_name: string;
  mime_type: string;
  size_kb: number;
  version: number;
  status: FileStatus;
  description?: string;
  tags?: FileTag[];
  extracted_text?: string;
  checksum: string;
  storage_path: string;
  storage_tier: StorageTier;
  encryption_status: EncryptionStatus;
  encryption_key_ref?: string;
  iv?: string;
  last_accessed_at?: string;
  effective_from: string;
  effective_to: string;
  is_current: number;
  created_at: string;
  updated_at: string;
}

export interface FileVersion {
  row_id: string;
  version_id: string;
  document_id: string;
  tenant_id: string;
  version_number: number;
  storage_path: string;
  checksum: string;
  size_kb: number;
  change_summary?: string;
  encryption_status: 'ENCRYPTED' | 'UNENCRYPTED';
  storage_tier: StorageTier;
  is_orphaned: number;
  created_by: string;
  created_at: string;
}

export interface FilePermission {
  row_id: string;
  permission_id: string;
  document_id?: string;
  folder_id?: string;
  tenant_id: string;
  grantee_type: GranteeType;
  grantee_id: string;
  grantee_email?: string;
  external_tenant_id?: string;
  role: PermissionRole;
  access_level: AccessLevel;
  share_link_token?: string;
  share_link_enabled: number;
  share_message?: string;
  apply_recursively: number;
  granted_by: string;
  granted_at: string;
  expires_at?: string;
  status: PermissionStatus;
  revoked_at?: string;
  revocation_reason?: string;
  last_accessed_at?: string;
  access_count: number;
  created_at: string;
}

export interface FileAuditLog {
  row_id: string;
  audit_id: string;
  document_id?: string;
  tenant_id: string;
  actor_id: string;
  actor_type: ActorType;
  action: AuditAction;
  action_timestamp: string;
  old_value?: Record<string, unknown>;
  new_value?: Record<string, unknown>;
  reason?: string;
  viewer_role: string;
  ip_address?: string;
  user_agent?: string;
  correlation_id?: string;
  session_id?: string;
  audit_signature?: string;
  previous_audit_hash?: string;
  created_at: string;
}

export interface FileBackup {
  row_id: string;
  backup_id: string;
  document_id?: string;
  tenant_id: string;
  backup_path: string;
  backup_type: BackupType;
  backup_scope: BackupScope;
  checksum: string;
  size_bytes: number;
  file_count: number;
  encryption_status: 'ENCRYPTED' | 'UNENCRYPTED';
  retention_days: number;
  status: BackupStatus;
  failure_reason?: string;
  created_by: string;
  created_at: string;
  completed_at?: string;
  verified_at?: string;
}

export interface FileRestoreJob {
  row_id: string;
  restore_id: string;
  document_id?: string;
  folder_id?: string;
  tenant_id: string;
  backup_id: string;
  restore_scope: RestoreScope;
  restore_path: string;
  restore_target_version?: number;
  restore_target_time?: string;
  requested_by: string;
  restored_file_count: number;
  failed_file_count: number;
  status: RestoreStatus;
  failure_reason?: string;
  approval_status: ApprovalStatus;
  approved_by?: string;
  requested_at: string;
  completed_at?: string;
  approved_at?: string;
  created_at: string;
}

export interface UserStoragePreferences {
  row_id: string;
  preference_id: string;
  tenant_id: string;
  user_id: string;
  preferred_view: PreferredView;
  default_sort_field: string;
  default_sort_order: 'ASC' | 'DESC';
  items_per_page: number;
  notification_settings: Record<string, unknown>;
  quiet_hours?: Record<string, unknown>;
  thumbnail_preview_enabled: number;
  auto_save_interval_seconds: number;
  default_upload_folder_id?: string;
  theme: 'LIGHT' | 'DARK' | 'SYSTEM';
  language: string;
  created_at: string;
  updated_at: string;
}

export interface StorageQuota {
  row_id: string;
  quota_id: string;
  tenant_id: string;
  user_id?: string;
  quota_type: QuotaType;
  allocated_space_mb: number;
  used_space_mb: number;
  soft_limit_mb: number;
  hard_limit_mb: number;
  status: QuotaStatus;
  last_checked_at?: string;
  created_at: string;
}

export interface FileCalendarEvent {
  row_id: string;
  event_id: string;
  tenant_id: string;
  user_id: string;
  document_id?: string;
  event_title: string;
  event_description?: string;
  event_date: string;
  event_end_date?: string;
  all_day: number;
  importance_level: ImportanceLevel;
  reminder_minutes_before?: number[];
  recurrence_rule?: string;
  color_code?: string;
  status: EventStatus;
  external_calendar_id?: string;
  created_at: string;
  updated_at: string;
}

export interface FileDiscussion {
  row_id: string;
  discussion_id: string;
  tenant_id: string;
  document_id: string;
  user_id: string;
  message_text: string;
  parent_message_id?: string;
  thread_depth: number;
  mentions?: string[];
  attachments?: string[];
  is_edited: number;
  edited_at?: string;
  status: DiscussionStatus;
  created_at: string;
  updated_at: string;
}

export interface FileNotification {
  row_id: string;
  notification_id: string;
  tenant_id: string;
  user_id: string;
  document_id?: string;
  notification_type: NotificationType;
  message: string;
  is_read: number;
  read_at?: string;
  action_url?: string;
  delivery_method: DeliveryMethod;
  created_at: string;
}

export interface Folder {
  row_id: string;
  folder_id: string;
  tenant_id: string;
  parent_folder_id?: string;
  owner_user_id: string;
  folder_name: string;
  folder_path?: string;
  description?: string;
  color_code?: string;
  is_public: number;
  created_at: string;
  updated_at: string;
}

export interface FolderFileMapping {
  row_id: string;
  mapping_id: string;
  folder_id: string;
  document_id: string;
  tenant_id: string;
  added_by: string;
  created_at: string;
}
