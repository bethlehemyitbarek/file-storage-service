import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getUploadSessions);
router.post('/', controller.createUploadSession);
router.get('/:id', controller.getUploadSessionById);
router.patch('/:id', controller.updateUploadSession);
router.post('/:id/resume', controller.resumeUploadSession);
export default router;
