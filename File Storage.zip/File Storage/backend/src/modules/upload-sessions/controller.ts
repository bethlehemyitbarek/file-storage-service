import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

export const createUploadSession = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const user_id = (req.headers['x-user-id'] as string) || 'anonymous';
    const result = await service.createUploadSession({ ...req.body, tenant_id, user_id });
    res.status(201).json({ data: result });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
};

export const getUploadSessions = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const user_id = (req.headers['x-user-id'] as string) || '';
    const result = await service.getUploadSessions(tenant_id, user_id, req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const getUploadSessionById = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getUploadSessionById(req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const updateUploadSession = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateUploadSession(req.params.id, req.body);
    res.json({ data: result });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
};

export const resumeUploadSession = async (req: Request, res: Response): Promise<void> => {
  try {
    const { bytes_uploaded } = req.body;
    const result = await service.resumeUploadSession(req.params.id, bytes_uploaded);
    res.json({ data: result });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
};
