import { supabase } from '@/config/supabase';import { generateUUID, getPaginationParams } from '@/utils';

export const createUploadSession = async (data: {
  user_id: string;
  file_count: number;
  total_size_kb: number;
  tenant_id?: string;
}) => {
  if (data.file_count > 5) throw new Error('EXCEEDS_MAX_FILES_PER_SESSION');
  const tenant_id = data.tenant_id || 'default';
  const session_id = generateUUID();
  const resume_token = generateUUID();
  const expiry_at = new Date(Date.now() + 60 * 60 * 1000).toISOString();

  const { data: inserted, error } = await supabase
    .from('storage.upload_sessions')
    .insert({
      session_id, tenant_id, user_id: data.user_id,
      file_count: data.file_count, total_size_kb: data.total_size_kb,
      status: 'IN_PROGRESS', started_at: new Date().toISOString(),
      expiry_at, resume_token, bytes_uploaded: 0, created_by: data.user_id,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getUploadSessions = async (tenant_id: string, user_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('storage.upload_sessions')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_current', 1)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getUploadSessionById = async (session_id: string) => {
  const { data, error } = await supabase
    .from('storage.upload_sessions')
    .select('*')
    .eq('session_id', session_id)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};

export const updateUploadSession = async (session_id: string, updates: Record<string, unknown>) => {
  const { data, error } = await supabase
    .from('storage.upload_sessions')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('session_id', session_id)
    .eq('is_current', 1)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const resumeUploadSession = async (session_id: string, bytes_uploaded: number) => {
  const session = await getUploadSessionById(session_id);
  if (!session) throw new Error('Session not found');
  if (session.status === 'EXPIRED') throw new Error('SESSION_EXPIRED');
  return updateUploadSession(session_id, { bytes_uploaded });
};
