import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';
import { QuotaType } from '@/types';

export const getOrCreateQuota = async (tenant_id: string, user_id?: string, quota_type: QuotaType = 'USER') => {
  const q = supabase
    .from('storage_quotas')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('quota_type', quota_type)
    .eq('is_current', 1);

  if (user_id) q.eq('user_id', user_id);

  const { data: existing } = await q.maybeSingle();
  if (existing) return existing;

  const defaults = {
    USER: { allocated_space_mb: 10240, soft_limit_mb: 9216, hard_limit_mb: 10240 },
    TENANT: { allocated_space_mb: 102400, soft_limit_mb: 92160, hard_limit_mb: 102400 },
    DEPARTMENT: { allocated_space_mb: 51200, soft_limit_mb: 46080, hard_limit_mb: 51200 },
  };

  const { data: inserted, error } = await supabase
    .from('storage_quotas')
    .insert({
      quota_id: generateUUID(),
      tenant_id,
      user_id: user_id || null,
      quota_type,
      ...defaults[quota_type],
      used_space_mb: 0,
      status: 'ACTIVE',
      last_checked_at: new Date().toISOString(),
      created_by: 'system',
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getQuotas = async (tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('storage_quotas')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getUserQuota = async (tenant_id: string, user_id: string) => {
  return getOrCreateQuota(tenant_id, user_id, 'USER');
};

export const updateUsedSpace = async (tenant_id: string, user_id: string, size_kb: number) => {
  const quota = await getUserQuota(tenant_id, user_id);
  const size_mb = size_kb / 1024;
  const new_used = quota.used_space_mb + size_mb;

  let status = 'ACTIVE';
  if (new_used >= quota.hard_limit_mb) status = 'EXCEEDED_HARD';
  else if (new_used >= quota.soft_limit_mb) status = 'EXCEEDED_SOFT';

  const { data, error } = await supabase
    .from('storage_quotas')
    .update({
      used_space_mb: new_used,
      status,
      last_checked_at: new Date().toISOString(),
    })
    .eq('quota_id', quota.quota_id)
    .select().single();

  if (error) throw new Error(error.message);
  if (status === 'EXCEEDED_HARD') throw new Error('QUOTA_EXCEEDED');
  return data;
};

export const updateQuota = async (
  tenant_id: string,
  quota_id: string,
  updates: { allocated_space_mb?: number; soft_limit_mb?: number; hard_limit_mb?: number },
  updated_by: string
) => {
  const { data, error } = await supabase
    .from('storage_quotas')
    .update({ ...updates, updated_at: new Date().toISOString(), updated_by })
    .eq('tenant_id', tenant_id)
    .eq('quota_id', quota_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};
