import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getQuotas);
router.get('/me', controller.getUserQuota);
router.put('/:id', controller.updateQuota);
export default router;
