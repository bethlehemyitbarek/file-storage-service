import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const getQuotas = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getQuotas(getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getUserQuota = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getUserQuota(getTenant(req), getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateQuota = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateQuota(getTenant(req), req.params.id, req.body, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
