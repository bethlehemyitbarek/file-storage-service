import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';
import { NotificationType, DeliveryMethod } from '@/types';

export const createNotification = async (data: {
  user_id: string;
  tenant_id?: string;
  document_id?: string;
  notification_type: NotificationType;
  message: string;
  action_url?: string;
  delivery_method?: DeliveryMethod;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const { data: inserted, error } = await supabase
    .from('file_notifications')
    .insert({
      notification_id: generateUUID(),
      tenant_id,
      user_id: data.user_id,
      document_id: data.document_id || null,
      notification_type: data.notification_type,
      message: data.message,
      is_read: 0,
      action_url: data.action_url || null,
      delivery_method: data.delivery_method || 'IN_APP',
      created_by: data.user_id,
    })
    .select().single();
  if (error) throw new Error(error.message);
  return inserted;
};

export const getNotifications = async (
  tenant_id: string,
  user_id: string,
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { type, is_read } = query;

  let q = supabase
    .from('file_notifications')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (type) q = q.eq('notification_type', type);
  if (is_read !== undefined) q = q.eq('is_read', is_read === 'true' ? 1 : 0);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const markAsRead = async (tenant_id: string, notification_id: string) => {
  const { data, error } = await supabase
    .from('file_notifications')
    .update({ is_read: 1, read_at: new Date().toISOString() })
    .eq('tenant_id', tenant_id)
    .eq('notification_id', notification_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const markAllAsRead = async (tenant_id: string, user_id: string) => {
  const { error } = await supabase
    .from('file_notifications')
    .update({ is_read: 1, read_at: new Date().toISOString() })
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_read', 0);
  if (error) throw new Error(error.message);
};

export const getUnreadCount = async (tenant_id: string, user_id: string) => {
  const { count, error } = await supabase
    .from('file_notifications')
    .select('*', { count: 'exact', head: true })
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_read', 0)
    .eq('is_current', 1);
  if (error) throw new Error(error.message);
  return count || 0;
};
