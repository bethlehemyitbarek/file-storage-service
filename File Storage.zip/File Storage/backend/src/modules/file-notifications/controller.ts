import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const getNotifications = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getNotifications(getTenant(req), getUser(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const createNotification = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createNotification({ ...req.body, tenant_id: getTenant(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const markAsRead = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.markAsRead(getTenant(req), req.params.id);
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const markAllAsRead = async (req: Request, res: Response): Promise<void> => {
  try {
    await service.markAllAsRead(getTenant(req), getUser(req));
    res.json({ data: { success: true } });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getUnreadCount = async (req: Request, res: Response): Promise<void> => {
  try {
    const count = await service.getUnreadCount(getTenant(req), getUser(req));
    res.json({ data: { count } });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
