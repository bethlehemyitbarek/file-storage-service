import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getNotifications);
router.post('/', controller.createNotification);
router.get('/unread-count', controller.getUnreadCount);
router.post('/mark-all-read', controller.markAllAsRead);
router.patch('/:id/read', controller.markAsRead);
export default router;
