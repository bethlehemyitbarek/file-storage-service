import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { FileRequest, PaginationParams } from '@/types';
import { generateUUID, getPaginationParams } from '@/utils';

export const createFileRequest = async (data: {
  user_id: string;
  file_name: string;
  file_url?: string;
  mime_type: string;
  size_kb: number;
  ip_address?: string;
  source?: 'HTTP' | 'KAFKA';
  tenant_id?: string;
}): Promise<FileRequest> => {
  const request_id = generateUUID();
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;

  // Idempotency check
  const { data: existing } = await supabase
    .from('file_requests')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('request_id', request_id)
    .eq('is_current', 1)
    .maybeSingle();

  if (existing) return existing as FileRequest;

  const { data: inserted, error } = await supabase
    .from('file_requests')
    .insert({
      request_id,
      tenant_id,
      user_id: data.user_id,
      file_name: data.file_name,
      file_url: data.file_url || null,
      mime_type: data.mime_type,
      size_kb: data.size_kb,
      status: 'RECEIVED',
      ip_address: data.ip_address || null,
      source: data.source || 'HTTP',
      created_by: data.user_id,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);
  return inserted as FileRequest;
};

export const getFileRequests = async (
  tenant_id: string,
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);
  const status = query.status;

  let q = supabase
    .from('file_requests')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (status) q = q.eq('status', status);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);

  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getFileRequestById = async (tenant_id: string, request_id: string) => {
  const { data, error } = await supabase
    .from('file_requests')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('request_id', request_id)
    .eq('is_current', 1)
    .maybeSingle();

  if (error) throw new Error(error.message);
  return data;
};

export const updateFileRequestStatus = async (
  tenant_id: string,
  request_id: string,
  status: string,
  failure_reason?: string
) => {
  const { data, error } = await supabase
    .from('file_requests')
    .update({ status, failure_reason: failure_reason || null, updated_at: new Date().toISOString() })
    .eq('tenant_id', tenant_id)
    .eq('request_id', request_id)
    .eq('is_current', 1)
    .select()
    .single();

  if (error) throw new Error(error.message);
  return data;
};
