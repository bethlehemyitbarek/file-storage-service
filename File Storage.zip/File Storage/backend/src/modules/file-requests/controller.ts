import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

export const createFileRequest = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const user_id = (req.headers['x-user-id'] as string) || 'anonymous';
    const result = await service.createFileRequest({ ...req.body, tenant_id, user_id, ip_address: req.ip });
    res.status(201).json({ data: result });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
};

export const getFileRequests = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const result = await service.getFileRequests(tenant_id, req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const getFileRequestById = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const result = await service.getFileRequestById(tenant_id, req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) {
    res.status(500).json({ error: (err as Error).message });
  }
};

export const updateFileRequestStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const tenant_id = (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
    const { status, failure_reason } = req.body;
    const result = await service.updateFileRequestStatus(tenant_id, req.params.id, status, failure_reason);
    res.json({ data: result });
  } catch (err: unknown) {
    res.status(400).json({ error: (err as Error).message });
  }
};
