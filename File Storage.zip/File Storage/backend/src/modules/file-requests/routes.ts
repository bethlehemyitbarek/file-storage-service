import { Router } from 'express';
import * as controller from './controller';

const router = Router();

router.get('/', controller.getFileRequests);
router.post('/', controller.createFileRequest);
router.get('/:id', controller.getFileRequestById);
router.patch('/:id/status', controller.updateFileRequestStatus);

export default router;
