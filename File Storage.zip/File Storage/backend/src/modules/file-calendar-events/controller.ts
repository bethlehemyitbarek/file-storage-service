import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createCalendarEvent = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createCalendarEvent({ ...req.body, tenant_id: getTenant(req), user_id: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getCalendarEvents = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getCalendarEvents(getTenant(req), getUser(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateCalendarEvent = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateCalendarEvent(getTenant(req), req.params.id, req.body, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const deleteCalendarEvent = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.deleteCalendarEvent(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
