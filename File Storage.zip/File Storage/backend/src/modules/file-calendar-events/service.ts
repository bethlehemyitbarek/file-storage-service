import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';
import { ImportanceLevel } from '@/types';

export const createCalendarEvent = async (data: {
  user_id: string;
  tenant_id?: string;
  document_id?: string;
  event_title: string;
  event_description?: string;
  event_date: string;
  event_end_date?: string;
  all_day?: boolean;
  importance_level?: ImportanceLevel;
  reminder_minutes_before?: number[];
  recurrence_rule?: string;
  color_code?: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const { data: inserted, error } = await supabase
    .from('file_calendar_events')
    .insert({
      event_id: generateUUID(),
      tenant_id,
      user_id: data.user_id,
      document_id: data.document_id || null,
      event_title: data.event_title,
      event_description: data.event_description || null,
      event_date: data.event_date,
      event_end_date: data.event_end_date || null,
      all_day: data.all_day ? 1 : 0,
      importance_level: data.importance_level || 'MEDIUM',
      reminder_minutes_before: data.reminder_minutes_before ? JSON.stringify(data.reminder_minutes_before) : null,
      recurrence_rule: data.recurrence_rule || null,
      color_code: data.color_code || null,
      status: 'SCHEDULED',
      created_by: data.user_id,
    })
    .select().single();
  if (error) throw new Error(error.message);
  return inserted;
};

export const getCalendarEvents = async (
  tenant_id: string,
  user_id: string,
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { document_id, status, from_date, to_date } = query;

  let q = supabase
    .from('file_calendar_events')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('event_date', { ascending: true })
    .range(offset, offset + limit - 1);

  if (document_id) q = q.eq('document_id', document_id);
  if (status) q = q.eq('status', status);
  if (from_date) q = q.gte('event_date', from_date);
  if (to_date) q = q.lte('event_date', to_date);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const updateCalendarEvent = async (
  tenant_id: string,
  event_id: string,
  updates: Record<string, unknown>,
  updated_by: string
) => {
  const { data, error } = await supabase
    .from('file_calendar_events')
    .update({ ...updates, updated_at: new Date().toISOString(), updated_by })
    .eq('tenant_id', tenant_id)
    .eq('event_id', event_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const deleteCalendarEvent = async (tenant_id: string, event_id: string, updated_by: string) => {
  const { data, error } = await supabase
    .from('file_calendar_events')
    .update({ is_deleted: 1, status: 'CANCELLED', updated_at: new Date().toISOString(), updated_by })
    .eq('tenant_id', tenant_id)
    .eq('event_id', event_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};
