import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getCalendarEvents);
router.post('/', controller.createCalendarEvent);
router.put('/:id', controller.updateCalendarEvent);
router.delete('/:id', controller.deleteCalendarEvent);
export default router;
