import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';

export const createFolder = async (data: {
  owner_user_id: string;
  folder_name: string;
  parent_folder_id?: string;
  description?: string;
  color_code?: string;
  tenant_id?: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const folder_id = generateUUID();

  // Build materialized path
  let folder_path = `/${data.folder_name}`;
  if (data.parent_folder_id) {
    const { data: parent } = await supabase
      .from('folders')
      .select('folder_path')
      .eq('folder_id', data.parent_folder_id)
      .eq('is_current', 1)
      .maybeSingle();
    if (parent?.folder_path) {
      folder_path = `${parent.folder_path}/${data.folder_name}`;
    }
  }

  const { data: inserted, error } = await supabase
    .from('folders')
    .insert({
      folder_id, tenant_id,
      parent_folder_id: data.parent_folder_id || null,
      owner_user_id: data.owner_user_id,
      folder_name: data.folder_name,
      folder_path,
      description: data.description || null,
      color_code: data.color_code || null,
      is_public: 0,
      created_by: data.owner_user_id,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getFolders = async (tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const parent_folder_id = query.parent_folder_id;

  let q = supabase
    .from('folders')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('folder_name', { ascending: true })
    .range(offset, offset + limit - 1);

  if (parent_folder_id) {
    q = q.eq('parent_folder_id', parent_folder_id);
  } else if (!query.all) {
    q = q.is('parent_folder_id', null);
  }

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getFolderById = async (tenant_id: string, folder_id: string) => {
  const { data, error } = await supabase
    .from('folders')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('folder_id', folder_id)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};

export const updateFolder = async (
  tenant_id: string,
  folder_id: string,
  updates: { folder_name?: string; description?: string; color_code?: string },
  updated_by: string
) => {
  const { data, error } = await supabase
    .from('folders')
    .update({ ...updates, updated_at: new Date().toISOString(), updated_by })
    .eq('tenant_id', tenant_id)
    .eq('folder_id', folder_id)
    .eq('is_current', 1)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const deleteFolder = async (tenant_id: string, folder_id: string, updated_by: string) => {
  const { data, error } = await supabase
    .from('folders')
    .update({ is_deleted: 1, updated_at: new Date().toISOString(), updated_by })
    .eq('tenant_id', tenant_id)
    .eq('folder_id', folder_id)
    .eq('is_current', 1)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const addFileToFolder = async (folder_id: string, document_id: string, tenant_id: string, added_by: string) => {
  const mapping_id = generateUUID();
  const { data, error } = await supabase
    .from('folder_file_mappings')
    .insert({ mapping_id, folder_id, document_id, tenant_id, added_by, created_by: added_by })
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const removeFileFromFolder = async (folder_id: string, document_id: string, tenant_id: string) => {
  const { error } = await supabase
    .from('folder_file_mappings')
    .update({ is_deleted: 1, is_current: 0 })
    .eq('folder_id', folder_id)
    .eq('document_id', document_id)
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1);
  if (error) throw new Error(error.message);
};

export const getFolderFiles = async (folder_id: string, tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('folder_file_mappings')
    .select('*, file_metadata!document_id(*)', { count: 'exact' })
    .eq('folder_id', folder_id)
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};
