import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getFolders);
router.post('/', controller.createFolder);
router.get('/:id', controller.getFolderById);
router.put('/:id', controller.updateFolder);
router.delete('/:id', controller.deleteFolder);
router.get('/:id/files', controller.getFolderFiles);
router.post('/:id/files', controller.addFileToFolder);
router.delete('/:id/files/:documentId', controller.removeFileFromFolder);
export default router;
