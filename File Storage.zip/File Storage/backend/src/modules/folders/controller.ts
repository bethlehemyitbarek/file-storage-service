import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createFolder = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createFolder({ ...req.body, tenant_id: getTenant(req), owner_user_id: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getFolders = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFolders(getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getFolderById = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFolderById(getTenant(req), req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateFolder = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateFolder(getTenant(req), req.params.id, req.body, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const deleteFolder = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.deleteFolder(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const addFileToFolder = async (req: Request, res: Response): Promise<void> => {
  try {
    const { document_id } = req.body;
    const result = await service.addFileToFolder(req.params.id, document_id, getTenant(req), getUser(req));
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const removeFileFromFolder = async (req: Request, res: Response): Promise<void> => {
  try {
    await service.removeFileFromFolder(req.params.id, req.params.documentId, getTenant(req));
    res.json({ data: { success: true } });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getFolderFiles = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFolderFiles(req.params.id, getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
