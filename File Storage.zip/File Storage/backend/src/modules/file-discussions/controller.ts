import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createDiscussion = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createDiscussion({
      ...req.body,
      tenant_id: getTenant(req),
      user_id: getUser(req),
      document_id: req.params.documentId,
    });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getDiscussions = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getDiscussions(getTenant(req), req.params.documentId, req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getReplies = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getReplies(getTenant(req), req.params.id);
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateDiscussion = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateDiscussion(getTenant(req), req.params.id, req.body.message_text, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const deleteDiscussion = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.deleteDiscussion(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
