import { Router } from 'express';
import * as controller from './controller';

const router = Router({ mergeParams: true });
router.get('/', controller.getDiscussions);
router.post('/', controller.createDiscussion);
router.get('/:id/replies', controller.getReplies);
router.put('/:id', controller.updateDiscussion);
router.delete('/:id', controller.deleteDiscussion);
export default router;
