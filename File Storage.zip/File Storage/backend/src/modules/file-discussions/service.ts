import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';

export const createDiscussion = async (data: {
  user_id: string;
  tenant_id?: string;
  document_id: string;
  message_text: string;
  parent_message_id?: string;
  mentions?: string[];
  attachments?: string[];
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;

  let thread_depth = 0;
  if (data.parent_message_id) {
    const { data: parent } = await supabase
      .from('file_discussions')
      .select('thread_depth')
      .eq('discussion_id', data.parent_message_id)
      .eq('is_current', 1)
      .maybeSingle();
    thread_depth = Math.min((parent?.thread_depth || 0) + 1, 10);
  }

  const { data: inserted, error } = await supabase
    .from('file_discussions')
    .insert({
      discussion_id: generateUUID(),
      tenant_id,
      document_id: data.document_id,
      user_id: data.user_id,
      message_text: data.message_text.slice(0, 10000),
      parent_message_id: data.parent_message_id || null,
      thread_depth,
      mentions: data.mentions ? JSON.stringify(data.mentions) : null,
      attachments: data.attachments ? JSON.stringify(data.attachments) : null,
      is_edited: 0,
      status: 'ACTIVE',
      created_by: data.user_id,
    })
    .select().single();
  if (error) throw new Error(error.message);
  return inserted;
};

export const getDiscussions = async (
  tenant_id: string,
  document_id: string,
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('file_discussions')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .eq('status', 'ACTIVE')
    .eq('is_current', 1)
    .is('parent_message_id', null)
    .order('created_at', { ascending: true })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getReplies = async (tenant_id: string, parent_message_id: string) => {
  const { data, error } = await supabase
    .from('file_discussions')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('parent_message_id', parent_message_id)
    .eq('status', 'ACTIVE')
    .eq('is_current', 1)
    .order('created_at', { ascending: true });
  if (error) throw new Error(error.message);
  return Array.isArray(data) ? data : [];
};

export const updateDiscussion = async (
  tenant_id: string,
  discussion_id: string,
  message_text: string,
  updated_by: string
) => {
  const { data, error } = await supabase
    .from('file_discussions')
    .update({
      message_text: message_text.slice(0, 10000),
      is_edited: 1,
      edited_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      updated_by,
    })
    .eq('tenant_id', tenant_id)
    .eq('discussion_id', discussion_id)
    .eq('is_current', 1)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const deleteDiscussion = async (
  tenant_id: string,
  discussion_id: string,
  deleted_by: string
) => {
  const { data, error } = await supabase
    .from('file_discussions')
    .update({
      status: 'DELETED_BY_USER',
      updated_at: new Date().toISOString(),
      updated_by: deleted_by,
    })
    .eq('tenant_id', tenant_id)
    .eq('discussion_id', discussion_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};
