import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';
import { FileStatus, StorageTier, FileTag } from '@/types';

export const createFileMetadata = async (data: {
  user_id: string;
  file_name: string;
  mime_type: string;
  size_kb: number;
  checksum: string;
  storage_path: string;
  description?: string;
  tags?: FileTag[];
  tenant_id?: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const document_id = generateUUID();
  const now = new Date().toISOString();

  const { data: inserted, error } = await supabase
    .from('file_metadata')
    .insert({
      document_id, tenant_id,
      user_id: data.user_id,
      file_name: data.file_name,
      mime_type: data.mime_type,
      size_kb: data.size_kb,
      version: 1,
      status: 'ACTIVE',
      description: data.description || null,
      tags: data.tags || null,
      checksum: data.checksum,
      storage_path: data.storage_path,
      storage_tier: 'HOT',
      encryption_status: 'ENCRYPTED',
      effective_from: now,
      is_current: 1,
      created_by: data.user_id,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getFiles = async (tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { status, mime_type, search, folder_id } = query;

  let q = supabase
    .from('file_metadata')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (status) q = q.eq('status', status);
  if (mime_type) q = q.eq('mime_type', mime_type);
  if (search) q = q.ilike('file_name', `%${search}%`);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getFileById = async (tenant_id: string, document_id: string) => {
  const { data, error } = await supabase
    .from('file_metadata')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};

export const updateFileMetadata = async (
  tenant_id: string,
  document_id: string,
  updates: Partial<{
    file_name: string;
    description: string;
    tags: FileTag[];
    status: FileStatus;
    storage_tier: StorageTier;
  }>,
  updated_by: string
) => {
  // Close existing current version
  const existing = await getFileById(tenant_id, document_id);
  if (!existing) throw new Error('File not found');

  const now = new Date().toISOString();
  await supabase
    .from('file_metadata')
    .update({ is_current: 0, row_end: now })
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .eq('is_current', 1);

  // Insert new version
  const { data: newVersion, error } = await supabase
    .from('file_metadata')
    .insert({
      ...existing,
      row_id: generateUUID(),
      ...updates,
      version: (existing.version || 1) + 1,
      row_start: now,
      row_end: '9999-12-31 23:59:59.999999+00',
      effective_from: now,
      is_current: 1,
      updated_at: now,
      updated_by,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return newVersion;
};

export const deleteFile = async (tenant_id: string, document_id: string, updated_by: string) => {
  return updateFileMetadata(tenant_id, document_id, { status: 'DELETED' }, updated_by);
};

export const archiveFile = async (tenant_id: string, document_id: string, updated_by: string) => {
  return updateFileMetadata(tenant_id, document_id, { status: 'ARCHIVED' }, updated_by);
};

export const restoreFile = async (tenant_id: string, document_id: string, updated_by: string) => {
  return updateFileMetadata(tenant_id, document_id, { status: 'ACTIVE' }, updated_by);
};

export const getFileHistory = async (tenant_id: string, document_id: string) => {
  const { data, error } = await supabase
    .from('file_metadata')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .order('version', { ascending: false })
    .limit(50);
  if (error) throw new Error(error.message);
  return Array.isArray(data) ? data : [];
};

export const getFileAsOf = async (tenant_id: string, document_id: string, asOf: string) => {
  const { data, error } = await supabase
    .from('file_metadata')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .lte('effective_from', asOf)
    .gte('effective_to', asOf)
    .order('version', { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};
