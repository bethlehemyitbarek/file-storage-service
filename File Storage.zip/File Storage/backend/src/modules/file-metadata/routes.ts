import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getFiles);
router.post('/', controller.createFile);
router.get('/:id', controller.getFileById);
router.put('/:id', controller.updateFile);
router.delete('/:id', controller.deleteFile);
router.post('/:id/archive', controller.archiveFile);
router.post('/:id/restore', controller.restoreFile);
router.get('/:id/history', controller.getFileHistory);
router.get('/:id/as-of', controller.getFileAsOf);
export default router;
