import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createFile = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createFileMetadata({ ...req.body, tenant_id: getTenant(req), user_id: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getFiles = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFiles(getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getFileById = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFileById(getTenant(req), req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateFile = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updateFileMetadata(getTenant(req), req.params.id, req.body, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const deleteFile = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.deleteFile(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const archiveFile = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.archiveFile(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const restoreFile = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.restoreFile(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getFileHistory = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFileHistory(getTenant(req), req.params.id);
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getFileAsOf = async (req: Request, res: Response): Promise<void> => {
  try {
    const { as_of } = req.query as { as_of: string };
    if (!as_of) { res.status(400).json({ error: 'as_of query param required' }); return; }
    const result = await service.getFileAsOf(getTenant(req), req.params.id, as_of);
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
