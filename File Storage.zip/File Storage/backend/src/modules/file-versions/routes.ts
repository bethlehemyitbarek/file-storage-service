import { Router } from 'express';
import * as controller from './controller';

const router = Router({ mergeParams: true });
router.get('/', controller.getFileVersions);
router.post('/', controller.createFileVersion);
router.get('/:versionNumber', controller.getFileVersionByNumber);
export default router;
