import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';

export const createFileVersion = async (data: {
  document_id: string;
  tenant_id?: string;
  storage_path: string;
  checksum: string;
  size_kb: number;
  change_summary?: string;
  created_by: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;

  // Get current max version number
  const { data: latest } = await supabase
    .from('file_versions')
    .select('version_number')
    .eq('tenant_id', tenant_id)
    .eq('document_id', data.document_id)
    .order('version_number', { ascending: false })
    .limit(1)
    .maybeSingle();

  const version_number = (latest?.version_number || 0) + 1;

  const { data: inserted, error } = await supabase
    .from('file_versions')
    .insert({
      version_id: generateUUID(),
      document_id: data.document_id,
      tenant_id,
      version_number,
      storage_path: data.storage_path,
      checksum: data.checksum,
      size_kb: data.size_kb,
      change_summary: data.change_summary || null,
      encryption_status: 'ENCRYPTED',
      storage_tier: 'HOT',
      is_orphaned: 0,
      created_by: data.created_by,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getFileVersions = async (tenant_id: string, document_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('file_versions')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .eq('is_current', 1)
    .order('version_number', { ascending: false })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getFileVersionByNumber = async (tenant_id: string, document_id: string, version_number: number) => {
  const { data, error } = await supabase
    .from('file_versions')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('document_id', document_id)
    .eq('version_number', version_number)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};
