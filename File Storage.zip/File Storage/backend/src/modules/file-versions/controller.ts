import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createFileVersion = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createFileVersion({ ...req.body, tenant_id: getTenant(req), created_by: getUser(req), document_id: req.params.documentId });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getFileVersions = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFileVersions(getTenant(req), req.params.documentId, req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getFileVersionByNumber = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getFileVersionByNumber(getTenant(req), req.params.documentId, parseInt(req.params.versionNumber));
    if (!result) { res.status(404).json({ error: 'Version not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
