import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const grantPermission = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.grantPermission({ ...req.body, tenant_id: getTenant(req), granted_by: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getPermissions = async (req: Request, res: Response): Promise<void> => {
  try {
    const { document_id, folder_id, grantee_id } = req.query as Record<string, string>;
    const result = await service.getPermissions(getTenant(req), { document_id, folder_id, grantee_id }, req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const revokePermission = async (req: Request, res: Response): Promise<void> => {
  try {
    const { revocation_reason } = req.body;
    const result = await service.revokePermission(getTenant(req), req.params.id, revocation_reason || 'Revoked by admin', getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getSharedWithMe = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getSharedWithMe(getTenant(req), getUser(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getSharedByMe = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getSharedByMe(getTenant(req), getUser(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
  