import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getPermissions);
router.post('/', controller.grantPermission);
router.delete('/:id', controller.revokePermission);
router.get('/shared-with-me', controller.getSharedWithMe);
router.get('/shared-by-me', controller.getSharedByMe);
export default router;
