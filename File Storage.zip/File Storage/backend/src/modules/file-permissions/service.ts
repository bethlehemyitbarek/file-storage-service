import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';

export const grantPermission = async (data: {
  document_id?: string;
  folder_id?: string;
  tenant_id?: string;
  grantee_type: string;
  grantee_id: string;
  grantee_email?: string;
  role: string;
  access_level: string;
  expires_at?: string;
  share_message?: string;
  apply_recursively?: boolean;
  granted_by: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const { data: inserted, error } = await supabase
    .from('file_permissions')
    .insert({
      permission_id: generateUUID(),
      document_id: data.document_id || null,
      folder_id: data.folder_id || null,
      tenant_id,
      grantee_type: data.grantee_type,
      grantee_id: data.grantee_id,
      grantee_email: data.grantee_email || null,
      role: data.role,
      access_level: data.access_level,
      share_link_enabled: 0,
      apply_recursively: data.apply_recursively ? 1 : 0,
      granted_by: data.granted_by,
      granted_at: new Date().toISOString(),
      expires_at: data.expires_at || null,
      share_message: data.share_message || null,
      status: 'ACTIVE',
      access_count: 0,
      created_by: data.granted_by,
    })
    .select().single();
  if (error) throw new Error(error.message);
  return inserted;
};

export const getPermissions = async (
  tenant_id: string,
  filters: { document_id?: string; folder_id?: string; grantee_id?: string },
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);
  let q = supabase
    .from('file_permissions')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .eq('status', 'ACTIVE')
    .order('granted_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (filters.document_id) q = q.eq('document_id', filters.document_id);
  if (filters.folder_id) q = q.eq('folder_id', filters.folder_id);
  if (filters.grantee_id) q = q.eq('grantee_id', filters.grantee_id);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const revokePermission = async (tenant_id: string, permission_id: string, revocation_reason: string, revoked_by: string) => {
  const { data, error } = await supabase
    .from('file_permissions')
    .update({
      status: 'REVOKED',
      revoked_at: new Date().toISOString(),
      revocation_reason,
      updated_at: new Date().toISOString(),
      updated_by: revoked_by,
    })
    .eq('tenant_id', tenant_id)
    .eq('permission_id', permission_id)
    .eq('is_current', 1)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const getSharedWithMe = async (tenant_id: string, user_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('file_permissions')
    .select('*, file_metadata!document_id(document_id, file_name, mime_type, size_kb, status, created_at)', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('grantee_id', user_id)
    .eq('status', 'ACTIVE')
    .eq('is_current', 1)
    .order('granted_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getSharedByMe = async (tenant_id: string, user_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { data, error, count } = await supabase
    .from('file_permissions')
    .select('*, file_metadata!document_id(document_id, file_name, mime_type, size_kb, status, created_at)', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('granted_by', user_id)
    .eq('status', 'ACTIVE')
    .eq('is_current', 1)
    .order('granted_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};
