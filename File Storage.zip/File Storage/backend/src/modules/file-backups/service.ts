import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, computeChecksum, getPaginationParams } from '@/utils';
import { BackupType, BackupScope } from '@/types';

export const createBackup = async (data: {
  document_id?: string;
  tenant_id?: string;
  backup_path: string;
  backup_type: BackupType;
  backup_scope: BackupScope;
  size_bytes: number;
  file_count: number;
  retention_days?: number;
  created_by: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const checksum = computeChecksum(`${data.backup_path}:${data.size_bytes}:${Date.now()}`);

  const { data: inserted, error } = await supabase
    .from('file_backups')
    .insert({
      backup_id: generateUUID(),
      document_id: data.document_id || null,
      tenant_id,
      backup_path: data.backup_path,
      backup_type: data.backup_type,
      backup_scope: data.backup_scope,
      checksum,
      size_bytes: data.size_bytes,
      file_count: data.file_count,
      encryption_status: 'ENCRYPTED',
      retention_days: data.retention_days || 365,
      status: 'IN_PROGRESS',
      created_by: data.created_by,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getBackups = async (tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);
  const { status, backup_type, backup_scope } = query;

  let q = supabase
    .from('file_backups')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .eq('is_deleted', 0)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (status) q = q.eq('status', status);
  if (backup_type) q = q.eq('backup_type', backup_type);
  if (backup_scope) q = q.eq('backup_scope', backup_scope);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getBackupById = async (tenant_id: string, backup_id: string) => {
  const { data, error } = await supabase
    .from('file_backups')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('backup_id', backup_id)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};

export const updateBackupStatus = async (
  tenant_id: string,
  backup_id: string,
  status: string,
  failure_reason?: string
) => {
  const updates: Record<string, unknown> = { status, updated_at: new Date().toISOString() };
  if (status === 'SUCCESS' || status === 'FAILED' || status === 'PARTIAL') {
    updates.completed_at = new Date().toISOString();
  }
  if (failure_reason) updates.failure_reason = failure_reason;

  const { data, error } = await supabase
    .from('file_backups')
    .update(updates)
    .eq('tenant_id', tenant_id)
    .eq('backup_id', backup_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};
