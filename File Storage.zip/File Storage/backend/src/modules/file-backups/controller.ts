import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createBackup = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createBackup({ ...req.body, tenant_id: getTenant(req), created_by: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getBackups = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getBackups(getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getBackupById = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getBackupById(getTenant(req), req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updateBackupStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const { status, failure_reason } = req.body;
    const result = await service.updateBackupStatus(getTenant(req), req.params.id, status, failure_reason);
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
