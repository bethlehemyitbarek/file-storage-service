import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getBackups);
router.post('/', controller.createBackup);
router.get('/:id', controller.getBackupById);
router.patch('/:id/status', controller.updateBackupStatus);
export default router;
