import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, computeAuditSignature, getPaginationParams } from '@/utils';
import { AuditAction, ActorType } from '@/types';

export const createAuditLog = async (data: {
  document_id?: string;
  tenant_id?: string;
  actor_id: string;
  actor_type?: ActorType;
  action: AuditAction;
  old_value?: Record<string, unknown>;
  new_value?: Record<string, unknown>;
  reason?: string;
  viewer_role?: string;
  ip_address?: string;
  user_agent?: string;
  correlation_id?: string;
  session_id?: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const audit_id = generateUUID();
  const action_timestamp = new Date().toISOString();

  // Get previous audit hash for chaining
  const { data: previous } = await supabase
    .from('file_audit_logs')
    .select('audit_signature')
    .eq('tenant_id', tenant_id)
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  const previous_audit_hash = previous?.audit_signature || null;
  const audit_signature = computeAuditSignature(
    audit_id, data.document_id, data.action, action_timestamp, previous_audit_hash
  );

  const { data: inserted, error } = await supabase
    .from('file_audit_logs')
    .insert({
      audit_id,
      document_id: data.document_id || null,
      tenant_id,
      actor_id: data.actor_id,
      actor_type: data.actor_type || 'USER',
      action: data.action,
      action_timestamp,
      old_value: data.old_value ? JSON.stringify(data.old_value) : null,
      new_value: data.new_value ? JSON.stringify(data.new_value) : null,
      reason: data.reason || null,
      viewer_role: data.viewer_role || 'END_USER',
      ip_address: data.ip_address || null,
      user_agent: data.user_agent || null,
      correlation_id: data.correlation_id || null,
      session_id: data.session_id || null,
      audit_signature,
      previous_audit_hash,
      created_by: data.actor_id,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getAuditLogs = async (
  tenant_id: string,
  filters: {
    document_id?: string;
    actor_id?: string;
    action?: string;
    from_date?: string;
    to_date?: string;
  },
  query: Record<string, string | undefined>
) => {
  const { page, limit, offset } = getPaginationParams(query);

  let q = supabase
    .from('file_audit_logs')
    .select('*', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .order('action_timestamp', { ascending: false })
    .range(offset, offset + limit - 1);

  if (filters.document_id) q = q.eq('document_id', filters.document_id);
  if (filters.actor_id) q = q.eq('actor_id', filters.actor_id);
  if (filters.action) q = q.eq('action', filters.action);
  if (filters.from_date) q = q.gte('action_timestamp', filters.from_date);
  if (filters.to_date) q = q.lte('action_timestamp', filters.to_date);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};
