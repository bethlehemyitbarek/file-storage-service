import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createAuditLog = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createAuditLog({
      ...req.body,
      tenant_id: getTenant(req),
      actor_id: getUser(req),
      ip_address: req.ip,
      user_agent: req.headers['user-agent'],
    });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getAuditLogs = async (req: Request, res: Response): Promise<void> => {
  try {
    const { document_id, actor_id, action, from_date, to_date } = req.query as Record<string, string>;
    const result = await service.getAuditLogs(
      getTenant(req),
      { document_id, actor_id, action, from_date, to_date },
      req.query as Record<string, string>
    );
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};
