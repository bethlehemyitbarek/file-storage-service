import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getAuditLogs);
router.post('/', controller.createAuditLog);
export default router;
