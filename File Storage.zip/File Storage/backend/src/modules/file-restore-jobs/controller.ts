import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const createRestoreJob = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.createRestoreJob({ ...req.body, tenant_id: getTenant(req), requested_by: getUser(req) });
    res.status(201).json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const getRestoreJobs = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getRestoreJobs(getTenant(req), req.query as Record<string, string>);
    res.json(result);
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const getRestoreJobById = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getRestoreJobById(getTenant(req), req.params.id);
    if (!result) { res.status(404).json({ error: 'Not found' }); return; }
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const approveRestoreJob = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.approveRestoreJob(getTenant(req), req.params.id, getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};

export const updateRestoreJobStatus = async (req: Request, res: Response): Promise<void> => {
  try {
    const { status, failure_reason } = req.body;
    const result = await service.updateRestoreJobStatus(getTenant(req), req.params.id, status, failure_reason);
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
