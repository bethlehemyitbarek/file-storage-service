import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID, getPaginationParams } from '@/utils';
import { RestoreScope } from '@/types';

export const createRestoreJob = async (data: {
  document_id?: string;
  folder_id?: string;
  tenant_id?: string;
  backup_id: string;
  restore_scope: RestoreScope;
  restore_path: string;
  restore_target_version?: number;
  restore_target_time?: string;
  requested_by: string;
}) => {
  const tenant_id = data.tenant_id || DEFAULT_TENANT_ID;
  const requiresApproval = data.restore_scope === 'TENANT' || data.restore_scope === 'BULK';

  const { data: inserted, error } = await supabase
    .from('file_restore_jobs')
    .insert({
      restore_id: generateUUID(),
      document_id: data.document_id || null,
      folder_id: data.folder_id || null,
      tenant_id,
      backup_id: data.backup_id,
      restore_scope: data.restore_scope,
      restore_path: data.restore_path,
      restore_target_version: data.restore_target_version || null,
      restore_target_time: data.restore_target_time || null,
      requested_by: data.requested_by,
      restored_file_count: 0,
      failed_file_count: 0,
      status: requiresApproval ? 'PENDING_APPROVAL' : 'IN_PROGRESS',
      approval_status: requiresApproval ? 'PENDING' : 'APPROVED',
      requested_at: new Date().toISOString(),
      created_by: data.requested_by,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const getRestoreJobs = async (tenant_id: string, query: Record<string, string | undefined>) => {
  const { page, limit, offset } = getPaginationParams(query);

  let q = supabase
    .from('file_restore_jobs')
    .select('*, file_backups!backup_id(backup_type, backup_scope)', { count: 'exact' })
    .eq('tenant_id', tenant_id)
    .eq('is_current', 1)
    .order('requested_at', { ascending: false })
    .range(offset, offset + limit - 1);

  if (query.status) q = q.eq('status', query.status);

  const { data, error, count } = await q;
  if (error) throw new Error(error.message);
  return { data: Array.isArray(data) ? data : [], total: count || 0, page, limit };
};

export const getRestoreJobById = async (tenant_id: string, restore_id: string) => {
  const { data, error } = await supabase
    .from('file_restore_jobs')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('restore_id', restore_id)
    .eq('is_current', 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data;
};

export const approveRestoreJob = async (tenant_id: string, restore_id: string, approved_by: string) => {
  const { data, error } = await supabase
    .from('file_restore_jobs')
    .update({
      approval_status: 'APPROVED',
      status: 'IN_PROGRESS',
      approved_by,
      approved_at: new Date().toISOString(),
    })
    .eq('tenant_id', tenant_id)
    .eq('restore_id', restore_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};

export const updateRestoreJobStatus = async (
  tenant_id: string,
  restore_id: string,
  status: string,
  failure_reason?: string
) => {
  const updates: Record<string, unknown> = { status, updated_at: new Date().toISOString() };
  if (status === 'COMPLETED' || status === 'FAILED') updates.completed_at = new Date().toISOString();
  if (failure_reason) updates.failure_reason = failure_reason;

  const { data, error } = await supabase
    .from('file_restore_jobs')
    .update(updates)
    .eq('tenant_id', tenant_id)
    .eq('restore_id', restore_id)
    .select().single();
  if (error) throw new Error(error.message);
  return data;
};
