import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getRestoreJobs);
router.post('/', controller.createRestoreJob);
router.get('/:id', controller.getRestoreJobById);
router.post('/:id/approve', controller.approveRestoreJob);
router.patch('/:id/status', controller.updateRestoreJobStatus);
export default router;
