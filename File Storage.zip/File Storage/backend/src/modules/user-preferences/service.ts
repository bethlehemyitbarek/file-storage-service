import { supabase, DEFAULT_TENANT_ID } from '@/config/supabase';
import { generateUUID } from '@/utils';

export const getPreferences = async (tenant_id: string, user_id: string) => {
  const { data: existing } = await supabase
    .from('user_storage_preferences')
    .select('*')
    .eq('tenant_id', tenant_id)
    .eq('user_id', user_id)
    .eq('is_current', 1)
    .maybeSingle();

  if (existing) return existing;

  const { data: inserted, error } = await supabase
    .from('user_storage_preferences')
    .insert({
      preference_id: generateUUID(),
      tenant_id,
      user_id,
      preferred_view: 'LIST',
      default_sort_field: 'created_at',
      default_sort_order: 'DESC',
      items_per_page: 25,
      notification_settings: JSON.stringify({}),
      thumbnail_preview_enabled: 1,
      auto_save_interval_seconds: 30,
      theme: 'SYSTEM',
      language: 'en',
      created_by: user_id,
    })
    .select().single();

  if (error) throw new Error(error.message);
  return inserted;
};

export const updatePreferences = async (
  tenant_id: string,
  user_id: string,
  updates: Record<string, unknown>
) => {
  const existing = await getPreferences(tenant_id, user_id);

  // Clamp items_per_page to max 100
  if (updates.items_per_page) {
    updates.items_per_page = Math.min(100, Number(updates.items_per_page));
  }

  const { data, error } = await supabase
    .from('user_storage_preferences')
    .update({ ...updates, updated_at: new Date().toISOString(), updated_by: user_id })
    .eq('preference_id', existing.preference_id)
    .select().single();

  if (error) throw new Error(error.message);
  return data;
};
