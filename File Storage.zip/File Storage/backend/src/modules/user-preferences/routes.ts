import { Router } from 'express';
import * as controller from './controller';

const router = Router();
router.get('/', controller.getPreferences);
router.put('/', controller.updatePreferences);
export default router;
