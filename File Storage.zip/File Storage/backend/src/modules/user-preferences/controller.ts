import { Request, Response } from 'express';
import * as service from './service';
import { DEFAULT_TENANT_ID } from '@/config/supabase';

const getTenant = (req: Request) => (req.headers['x-tenant-id'] as string) || DEFAULT_TENANT_ID;
const getUser = (req: Request) => (req.headers['x-user-id'] as string) || 'anonymous';

export const getPreferences = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.getPreferences(getTenant(req), getUser(req));
    res.json({ data: result });
  } catch (err: unknown) { res.status(500).json({ error: (err as Error).message }); }
};

export const updatePreferences = async (req: Request, res: Response): Promise<void> => {
  try {
    const result = await service.updatePreferences(getTenant(req), getUser(req), req.body);
    res.json({ data: result });
  } catch (err: unknown) { res.status(400).json({ error: (err as Error).message }); }
};
