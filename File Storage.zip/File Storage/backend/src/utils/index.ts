import { createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';

export const generateUUID = (): string => uuidv4();

export const computeChecksum = (data: string): string => {
  return createHash('sha256').update(data).digest('hex');
};

export const computeAuditSignature = (
  auditId: string,
  documentId: string | undefined,
  action: string,
  timestamp: string,
  previousHash: string | undefined
): string => {
  const payload = `${auditId}:${documentId || ''}:${action}:${timestamp}:${previousHash || ''}`;
  return computeChecksum(payload);
};

export const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

export const sanitizeEmpty = <T extends Record<string, unknown>>(obj: T): T => {
  const result = { ...obj };
  for (const key of Object.keys(result)) {
    if (result[key] === '') {
      (result as Record<string, unknown>)[key] = null;
    }
  }
  return result;
};

export const getPaginationParams = (query: Record<string, string | undefined>) => {
  const page = Math.max(1, parseInt(query.page || '1', 10));
  const limit = Math.min(100, Math.max(1, parseInt(query.limit || '25', 10)));
  const offset = (page - 1) * limit;
  return { page, limit, offset };
};
