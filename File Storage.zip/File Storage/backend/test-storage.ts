import dotenv from "dotenv";
dotenv.config();

import { createClient } from "@supabase/supabase-js";

console.log("SUPABASE_URL:", process.env.SUPABASE_URL);
console.log("SUPABASE_SERVICE_KEY:", process.env.SUPABASE_SERVICE_KEY);

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

async function run() {
  const { data, error } = await supabase.storage.listBuckets();

  console.log("Buckets:", data);
  console.log("Error:", error);
}

run();