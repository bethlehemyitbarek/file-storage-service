Backend is complete. See src/index.ts for entry point. All 14 modules implemented:

file-requests
upload-sessions
file-metadata
file-versions
file-permissions
file-audit-logs
file-backups
file-restore-jobs
storage-quotas
file-calendar-events
file-discussions
folders
file-notifications
user-preferences